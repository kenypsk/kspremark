import requests,unittest,os,sys
from UtilityModule.ultm import UM
from UtilityModule.path import *
from log.logger import *

class TestTerminal(unittest.TestCase):

    '''API:终端详情'''

    global logging
    logging = log()

    def setUp(self):
        logging.info("API：终端详情用接口例开始执行")
        filename = get_FatherPath()+'excel_api\\test.xlsx'
        logging.info("接口用例Excel文件路径：%s"%filename)
        self.token =UM().get_token("login_api",filename) # 获取登录token
        self.url = UM().getUrl_readexcel("api",1,1,4,filename)  # 获取api url
        self.data = UM().get_data("api",1,6,filename)

    def test_terminal_case(self):
        headers = {'Content-Type': 'application/json', 'Authorization': self.token}
        resp = requests.get(self.url,headers=headers)
        assert resp.status_code == 200   #d 断言返回状态是否为200
        logging.info("断言：返回状态，%s"%resp.status_code)
        resp_data = resp.json()
        logging.info("接口响应数据，data=%s"%resp_data)
        terminal_data = resp_data['data'].values()

        i = 0
        # 断言响应数据
        for terminal in terminal_data:
            logging.info("terminal is %s,data is %s"%(terminal,self.data[i]))
            if isinstance(terminal,int):
                assert terminal == int(self.data[i])
            else:
                assert terminal == self.data[i]
            i += 1



if __name__ == '__main__':

    suite = unittest.TestSuite()
    suite.addTest(TestTerminal("test_terminal_case"))

    runner = unittest.TextTestRunner()
    runner.run(suite)