import HTMLTestRunner,unittest,os

case_path = os.path.join(os.getcwd(),"case")  # 测试用例路径
report_path = os.path.join(os.getcwd(),"report")    # 存放测试报告路径

# 遍历case文件夹下的所有test*.py用例，获取用例的test方法,以list形式存储在discover里面
discover = unittest.defaultTestLoader.discover(case_path,
                                               pattern="test*.py",
                                               top_level_dir=None)

#生成测试报告文件
filename = report_path+'\\result.html'
fp = open(filename, 'wb')

runner = HTMLTestRunner.HTMLTestRunner(
    stream=fp,
    title='测试结果',
    description='测试报告.'
)

runner.run(discover)