import os

# 构造当前工作区前的根路劲
def get_FatherPath():
    path = os.getcwd().split('\\')
    return path[0] + '\\' + path[1] + '\\'