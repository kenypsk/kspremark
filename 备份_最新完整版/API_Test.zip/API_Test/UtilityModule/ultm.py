import xlrd,requests,os
from log.logger import *

class UM(object):

    global logging
    logging = log()

    # 读取excel，获取API的URL
    # 参数：
    #     sheetname:sheet名字
    #     row:第几行
    #     begincol: 开始列
    #     endcol：结束列
    def getUrl_readexcel(self,sheetname,row,begincol,endcol,filname):
        # 打开文件
        workbook = xlrd.open_workbook(filname)
        # 根据sheet索引或者名称获取sheet内容
        sheet = workbook.sheet_by_name(sheetname)
        # 获取整行值（数组）
        rows = sheet.row_values(row)  # 获取行内容
        logging.info("从Excel获取接口信息:%s"%rows)
        url = ""
        for i in range(begincol,endcol+1):
            url += rows[i]
        logging.info("接口地址：%s"%url)
        return url

    # 获取登录接口的token值
    # sheetname:sheet名字
    def get_token(self,sheet_name,filname):
        workbook = xlrd.open_workbook(filname)
        sheet = workbook.sheet_by_name(sheet_name)
        headers = {sheet.cell(0,1).value:sheet.cell(1,1).value}  # 获取登录headers
        logging.info("获取登录接口的headers:%s"%headers)
        data = {sheet.cell(0,5).value:sheet.cell(1,5).value,
                sheet.cell(0,6).value:sheet.cell(1,6).value}    # 获取用户，密码
        logging.info("获取登录接口的请求数据:%s" % data)
        rowsdata = sheet.row_values(1)  # 获取行数据
        url = ""
        for i in range(2,5):
            url += rowsdata[i]
        logging.info("登录接口的链接：%s"%url)
        resp = requests.post(url,json=data,headers=headers)
        resp_data = resp.json()
        token = resp_data['data']['token']  # 获取token
        logging.info("登录接口返回的token：%s"%token)
        return token


    # 获取用例的预想结果数据
    # 参数：
    #   sheet_name:sheet名称
    #   row:第几行
    #   clo:第几列
    def get_data(self,sheet_name,row,col,filname):
        workbook = xlrd.open_workbook(filname)
        sheet = workbook.sheet_by_name(sheet_name)
        data = sheet.cell(row,col).value.split(',')
        logging.info("接口的预想数据：%s"%data)
        return data


