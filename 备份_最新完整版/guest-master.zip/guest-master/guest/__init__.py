import pymysql
pymysql.install_as_MySQLdb()

"""
如果你使用pymysql驱动的话，上面两行必须添加。
"""
