#!/usr/bin/python
# coding: utf-8
from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.common.analyze_base import AnalyzeBase

logger = Logger(logger="AnalyzeDefault").getlog()
base_conf = BaseConf()
analyze_base = AnalyzeBase()


# 【解析】 固定部分解析 --> 了解报文的具体含义，最重要的是得到应用层功能码 AFN
class AnalyzeFixed(object):

    # 【检查】：固定报文（第一个、第六个、最后一个字节分别是：68H 68H 16H）
    def check_fixed(self, data_list):
        first_byte = data_list[0]
        # logger.info("【报文 第一个字节】：%s" % first_byte)
        if eval(first_byte) == 68:
            logger.info("【正常】 第一个字节是 %d" % eval(first_byte))
        else:
            logger.error("【错误】 第一个字节是 %d 不是68！" % eval(first_byte))

        sixth_byte = data_list[5]
        # logger.info("【报文 第六个字节】：%s" % sixth_byte)
        if eval(sixth_byte) == 68:
            logger.info("【正常】 第六个字节是 %d" % eval(sixth_byte))
        else:
            logger.error("【错误】 第六个字节是 %d 不是68！" % eval(sixth_byte))

        final_byte = data_list[-1]
        # logger.info("【报文 最后一个字节】：%s" % final_byte)
        if eval(final_byte) == 16:
            logger.info("【正常】 最后一个字节是 %d" % eval(final_byte))
        else:
            logger.error("【错误】 最后一个字节是 %d 不是16" % eval(final_byte))

    # 补位：不足8位的补0
    def generate_append_string(self, length):
        value = 8 - length
        tmp_string = ""
        if value == 1:
            tmp_string = '0'
        elif value == 2:
            tmp_string = '00'
        elif value == 3:
            tmp_string = '000'
        elif value == 4:
            tmp_string = '0000'
        elif value == 5:
            tmp_string = '00000'
        elif value == 6:
            tmp_string = '000000'
        elif value == 7:
            tmp_string = '0000000'
        else:
            logger.error("【错误】 长度不正确!")
        return tmp_string

    # 判断：长度（L第一部分D0-D1：表示是否适用本协议）
    def check_protocol(self, L_list_type1):

        hex_value = '0x' + L_list_type1  # 先把原始报文的16进制格式标准化
        # logger.info(hex_value)   # 打印：16进制
        int_value = eval(hex_value)  # int_value = int(hex_value, 16)
        # logger.info(int_value)  # 打印：16进制转为10进制
        bin_value = bin(int_value)
        # logger.info("  长度 L 计算报文再转换二进制值：" + bin_value)   # 打印：10进制转换为2进制
        D0 = bin_value[-1]
        # logger.info("  D0的值是：" + D0)
        D1 = bin_value[-2]
        # logger.info("  D1的值是：" + D1)
        if eval(D0) == 0 and eval(D1) == 1:
            logger.info("【正常】 L 长度 D0=0，D1=1，适用376.1协议 ")
            # print("【正常】 L 长度 D0=0，D1=1，此报文适用376.1协议 ")
        elif eval(D0) == 0 and eval(D1) == 0:
            logger.info("【正常】 L 长度 D0=0，D1=0，禁用 ")
        elif eval(D0) == 1 and eval(D1) == 0:
            logger.info("【正常】 L 长度 D0=1，D1=0，为《Q/GDW 130—2005电力负荷管理系统数据传输规约》使用 ")
        else:
            logger.error("【正常】 L 长度 D0=1，D1=1，保留")

    # 计算：长度（L第二部分D2-D15：即 L1，用户数据长度，采用BIN编码，是控制域、地址域、链路用户数据（应用层）的字节总数）
    def calculate_length(self, L_list):
        # 先高低位交换位置，如32 00 交换后00 32
        # 获取交换后的低位32的其中去掉D0、D1后剩余的D2-D7
        byte1 = L_list[1]
        # logger.info(byte1)
        bin_value1 = bin(eval(('0x' + byte1)))  # 16进制-->10进制-->2进制
        # logger.info(bin_value1)
        bin_value1 = bin_value1[:-2]
        # logger.info(bin_value1)
        if len(bin_value1) != 8:
            append_string = self.generate_append_string(len(bin_value1))
        else:
            append_string = ''
        bin_value1 = '0b' + append_string + bin_value1[2:]
        # logger.info(bin_value1)

        # 获取交换后的高位00的D8-D15
        byte2 = L_list[0]
        # logger.info(byte2)
        bin_value2 = bin(eval(('0x' + byte2)))  # 16进制-->10进制-->2进制
        # logger.info(bin_value2)

        # 得到L的长度值
        length_value = bin_value2 + bin_value1[2:]
        # logger.info(int(length_value, 2))
        return int(length_value, 2)

    # 比较：长度L是否正确
    def compare_length(self, data_list, L_length):
        user_data = data_list[6:-2]
        # logger.info("  长度 L 计算数据范围：%s" % user_data)
        logger.info("【正常】 L 长度 D2-D15用户数据长度：%d" % L_length)
        if L_length == len(user_data):
            logger.info("【正常】 L 长度：%d，匹配" % L_length)
            print("【正常】 L 长度：%d，匹配" % L_length)
        else:
            logger.error("【错误】 L 长度不匹配，原用户数据长度 %d，实际长度%d" % (len(user_data), L_length))
            print("【错误】 L 长度不匹配，原用户数据长度 %d，实际长度%d" % (len(user_data), L_length))

    # 【检查】：L（长度）
    def check_length_L(self, data_list):
        L_list = data_list[1:3]
        logger.info("【报文 L 长度】：%s" % L_list)
        L_list.reverse()
        # logger.info("  长度 L 计算报文，需高低位交换：%s" % L_bytes)
        L_list_type1 = L_list[1]
        self.check_protocol(L_list_type1)  # 高低位交换后，通过 D0-D1：【得到判断结果 L1 是否使用与本协议】
        L_length = self.calculate_length(L_list)  # 高低位交换后，通过 D2-D15：【得到 L2 长度值】
        self.compare_length(data_list, L_length)  # 高低位交换后，报文长度是否匹配

    # 【检查】：CS (校验和)  ：所有16进制数据相加，再截取最后两位
    def check_checks_sum_CS(self, data_list):
        # （1）报文的CS值
        message_cs = data_list[-2]
        logger.info("【报文 CS 校验和】：%s" % message_cs)

        # （2）通过计算得到CS值
        user_data = data_list[6:-2]
        # logger.info("  （2）计算出校验和 CS 值：")
        # logger.info("  校验和 CS 计算数据范围：%s" % user_data)
        hex_user_data = ['0x' + item for item in user_data]
        # logger.info("  校验和 CS 计算数据范围转换为16进制：%s" % hex_user_data)
        byte_sum = sum([eval(value) for value in hex_user_data])
        # logger.info("  所有16进制数据相加："+hex(byte_sum))
        actual_cs = hex(byte_sum)[-2:]
        logger.info("【计算】 CS 校验和，通过所有16进制数据相加，再截取最后两位：" + actual_cs)

        # （3）对比报文的CS 和计算得到的CS 值相等
        if actual_cs == message_cs:
            print("【正常】 CS 校验和：%s，匹配" % message_cs)
            logger.info("【正常】 CS 校验和：%s，匹配" % message_cs)
        else:
            print("【错误】 CS 校验和不匹配，计算校验和 %s，实际校验和 %s" % (actual_cs, message_cs))
            logger.error("【错误】 CS 校验和不匹配，计算校验和 %s，实际校验和 %s" % (actual_cs, message_cs))

    # 【检查】：C (控制域)
    def check_control_bytes_C(self, data_list):
        dict_PRM1 = {1: '发送或确认: 服务于复位命令', 4: '发送或无回答: 服务于用户数据', 9: '请求: 服务于链路测试', 10: '请求: 请求1级数据', 11: '请求：请求2级数据'}
        dict_PRM0 = {0: '确认', 8: '响应帧: 对用户数据请求的响应', 9: '响应帧: 否认: 响应无所召唤的数据时', 11: '响应帧: 链路测试响应'}
        control_byte = data_list[6]
        logger.info("【报文 C 控制域】：" + control_byte)
        hex_control_byte = '0x' + control_byte
        bin_control_byte = bin(eval(hex_control_byte))
        data_control_byte = bin_control_byte[2:]
        # 高位有可能需要补位 0
        if len(data_control_byte) != 8:
            append_string = self.generate_append_string(len(data_control_byte))
        else:
            append_string = ''
        data_control_byte = append_string + data_control_byte
        # logger.info(" （2）报文中控制域 C值转换为二进制：" + data_control_byte)

        # 通过D7 位，即传输方向位 DIR ，判断报文是上行，还是下行
        # 目前报文：一般默认 帧计数位FCB、要求访问位ACD、帧计数有效位FCV 均为0
        # 通过D5位，帧计数位FCB（下行）、要求访问位ACD（上行）
        DIR = data_control_byte[0]
        if data_control_byte[0] == '1':  # DIR
            logger.info("【正常】 C 控制域 D7：传输方向位 DIR = 1，上行报文，来自终端！")
            # print("【正常】 C 控制域 D7：传输方向位 DIR = 1，上行报文，来自终端！")
            if data_control_byte[2] == "1":  # ACD
                logger.info("【正常】 C 控制域 D5：要求访问位 ACD = 1，终端有重要事件等待访问，则附加信息域中带有事件计数器EC")
                print("【正常】 C 控制域 D5：要求访问位 ACD = 1，终端有重要事件等待访问，则附加信息域中带有事件计数器EC")
            else:
                logger.info("【正常】 C 控制域 D5：要求访问位 ACD = 0，终端无事件数据等待访问")
                print("【正常】 C 控制域 D5：要求访问位 ACD = 0，终端无事件数据等待访问")
            logger.info("【正常】 C 控制域 D4：保留")
            print("【正常】 C 控制域 D4：保留")
        else:
            logger.info("【正常】 C 控制域 D7：传输方向位 DIR = 0，下行报文，来自主站！")
            # print("【正常】 C 控制域 D7：传输方向位 DIR = 0，下行报文，来自主站！")
            if data_control_byte[3] == "1":  # FCV
                logger.info("【正常】 C 控制域 D4：帧计数有效位 FCV = 1，FCB位有效，FCB每个站连续的发送/确认或者请求/响应服务的变化位。FCB位用来防止信息传输的丢失和重复")
                print("【正常】 C 控制域 D4：帧计数有效位 FCV = 1，FCB位有效，FCB每个站连续的发送/确认或者请求/响应服务的变化位。FCB位用来防止信息传输的丢失和重复")
                if data_control_byte[2] == "0":  # FCB
                    logger.info("【正常】 C 控制域 D5：帧计数位 FCB = 0，从动站接收复位命令后将FCB置“0”")
                    print("【正常】 C 控制域 D5：帧计数位 FCB = 0，从动站接收复位命令后将FCB置“0”")
            else:
                logger.info("【正常】 C 控制域 D4：帧计数有效位 FCV = 0，FCB位无效")
                print("【正常】 C 控制域 D4：帧计数有效位 FCV = 0，FCB位无效")

        # 通过D6 位，即启动标志位PRM ，判断报文来自启动站，还是从动站
        if data_control_byte[1] == '1':
            logger.info("【正常】 C 控制域 D6：启动标志位 PRM = 1，报文来自启动站！")
        else:
            logger.info("【正常】 C 控制域 D6：启动标志位 PRM = 0，报文来自从动站！")

        # 综合D7、D6判断：
        if data_control_byte[0] == '0' and data_control_byte[1] == '0':
            logger.info("【正常】 C 控制域 D7=0，D6=0，下行，响应报文来自主站， 终端作为启动站！")
            print("【正常】 C 控制域 D7=0，D6=0，下行，响应报文来自主站， 终端作为启动站！")

        elif data_control_byte[0] == '0' and data_control_byte[1] == '1':
            logger.info("【正常】 C 控制域 D7=0，D6=1，下行，请求报文来自主站， 主站作为启动站！")
            print("【正常】 C 控制域 D7=0，D6=1，下行，请求报文来自主站， 主站作为启动站！")
            # if data_control_byte[3] == '1':
            #     logger.info("【正常】 FCB 帧计数位正常，注意响应信息！")
            # else:
            #     logger.info("【正常】 FCB 帧计数位和 FCV 帧计数有效位,应该为0，记得检查！")
            #     if FCV is 0, FCB does not work, set to 0 by default
        elif data_control_byte[0] == '1' and data_control_byte[1] == '0':
            logger.info("【正常】 C 控制域 D7=1，D6=0，上行，响应报文来自终端，主站作为启动站！")
            print("【正常】 C 控制域 D7=1，D6=0，上行，响应报文来自终端，主站作为启动站！")
        else:
            logger.info("【正常】 C 控制域 D7=1，D6=1，上行，请求报文来自终端，终端作为启动站！")
            print("【正常】 C 控制域 D7=1，D6=1，上行，请求报文来自终端，终端作为启动站！")

        bin_fun_code = '0b' + data_control_byte[4:]
        fun_code = int(bin_fun_code, 2)
        # logger.info("  （3）功能码：%d" % fun_code)
        # 通过上行、下行信息，判断功能码，对应具体功能
        if data_control_byte[1] == '1':
            print("【正常】 C 控制域 D0-D3功能码 ：%d, 表示：{ %s }" % (fun_code, dict_PRM1[fun_code]))
            logger.info("【正常】 C 控制域 D0-D3功能码：%d, 表示：{ %s }" % (fun_code, dict_PRM1[fun_code]))
        else:
            print("【正常】 C控制域 D0-D3功能码：%d, 表示：{ %s }" % (fun_code, dict_PRM0[fun_code]))
            logger.info("【正常】 C控制域 D0-D3功能码：%d, 表示：{ %s }" % (fun_code, dict_PRM0[fun_code]))
        return DIR

    # 【检查】：A (地址域)   # 注意，当前用的A1都是: 5000
    def check_address_bytes_A(self, data_list):
        # （1）2B：A1行政区划码，实际字节反序不转换即为所得值（因为采用BCD编码）
        address_code = data_list[7:9]
        logger.info("【报文 A 地址域，其中A1行政区划码】：%s" % address_code)
        address_code.reverse()
        # logger.info(" （1）报文中地址域 A1行政区划码，高低位交换：%s" % address_code)
        address = address_code[0] + address_code[1]
        # logger.info(" （1）报文中地址域 A1行政区划码，即最终BCD编码值：%s" % address)
        if address != '5000':
            logger.error("【错误】 A 地址域 A1行政区划码不匹配，非 5000，请检查!")
            return 0
        else:
            logger.info("【正常】 A 地址域 A1行政区划码：%s" % address)

        # （2）2B：A2可以是单终端地址，也可是终端组地址，取决于A3的D0：（D0=1，A2表示组地址；D0=0，表示A2是单终端地址）
        # （3）1B：A3主站地址和组地址标志
        terminal_flag = data_list[11]
        # hex_terminal_flag = '0x' + terminal_flag
        hex_terminal_flag = bin(eval('0x' + terminal_flag))  # 二进制
        # logger.info(" （2.1）采集项%s 的byte1，转换为二进制：%s" % (type, hex_terminal_flag))
        hex_terminal_flag = hex_terminal_flag[2:]
        # logger.info(" （2.1）采集项%s 的byte1，转换为二进制最终值：%s" % (type, hex_terminal_flag))
        if len(hex_terminal_flag) != 8:
            append_string = self.generate_append_string(len(hex_terminal_flag))
        else:
            append_string = ''
        hex_terminal_flag = append_string + hex_terminal_flag[0:]
        logger.info("【报文 A 地址域，其中A3单/组终端，转换为二进制补位最终值】：%s" % hex_terminal_flag)
        # bin_terminal_flag = bin(eval(hex_terminal_flag))
        # logger.info(" （2）报文中地址域 A3，转换为二进制：%s" % hex_terminal_flag)
        # A3的D0位为终端组地址标志，D0=0表示终端地址A2为单地址；D0=1表示终端地址A2为组地址
        if hex_terminal_flag[-1] != '0':
            logger.error("【正常】 A 地址域 A3的D0=0，组终端，请检查端口!")
            return 0
        else:
            logger.info("【正常】 A 地址域 A3的D0=1，单终端!")
        # A3的D1～D7组成0～127个主站地址MSA
        msa = hex_terminal_flag[1:]
        int_msa = int(msa, 2)
        logger.info("【正常】 A 地址域 A3的D1-D7，即MSA：%s" % int_msa)
        print("【正常】 A 地址域 A3的D1-D7，即MSA：%s" % int_msa)

        # （2）2B：A2可以是单终端地址（实际字节反序并转换成10进制，A1+A2组成实际终端地址），也可是终端组地址
        terminal_address = data_list[9:11]
        logger.info("【报文 A 地址域，其中A2终端地址】：%s" % terminal_address)
        terminal_address.reverse()
        # logger.info(" （3）报文中地址域 A2终端地址，高低位交换：%s" % terminal_address)
        tmp_list = ['0x' + item for item in terminal_address]
        tmp_list = [bin(eval(item)) for item in tmp_list]
        # logger.info(" （3）报文中地址域 A2终端地址，高低位交换，再转换为二进制：%s" % tmp_list)
        bin_terminal_address = tmp_list[0] + tmp_list[1][2:]
        # logger.info(" （3）报文中地址域 A2终端地址，高低位交换，再转换为二进制，组合：%s" % bin_terminal_address)

        if bin_terminal_address == "0000H":
            logger.info("【正常】 A 地址域 A2=0000H，无效地址")
        elif bin_terminal_address == "FFFFH" and hex_terminal_flag[-1] == "1":
            logger.info("【正常】 A 地址域 A2=FFFFH且A3的D0位为“1”时表示系统广播地址")
        else:
            terminal_address = int(bin_terminal_address, 2)
            # logger.info(" （3）报文中地址域 A2终端地址，高低位交换，再转换为二进制，组合，再转换为十进制：%s" % terminal_address)
            terminal_address = str(terminal_address)  # 纯终端地址A2
            logger.info("【正常】 A 地址域 A2终端：%s" % terminal_address)
        terminal_address = address + str(terminal_address)  # 终端地址由A1+A2组成
        logger.info("【正常】 A 地址域 终端地址：%s" % terminal_address)
        print("【正常】 A 地址域 终端地址：%s" % terminal_address)

    # 【检查】：AFN（应用功能码）
    def check_AFN(self, data_list):
        func_code = data_list[12]
        logger.info("【报文 AFN 应用功能码】：%s" % func_code)
        func_dict = {'00': '确认/否认',
                     '01': '复位',
                     '02': '链路接口检查',
                     '03': '中继站命令',
                     '04': '设置参数',
                     '05': '控制命令',
                     '06': '身份认证及密钥协商',
                     '07': '备用', '08': '请求被级联终端主动上报',
                     '09': '请求终端配置',
                     '10': '数据转发',
                     '0a': '查询参数',
                     '0b': '请求任务数据',
                     '0c': '请求/发送1类数据（实时数据）',
                     '0d': '请求/发送2类数据（历史数据）',
                     '0e': '请求/发送3类数据（事件数据）',
                     '0f': '文件传输',
                     '0A': '查询参数',
                     '0B': '请求任务数据',
                     '0C': '请求/发送1类数据（实时数据）',
                     '0D': '请求/发送2类数据（历史数据）',
                     '0E': '请求/发送3类数据（事件数据）',
                     '0F': '文件传输'
                     }
        if func_code in list(func_dict.keys()):
            print("【检查】 AFN 应用功能码：%s,表示：{ %s }" % (func_code, func_dict[func_code]))
            logger.info("【检查】 AFN 应用功能码：%s,表示：{ %s }" % (func_code, func_dict[func_code]))
        else:
            logger.error("【检查】 AFN 应用功能码：%s 不匹配" % func_code)
            print("【检查】 AFN 应用功能码：%s 不匹配" % func_code)
        return func_code

    # 【检查】：SEQ（帧序列域）
    def check_SEQ(self, data_list):
        # （1）转换SEQ为二进制
        SEQ = data_list[13]
        logger.info("【报文 SEQ 帧序列域】：%s" % SEQ)
        bin_SEQ = bin(eval('0x' + SEQ))
        # logger.info(" （2）报文中帧序列域 SEQ，转换为二进制：%s" % bin_SEQ)
        bin_SEQ = bin_SEQ[2:]
        # logger.info(" （3）报文中帧序列域 SEQ，转换为二进制最终值，：%s" % bin_SEQ)
        # 如果bin_SEQ小于8位补齐0
        if len(bin_SEQ) != 8:
            append_string = self.generate_append_string(len(bin_SEQ))
        else:
            append_string = ''
        bin_SEQ = append_string + bin_SEQ
        logger.info("【正常】 SEQ 帧序列域，转换为二进制 %s" % bin_SEQ)

        # (2) D7位，报文是否有时间标签Tp
        if bin_SEQ[0] == '1':
            logger.info("【正常】 SEQ 帧序列域 D7：帧时间标签有效位TpV=1，AUX中有时间标签Tp")
        else:
            logger.info("【正常】 SEQ 帧序列域 D7：帧时间标签有效位TpV=0，AUX中无时间标签Tp")

        # （3） D6位（首）、D5位（尾），报文位置，是否为首尾报文或是中间报文
        if bin_SEQ[1] == '0' and bin_SEQ[2] == '0':
            logger.info("【正常】 SEQ 帧序列域 首末帧标志 D6：FIR=0，D5：FIN=0，多帧报文的中间帧报文！")
        elif bin_SEQ[1] == '0' and bin_SEQ[2] == '1':
            logger.info("【正常】 SEQ 帧序列域 首末帧标志 D6：FIR=0，D5：FIN=1，多帧报文的最后1帧报文！")
        elif bin_SEQ[1] == '1' and bin_SEQ[2] == '0':
            logger.info("【正常】 SEQ 帧序列域 首末帧标志 D6：FIR=1，D5：FIN=0，多帧报文的第1帧报文，有后续帧！")
        else:
            logger.info("【正常】 SEQ 帧序列域 首末帧标志 D6：FIR=1，D5：FIN=1，单帧报文！")

        # （4） D4位，报文是否需要确认/响应
        if bin_SEQ[3] == '1':
            logger.info("【正常】 SEQ 帧序列域 D4：请求确认标志位CON=1，该帧报文需进行确认！")
            print("【正常】 SEQ 帧序列域 D4：请求确认标志位CON=1，该帧报文需进行确认！")
        else:
            logger.info("【正常】 SEQ 帧序列域 D4：请求确认标志位CON=0，该帧报文不需要进行确认！")
            print("【正常】 SEQ 帧序列域 D4：请求确认标志位CON=0，该帧报文不需要进行确认！")

        # （5）D3-D0位 ，报文PSEQ（启动帧序号）/RSEQ（响应帧序号）
        logger.info("-------------- C ：检查控制域 1B --------------")
        DIR = self.check_control_bytes_C(data_list)
        PSEQ_RSEQ = bin_SEQ[4:]  # PSEQ，取自PFC（1B）的低4位；RSEQ第一个响应序号来自PSEQ，此后依次累加
        int_PSEQ_RSEQ = (int(PSEQ_RSEQ, 2))
        if DIR == "0":  # 0表示主站发出的下行报文
            logger.info("【正常】 SEQ 帧序列域 D0-D3：下行，响应帧序号RSEQ：%s" % int_PSEQ_RSEQ)
            print("【正常】 SEQ 帧序列域 D0-D3：下行，响应帧序号RSEQ：%s" % int_PSEQ_RSEQ)
        elif DIR == "1":  # 1表示终端发出的上行报文
            logger.info("【正常】 SEQ 帧序列域 D0-D3：上行，PSEQ启动帧序号：%s" % int_PSEQ_RSEQ)
            print("【正常】 SEQ 帧序列域 D0-D3：上行，PSEQ启动帧序号：%s" % int_PSEQ_RSEQ)
        # PSEQ_RSEQ = bin_SEQ[4:]  # PSEQ，取自PFC（1B）的低4位；RSEQ第一个响应序号来自PSEQ，此后依次累加
        # int_PSEQ_RSEQ = (int(PSEQ_RSEQ, 2))
        # logger.info("【正常】 SEQ 帧序列域 D0-D3：PSEQ（启动帧序号-上行）/RSEQ（响应帧序号-下行）：%s" % int_PSEQ_RSEQ)
        # print("【正常】 SEQ 帧序列域 D0-D3：PSEQ（启动帧序号-上行）/RSEQ（响应帧序号-下行）：%s" % int_PSEQ_RSEQ)

    def test_tmp(self, data_list):
        logger.info("\n-------------- 缺位补位 --------------")
        self.generate_append_string(6)
        # logger.info(str)
        logger.info("\n-------------- L：第一部分，是否适用本协议 --------------")
        self.check_protocol("30 52")
        # self.check_protocol("4574")
        logger.info("\n-------------- L：第二部分，用户数据长度 --------------")
        self.calculate_length("30 52")
        logger.info("\n-------------- L：检查长度是否匹配 --------------")
        self.compare_length(data_list, 90)
        logger.info("-------------- C ：检查控制域 1B --------------")
        self.check_control_bytes_C(data_list)

    # 1、analyze：固定报文
    def test_analyze_default(self, data_list):
        logger.info("-------------- 固定头 ：检查 1B+1B+1B -------------")
        self.check_fixed(data_list)
        logger.info("-------------- L ：检查长度 2B --------------")
        self.check_length_L(data_list)
        logger.info("-------------- CS ：检查校验和 1B --------------")
        self.check_checks_sum_CS(data_list)
        logger.info("-------------- A ：检查地址域 5B --------------")
        self.check_address_bytes_A(data_list)
        logger.info("-------------- AFN ：检查报文作用 1B --------------")
        self.check_AFN(data_list)
        logger.info("-------------- SEQ ：检查 1B --------------")
        self.check_SEQ(data_list)


if __name__ == '__main__':
    analyze_default = AnalyzeDefault()
    # 1、读取报文（完整）
    # data_list = analyze_base.get_data_list_conf("baowen00H")
    # data_list = analyze_base.get_data_list_conf("baowen02H")
    # data_list = analyze_base.get_data_list_conf("baowen04H")
    data_list = analyze_base.get_data_list_conf("baowen0dH")

    # 2、解析报文：固定部分及整体含义
    analyze_default.test_analyze_default(data_list)
