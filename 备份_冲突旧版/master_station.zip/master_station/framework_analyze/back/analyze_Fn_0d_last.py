#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from master_station.framework.analyze.analyze_Fn_0d_full import AnalyzeFnOdFull
from master_station.framework.define.analyze_Fn_0d_base import AnalyzeFnOdBase

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_define import AnalyzeFnOdDefine
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework_analyze.analyze_default import AnalyzeDefault
from master_station.framework_analyze.analyze_default2 import AnalyzeDefault2
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnOdAll").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_default = AnalyzeDefault()
analyze_default2 = AnalyzeDefault2()
analyze_fn_0d_base = AnalyzeFnOdBase()
analyze_fn_0d_define = AnalyzeFnOdDefine()
analyze_fn_0d_full = AnalyzeFnOdFull()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 暂未实现
# 【解析】 针对AFN=0dH的完整报文：同时得到所有采集项的值：curveValue
class AnalyzeFnOdLast(object):

    def get_Fn_0d_last(self, data_list):
        result = analyze_default2.check_biaoshi(data_list)
        Fn = result[0]
        a = result[2]  # if str(result[2]) == "01":  print("pass")
        b = result[3]
        c = result[4]
        d = result[5]
        type_dict = {77: "'01', '01', '10', '09'",
                     78: "'01', '01', '20', '09'",
                     79: "'01', '01', '40', '09'"
                     }
        print("=============")
        if Fn in list(type_dict.keys()):
            data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 18
            sj_list = data_list[data_start_index - 4:]
            for type_dict[Fn] in sj_list:
                if (a == "01") and (b == "01") and (c == "10") and (d == "09"):  # type == 77
                    print("1111111111")
                    print(sj_list)
                    analyze_fn_0d_full.test_analyze_fn(data_list)
                elif (a == "01") and (b == "01") and (c == "20") and (d == "09"):  # type == 78
                    print("222222222")
                    print(sj_list)
                    analyze_fn_0d_full.test_analyze_fn(data_list)
                break


                # for str in data_list:
                # if (a == "01") and (b == "01") and (c == "20") and (d == "09"):  # type == 78
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 32
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "09"):  # type == 79
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 46
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "09"):  # type == 80
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 60
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0a"):  # type == 81
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 74
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0a"):  # type == 82
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 88
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "09"):  # type == 83
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 102
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0a"):  # type == 84
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 116
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0a"):  # type == 85
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 130
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0a"):  # type == 86
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 144
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0a"):  # type == 87
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 158
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0a"):  # type == 88
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 172
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0b"):  # type == 89
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 186
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0b"):  # type == 90
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 199
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "0b"):  # type == 91
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 212
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0b"):  # type == 92
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 225
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0b"):  # type == 93
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 239
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0b"):  # type == 94
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 253
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0b"):  # type == 95
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 267
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0b"):  # type == 96
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 281
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0c"):  # type == 101
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 294
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0c"):  # type == 102
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 309
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0c"):  # type == 103
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 324
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0c"):  # type == 104
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 339
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0d"):  # type == 105
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 354
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0d"):  # type == 106
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 367
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "0d"):  # type == 107
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 380
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0d"):  # type == 108
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 393
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list


# 自测
if __name__ == '__main__':
    analyze_fn_0d_last = AnalyzeFnOdLast()
    data_list = analyze_base.get_data_list_conf("baowen0dH")  # 读取报文  # logger.info(list(enumerate(data_list)))
    analyze_fn_0d_last.get_Fn_0d_last(data_list)
