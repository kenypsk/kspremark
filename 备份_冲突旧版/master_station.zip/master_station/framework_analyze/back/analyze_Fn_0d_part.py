#!/usr/bin/python
# coding: utf-8
from master_station.framework.analyze.analyze_Fn_0d_full import AnalyzeFnOdFull

from logger_demo.framework.log.logger import Logger
from master_station.framework.common.analyze_base import AnalyzeBase
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnOdPart").getlog()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_fn_0d_full = AnalyzeFnOdFull()
analyze_base = AnalyzeBase()


# 【解析】 针对AFN=0dH手动修改为单个采集项报文：Fn解析，最终得到curveValue
class AnalyzeFnOdPart(object):

    # 检查AFN = 0dH：数据单元标识（4B）从左至右： DA1，DA2，DT1，DT2，返回Pn、Fn
    def check_biaoshi(self, data_list):
        data_dict = {'01': '1',
                     '02': '2',
                     '04': '3',
                     '08': '4',
                     '10': '5',
                     '20': '6',
                     '40': '7',
                     '80': '8'
                     }

        biao_shi = data_list[14:18]
        logger.info("【报文 数据单元标识】：%s" % biao_shi)

        # （1）转换DA2为二进制
        biao_shi_DA2 = data_list[15]
        # logger.info(" （2）报文中数据单元标识 DA2：%s" % biao_shi_DA2)
        bin_biao_shi_DA2 = bin(eval('0x' + biao_shi_DA2))
        # logger.info(" （2）报文中数据单元标识 DA2，转换为二进制：%s" % bin_biao_shi_DA2)
        bin_biao_shi_DA2 = bin_biao_shi_DA2[2:]
        # logger.info(" （3）报文中数据单元标识 DA2，转换为二进制最终值：%s" % bin_biao_shi_DA2)
        int_biao_shi_DA2 = int(bin_biao_shi_DA2, 2)
        # logger.info(" （4）报文中数据单元标识 DA2，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DA2)
        # （2）转换DA1为二进制
        biao_shi_DA1 = data_list[14]
        # logger.info(" （1）报文中数据单元标识 DA1：%s" % biao_shi_DA1)
        if biao_shi_DA1 in list(data_dict.keys()):
            result_DA1 = data_dict[biao_shi_DA1]
            # logger.info("【正常】 DA1 对照表，DA1十六进制值：%s,对应 DA1真实值： %s" % (biao_shi_DA1, int(result_DA1)))
            Pn = (int_biao_shi_DA2 - 1) * 8 + int(result_DA1)  # Pn计算公式： (DA2 - 1) * 8 + DA1对应的值就是信息点标识pn
            logger.info("【正常】 计算出Pn的值：%d，其中DA2值：%d，DA1值：%d" % (Pn, int_biao_shi_DA2, int(result_DA1)))
            # return Pn
        else:
            logger.error("【错误】 DA1 对照表，其中DA1不在对照表内")

        # （3）转换DT2为二进制
        biao_shi_DT2 = data_list[17]
        # logger.info(" （4）报文中数据单元标识 DT2：%s" % biao_shi_DT2)
        bin_biao_shi_DT2 = bin(eval('0x' + biao_shi_DT2))
        # logger.info(" （2）报文中数据单元标识 DT2，转换为二进制：%s" % bin_biao_shi_DT2)
        bin_biao_shi_DT2 = bin_biao_shi_DT2[2:]
        # logger.info(" （3）报文中数据单元标识 DT2，转换为二进制最终值：%s" % bin_biao_shi_DT2)
        int_biao_shi_DT2 = int(bin_biao_shi_DT2, 2)
        # logger.info(" （4）报文中数据单元标识 DT2，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DT2)
        # （4）转换DT1为二进制
        biao_shi_DT1 = data_list[16]
        # logger.info(" （3）报文中数据单元标识 DT1：%s" % biao_shi_DT1)
        if biao_shi_DT1 in list(data_dict.keys()):
            result_DT1 = data_dict[biao_shi_DT1]
            # logger.info("【正常】 DT1 对照表，DT1十六进制值：%s,对应 DT1真实值： %s" % (biao_shi_DT1, int(result_DT1)))
            Fn = int_biao_shi_DT2 * 8 + int(result_DT1)  # Fn计算公式：DT2 * 8 + DT1对应的值就是信息类标识Fn
            logger.info("【正常】 计算出Fn的值：%d，其中DT2值：%d，DT1值：%d" % (Fn, int_biao_shi_DT2, int(result_DT1)))
            # return Fn
        else:
            logger.error("【错误】 DT1 对照表，其中DT1不在对照表内")
        # print(Pn, Fn)
        return Fn, Pn, biao_shi

    # 检查：根据Pn、Fn解析具体数据含义:得到curveValue
    def check_Pn_Fn(self, data_list, type):
        Pn_Fn = self.check_biaoshi(data_list)
        Fn = Pn_Fn[0]
        Pn = Pn_Fn[1]
        biao_shi = Pn_Fn[2]
        print("【计算】 最终 Fn 值：%s，Pn值：%s，数据标识：%s" % (Fn, Pn, biao_shi))
        logger.info("【计算】 最终 Fn 值：%s，Pn值：%s，数据标识：%s" % (Fn, Pn, biao_shi))
        analyze_fn_0d_full.test_analyze_fn(data_list, type)

    # 检查 AUX： PW + EC + Tp（不同报文可以其中部分内容）
    def check_AUX(self, data_list):
        if data_list.__len__() > 44:
            # （1）转换 PW（16B） 为二进制
            # PW（16B）用于重要下行报文，由主站系统产生并下发给终端；终端进行校验：通过则响应主站命令，不通过则否认
            PW = data_list[-26:-10]
            logger.info("【报文 AUX中的 PW】：%s" % PW)

            # （2）转换 EC（2B） 为二进制
            # EC（2B）= EC1(重要事件计数器) + EC2（一般事件计数器），用于上行响应报文中，各暂1字节
            EC = data_list[-10:-8]
            logger.info("【报文 AUX中的 EC】：%s" % EC)
            EC1 = data_list[-10]
            logger.info(" （2）报文中AUX中EC的 EC1（重要事件计数器）：%s" % EC1)
            EC2 = data_list[-9]
            logger.info(" （2）报文中AUX中EC的 EC2（一般事件计数器）：%s" % EC2)

            # （3）转换 Tp（6B） 为二进制
            # Tp（6B）=启动帧帧序号器PFC（1B）+启动帧发送时标（4B）+允许发送传输延时时间（1B）
            # Tp由启动站产生并通过报文传送给从动站，从动站据此判决收到的报文的时序和时效性，如判别有效，从动站发送响应帧，并在响应帧中将时间标签Tp返回启动站。
            Tp = data_list[-8:-2]
            logger.info("【报文 AUX中的 Tp】：%s" % Tp)
            PFC = data_list[-8]
            logger.info(" （3）报文中AUX中Tp的 PFC（启动帧帧序号器）：%s" % PFC)
            qdzfssb = data_list[-7:-3]
            logger.info(" （3）报文中AUX中Tp的 qdzfssb（启动帧发送时标）：%s" % qdzfssb)
            yxfscsyssj = data_list[-3]
            logger.info(" （3）报文中AUX中Tp的 yxfscsyssj（允许发送传输延时时间）：%s" % yxfscsyssj)
        else:
            logger.error("【异常】 不满足获取AUX的条件")

    # 2、analyze_Fn_data：Fn计算值
    def test_analyze_fn_0d_part(self, data_list, type):
        # 测试解析单组：数据标识 + 数据
        logger.info("-------------- 单组：数据单元标识 + 数据 --------------")
        self.check_Pn_Fn(data_list, type)


# 自测
if __name__ == '__main__':
    analyze_fn_od_part = AnalyzeFnOdPart()
    data_list = analyze_base.get_data_list_conf("baowen0dH")  # 读取手动修改单个采集项报文 81、82、83...108
    analyze_fn_od_part.test_analyze_fn_0d_part(data_list, 89)
