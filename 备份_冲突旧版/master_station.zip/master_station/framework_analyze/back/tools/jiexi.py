#!/usr/bin/python
# coding: utf-8
# from analyze.analyze_frame import AnalyzeFrame
# from analyze.jiexi_Fn import JieXiFn
# j_fn = JieXiFn()


class JieXi(object):

    # 检查 AUX： PW + EC + Tp（不同报文可以其中部分内容）
    def check_AUX(self, data_list):
        if data_list.__len__() > 44:
            # （1）转换 PW（16B） 为二进制
            # PW（16B）用于重要下行报文，由主站系统产生并下发给终端；终端进行校验：通过则响应主站命令，不通过则否认
            PW = data_list[-26:-10]
            print(" （1）报文中AUX中的 PW：%s" % PW)

            # （2）转换 EC（2B） 为二进制
            # EC（2B）= EC1(重要事件计数器) + EC2（一般事件计数器），用于上行响应报文中，各暂1字节
            EC = data_list[-10:-8]
            print(" （2）报文中AUX中的 EC：%s" % EC)
            EC1 = data_list[-10]
            print(" （2）报文中AUX中EC的 EC1（重要事件计数器）：%s" % EC1)
            EC2 = data_list[-9]
            print(" （2）报文中AUX中EC的 EC2（一般事件计数器）：%s" % EC2)

            # （3）转换 Tp（6B） 为二进制
            # Tp（6B）=启动帧帧序号器PFC（1B）+启动帧发送时标（4B）+允许发送传输延时时间（1B）
            # Tp由启动站产生并通过报文传送给从动站，从动站据此判决收到的报文的时序和时效性，如判别有效，从动站发送响应帧，并在响应帧中将时间标签Tp返回启动站。
            Tp = data_list[-8:-2]
            print(" （3）报文中AUX中的 Tp：%s" % Tp)
            PFC = data_list[-8]
            print(" （3）报文中AUX中Tp的 PFC（启动帧帧序号器）：%s" % PFC)
            qdzfssb = data_list[-7:-3]
            print(" （3）报文中AUX中Tp的 qdzfssb（启动帧发送时标）：%s" % qdzfssb)
            yxfscsyssj = data_list[-3]
            print(" （3）报文中AUX中Tp的 yxfscsyssj（允许发送传输延时时间）：%s" % yxfscsyssj)
        else:
            print("【异常】不满足获取AUX的条件")


if __name__ == '__main__':
    fp = open('data.txt', 'r')
    # data = "68 32 06 32 06 68 c4 00 50 9a 39 00 0d 72 01 01 01 0a 30 10 24 02 18 01 01 88 01 00 01 01 02 0a 30 10 24 02 18 01 01 88 01 00 01 01 04 0a 30 10 24 02 18 01 01 ee ee ee 01 01 08 0a 30 10 24 02 18 01 01 ee ee ee 01 01 10 0a 30 10 24 02 18 01 01 ee ee ee 01 01 20 0a 30 10 24 02 18 01 01 ee ee ee 01 01 40 0a 30 10 24 02 18 01 01 ee ee ee 01 01 80 0a 30 10 24 02 18 01 01 ee ee ee 01 01 01 0b 30 10 24 02 18 01 01 44 22 01 01 02 0b 30 10 24 02 18 01 01 ee ee 01 01 04 0b 30 10 24 02 18 01 01 ee ee 01 01 08 0b 30 10 24 02 18 01 01 83 00 00 01 01 10 0b 30 10 24 02 18 01 01 ee ee ee 01 01 20 0b 30 10 24 02 18 01 01 ee ee ee 01 01 40 0b 30 10 24 02 18 01 01 83 00 00 01 01 80 0b 30 10 24 02 18 01 01 00 00 01 01 10 0c 30 10 24 02 18 01 01 62 38 01 00 01 01 20 0c 30 10 24 02 18 01 01 ee ee ee ee 01 01 40 0c 30 10 24 02 18 01 01 28 00 00 00 01 01 80 0c 30 10 24 02 18 01 01 ee ee ee ee 01 01 01 0d 30 10 24 02 18 01 01 00 10 01 01 02 0d 30 10 24 02 18 01 01 00 10 01 01 04 0d 30 10 24 02 18 01 01 ff ff 01 01 08 0d 30 10 24 02 18 01 01 ff ff b8 16"
    raw_data = fp.read()
    data_list = raw_data.split()
    t = JieXi()
    print("\n-------------- 多组：数据单元标识 + 数据 --------------")
    t.check_Pn_Fn(data_list)
