#!/usr/bin/python
# coding: utf-8

import datetime
from copy import copy
from xlrd import open_workbook

# time
nowTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # 现在
pastTime = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')  # 过去一小时时间
afterTomorrowTime = (datetime.datetime.now() + datetime.timedelta(days=2)).strftime('%Y-%m-%d %H:%M:%S')  # 后天
tomorrowTime = (datetime.datetime.now() + datetime.timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')  # 明天
print('\n', nowTime, '\n', pastTime, '\n', afterTomorrowTime, '\n', tomorrowTime)


# 读取from beforeRemove.txt的数据到afterRemove.txt
fp = open('beforeRemove.txt', 'r')
raw_data = fp.read()
fpw = open('afterRemove.txt', 'w')
strdata = raw_data.split()
str_value = ''
for i in strdata: str_value = str_value + i
fpw.write(str_value)
fp.close()
fpw.close()


# [no]
def append_excel(path_name):
    # write_excel()
    book = open_workbook("baowen.xls")
    wfile = copy(book)  # 在内存中复制
    wsheet = wfile.get_sheet('sheet1')
    wsheet.write(2, 1, 'new_new_new')  # 在第3行第2列添加新数据'new_new_new'
    wfile.save("new_baowen.xls")


# 3、构建数据报文（1条）
def generate_data_frame_ok(self, te_address, hang):
    raw_data = '68 32 06 32 06 68 c4 00 50 9a 39 00 0d 7f ' \
                   '01 01 10 09 15 00 14 03 18 01 01 ee ee ee 01 01 20 09 15 00 14 03 18 01 01 ee ee ee 01 01 40 09 15 00 14 03 18 01 01 ee ee ee 01 01 80 09 15 00 14 03 18 01 01 ee ee ee ' \
                   '01 01 01 0a 15 00 14 03 18 01 01 23 01 00 01 01 02 0a 15 00 14 03 18 01 01 23 01 00 01 01 04 0a 15 00 14 03 18 01 01 ee ee ee 01 01 08 0a 15 00 14 03 18 01 01 ee ee ee ' \
                   '01 01 10 0a 15 00 14 03 18 01 01 ee ee ee 01 01 20 0a 15 00 14 03 18 01 01 ee ee ee 01 01 40 0a 15 00 14 03 18 01 01 ee ee ee 01 01 80 0a 15 00 14 03 18 01 01 ee ee ee ' \
                   '01 01 01 0b 15 00 14 03 18 01 01 91 22 01 01 02 0b 15 00 14 03 18 01 01 ee ee 01 01 04 0b 15 00 14 03 18 01 01 ee ee 01 01 08 0b 15 00 14 03 18 01 01 53 00 00 ' \
                   '01 01 10 0b 15 00 14 03 18 01 01 ee ee ee 01 01 20 0b 15 00 14 03 18 01 01 ee ee ee 01 01 40 0b 15 00 14 03 18 01 01 54 00 00 01 01 80 0b 15 00 14 03 18 01 01 00 00 ' \
                   '01 01 10 0c 15 00 14 03 18 01 01 93 52 01 00 01 01 20 0c 15 00 14 03 18 01 01 ee ee ee ee 01 01 40 0c 15 00 14 03 18 01 01 28 00 00 00 01 01 80 0c 15 00 14 03 18 01 01 ee ee ee ee ' \
                   '01 01 01 0d 15 00 14 03 18 01 01 00 10 01 01 02 0d 15 00 14 03 18 01 01 00 10 01 01 04 0d 15 00 14 03 18 01 01 ff ff 01 01 08 0d 15 00 14 03 18 01 01 ff ff d6 16'
    raw_list = raw_data.split()
    sam_data_head = raw_list[:7]
    sam_data_end = ['16']
    sam_data_shuju = raw_list[11:-2]
    temp_CS = ['xx']
    temp_frame = sam_data_head + te_address + sam_data_shuju + temp_CS + sam_data_end
    temp_CS[0] = self.calculate_CS(temp_frame)
    # print(temp_CS)
    temp_frame = sam_data_head + te_address + sam_data_shuju + temp_CS + sam_data_end
    # print(temp_frame)
    data_frame = ''
    for item in temp_frame:
        data_frame = data_frame + item
    # print(data_frame)
    self.table.write(hang, 16, data_frame)
