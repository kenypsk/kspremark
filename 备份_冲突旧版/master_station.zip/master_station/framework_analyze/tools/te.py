#!/usr/bin/python
# coding: utf-8

import re

# list = "68 32 06 32 06 68 c4 00 50 9a 39 00 0d 72 01 01 10 09 15 15 24 02 18 01 01 ee ee ee 01 01 20 09 15 15 24 02 18 01 01 ee ee ee 01 01 40 09 15 15 24 02 18 01 01 ee ee ee 01 01 80 09 15 15 24 02 18 01 01 ee ee ee 01 01 01 0a 15 15 24 02 18 01 01 26 01 00 01 01 02 0a 15 15 24 02 18 01 01 26 01 00 01 01 04 0a 15 15 24 02 18 01 01 ee ee ee 01 01 08 0a 15 15 24 02 18 01 01 ee ee ee 01 01 10 0a 15 15 24 02 18 01 01 ee ee ee 01 01 20 0a 15 15 24 02 18 01 01 ee ee ee 01 01 40 0a 15 15 24 02 18 01 01 ee ee ee 01 01 80 0a 15 15 24 02 18 01 01 ee ee ee 01 01 01 0b 15 15 24 02 18 01 01 68 22 01 01 02 0b 15 15 24 02 18 01 01 ee ee 01 01 04 0b 15 15 24 02 18 01 01 ee ee 01 01 08 0b 15 15 24 02 18 01 01 55 00 00 01 01 10 0b 15 15 24 02 18 01 01 ee ee ee 01 01 20 0b 15 15 24 02 18 01 01 ee ee ee 01 01 40 0b 15 15 24 02 18 01 01 56 00 00 01 01 80 0b 15 15 24 02 18 01 01 00 00 01 01 10 0c 15 15 24 02 18 01 01 06 39 01 00 01 01 20 0c 15 15 24 02 18 01 01 ee ee ee ee 01 01 40 0c 15 15 24 02 18 01 01 28 00 00 00 01 01 80 0c 15 15 24 02 18 01 01 ee ee ee ee 01 01 01 0d 15 15 24 02 18 01 01 00 10 01 01 02 0d 15 15 24 02 18 01 01 00 10 01 01 04 0d 15 15 24 02 18 01 01 ff ff 01 01 08 0d 15 15 24 02 18 01 01 ff ff fa 16"
# pattern = re.compile(r"01 01 10 09")
# match = pattern.match(list)
#
# # F(a(x(b)), a(c))，depth=2
# ss = "%s" % (match.group(1))
# print(ss)
#
# # pattern = re.compile(r"F\(a\((.*)\), a\((.*)\)\)")
# # match = pattern.match("F(a(x(b)), a(c))")
# # ss = "List = [%s, %s]" % (match.group(1), match.group(2))
# # print(ss)
# # List = [x(b), c]

data_list = ['68', '32', '06', '32', '06', '68', 'c4', '00', '50', '9a', '39', '00', '0d', '72', '01', '01', '01', '0a', '30',
      '10', '24', '02', '18', '01', '01', '88', '01', '00', '01', '01']
# sjbs_sj = data_list[14:]
# print("【数据标识+数据 多组 原报文】：%s" % sjbs_sj)
# print(list(enumerate(sjbs_sj)))

sjbs_sj = ['01', '01', '01', '0a', '30', '10', '24', '02', '18', '01', '01', '88']
print(sjbs_sj)


# d = next((x for x in sjbs_sj if x > "'01', '01', '10', '09'"))
# a = sjbs_sj.index("01")
# b = sjbs_sj.index("01")
# c = sjbs_sj.index("01")
# d = sjbs_sj.index("0a")
# print(a, b, c, d)

# if next((x for x in sjbs_sj if x == sjbs_sj.index("0a"))):
#     print(x)
#     if next(y for y in sjbs_sj if y == sjbs_sj.index("01"))):
#         print(y)
#         if next((z for z in sjbs_sj if z == sjbs_sj.index("10"))):
#             if next((k for k in sjbs_sj if k == sjbs_sj.index("09"))):
#                 print(k)
if sjbs_sj.index("01"):
    if sjbs_sj.index("01"):
        if sjbs_sj.index("10"):
            if sjbs_sj.index("09"):
                print(sjbs_sj.index("09"))

# print(sjbs_sj.index("'01', '01', '10', '09'"))
# print([i for i, x in enumerate(sjbs_sj) if x == 9])
if sjbs_sj[:4] == ['01', '01', '10', '09']:  # 77
    type = 77
    # self.test_analyze_fn(data_list, type)
elif sjbs_sj == ['01', '01', '20', '09']:  # 78
    type = 78
    # self.test_analyze_fn(data_list, type)


dd = "68"
if eval(dd) == 68:
    print("相等")


# 10 进制转16进制: hex(16) == > 0x10
# 16 进制转10进制: int('0x10', 16) == > 16
# 1、int() 可以将 二进制，八进制，十六进制转换成十进制整型
# >>> int('1111', 2)     15
# >>> int('0xf', 16)       15
# >>> int('17', 8)       15
# 2、hex() 将十进制转换为十六进制
# >>> hex(255)  '0xff'
# 3、bin() 将十进制转换为二进制
#  >>> bin(255)  '0b11111111


