#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_base import AnalyzeFnOdBase
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot

logger = Logger(logger="AnalyzeFnO0Base").getlog()
base_conf = BaseConf()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_0d_base = AnalyzeFnOdBase()


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnO0Base(object):

    # 【检查】：Fn的含义
    def check_00_Fn(self, data_list):  # 拆分、完整报文
        Fn = analyze_fixed_not.get_Fn(data_list)
        return Fn

    # 【检查】：EC 事件计数器（2B）：重要事件计数器EC1（1B）、 一般事件计数器EC2（1B）
    def check_00_EC(self, data_list):
        # try:
            result = analyze_fixed.check_control_bytes_C(data_list)
            C_D5_ACD = result[2]
            if C_D5_ACD == "1":  # 只有ACD=1上行报文，才有EC
                logger.info("【组成】：事件计数器EC（2B）：重要事件计数器EC1（1B）、 一般事件计数器EC2（1B）")
                EC1 = data_list[-6:-4]
                logger.info("【事件计数器EC（2B） 原报文】 :%s" % EC1)

                # （1）重要事件计数器EC1（1B）
                EC1 = data_list[-6]
                logger.info("【事件计数器EC，其中重要事件计数器EC1 原报文】：%s" % EC1)
                logger.info(" （1.1）重要事件计数器EC1  的byte：%s" % EC1)
                bin_EC1 = bin(eval('0x' + EC1))
                logger.info(" （1.1）重要事件计数器EC1 转换为二进制：%s" % bin_EC1)
                bin_EC1 = bin_EC1[2:]
                logger.info(" （1.1）重要事件计数器EC1 转换为二进制最终值：%s" % bin_EC1)
                if len(bin_EC1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_EC1))
                else:
                    append_string = ''
                bin_EC1 = append_string + bin_EC1[0:]
                logger.info(" （1.1）重要事件计数器EC1 转换为二进制补位最终值：%s" % bin_EC1)
                int_EC1 = int(bin_EC1, 2)
                logger.info(" （1.1）重要事件计数器EC1 转换为二进制最终值，再转换为十进制：%s" % int_EC1)

                # （2）重要事件计数器EC2（1B）
                EC2 = data_list[-5]
                logger.info("【事件计数器EC，其中重要事件计数器EC2 原报文】：%s" % EC2)
                logger.info(" （1.2）重要事件计数器EC2 的byte：%s" % EC2)
                bin_EC2 = bin(eval('0x' + EC2))
                logger.info(" （1.2）重要事件计数器EC2 转换为二进制：%s" % bin_EC2)
                bin_EC2 = bin_EC2[2:]
                logger.info(" （1.2）重要事件计数器EC2 转换为二进制最终值：%s" % bin_EC2)
                if len(bin_EC2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_EC2))
                else:
                    append_string = ''
                bin_EC2 = append_string + bin_EC2[0:]
                logger.info(" （1.2）重要事件计数器EC2 转换为二进制补位最终值：%s" % bin_EC2)
                int_EC2 = int(bin_EC2, 2)
                logger.info(" （1.2）重要事件计数器EC2 转换为二进制最终值，再转换为十进制：%s" % int_EC2)
                return int_EC1, int_EC2
            else:
                logger.info("【正常】 C_D5_ACD不是1，所以 无时间计数器EC")
                # print("【正常】 C_D5_ACD不是1，所以 无时间计数器EC")
        # except Exception as e:
        #     logger.error("【异常】时间计数器EC，报错：%s" % e)

    # {附录A.16}   时间标签Tp（6B）的启动帧发送时标（4B）
    def check_00_Tp_shibiao_data(self, data_list):
        # try:
            # （2）启动帧发送时标（4B）: 秒（1B）+ 分（1B） + 时（1B） + 日（1B）
            shibiao = data_list[-7:-3]
            logger.info("【时间标签Tp，其中启动帧发送时标 原报文】：%s" % shibiao)
            # （2）启动帧发送时标（4B）：秒（1B）+ 分（1B） + 时（1B） + 日（1B）
            # （2.1） 秒（1B）
            byte1 = data_list[-7]
            logger.info(" （2.1）Tp的启动帧发送时标的byte1：%s" % byte1)
            bin_byte1 = bin(eval('0x' + byte1))
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制：%s" % bin_byte1)
            bin_byte1 = bin_byte1[2:]
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制最终值：%s" % bin_byte1)
            if len(bin_byte1) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte1))
            else:
                append_string = ''
            bin_byte1 = append_string + bin_byte1[0:]
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制补位最终值：%s" % bin_byte1)
            miao_shiwei = bin_byte1[4:]
            # logger.info(miao_shiwei)
            int_miao_shiwei = int(miao_shiwei, 2)
            logger.info(" （2.1）Tp的启动帧发送时标的byte1的秒的十位，转换为二进制最终值，再转换为十进制：%s" % int_miao_shiwei)
            miao_gewei = bin_byte1[0:4]
            # logger.info(miao_gewei)
            int_miao_gewei = int(miao_gewei, 2)
            logger.info(" （2.1）Tp的启动帧发送时标的byte1的秒的个位，转换为二进制最终值，再转换为十进制：%s" % int_miao_gewei)

            # （2.2） 分（1B）
            byte2 = data_list[-6]
            logger.info(" （2.2）Tp的启动帧发送时标的byte2：%s" % byte2)
            bin_byte2 = bin(eval('0x' + byte2))
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制：%s" % bin_byte2)
            bin_byte2 = bin_byte2[2:]
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制最终值：%s" % bin_byte2)
            if len(bin_byte2) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte2))
            else:
                append_string = ''
            bin_byte2 = append_string + bin_byte2[0:]
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制补位最终值：%s" % bin_byte2)
            fen_shiwei = bin_byte2[4:]
            # logger.info(fen_shiwei)
            int_fen_shiwei = int(fen_shiwei, 2)
            logger.info(" （2.2）Tp的启动帧发送时标的byte2的分的十位，转换为二进制最终值，再转换为十进制：%s" % int_fen_shiwei)
            fen_gewei = bin_byte2[0:4]
            # logger.info(fen_gewei)
            int_fen_gewei = int(fen_gewei, 2)
            logger.info(" （2.2）Tp的启动帧发送时标的byte2的分的个位，转换为二进制最终值，再转换为十进制：%s" % int_fen_gewei)

            # （2.3） 时（1B）
            byte3 = data_list[-5]
            logger.info(" （2.3）Tp的启动帧发送时标的byte3：%s" % byte3)
            bin_byte3 = bin(eval('0x' + byte3))
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制：%s" % bin_byte3)
            bin_byte3 = bin_byte3[2:]
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制最终值：%s" % bin_byte3)
            if len(bin_byte3) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte3))
            else:
                append_string = ''
            bin_byte3 = append_string + bin_byte3[0:]
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制补位最终值：%s" % bin_byte3)
            shi_shiwei = bin_byte3[4:]
            # logger.info(shi_shiwei)
            int_shi_shiwei = int(shi_shiwei, 2)
            logger.info(" （2.3）Tp的启动帧发送时标的byte3的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_shi_shiwei)
            shi_gewei = bin_byte3[0:4]
            # logger.info(shi_gewei)
            int_shi_gewei = int(shi_gewei, 2)
            logger.info(" （2.3）Tp的启动帧发送时标的byte3的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_shi_gewei)

            # （2.4）日（1B）
            byte4 = data_list[-4]
            logger.info(" （2.4）Tp的启动帧发送时标的byte4：%s" % byte4)
            bin_byte4 = bin(eval('0x' + byte4))
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制：%s" % bin_byte4)
            bin_byte4 = bin_byte4[2:]
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制最终值：%s" % bin_byte4)
            if len(bin_byte4) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte4))
            else:
                append_string = ''
            bin_byte4 = append_string + bin_byte4[0:]
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制补位最终值：%s" % bin_byte4)
            ri_shiwei = bin_byte4[4:]
            # logger.info(ri_shiwei)
            int_ri_shiwei = int(ri_shiwei, 2)
            logger.info(" （2.4）Tp的启动帧发送时标的byte4的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_ri_shiwei)
            ri_gewei = bin_byte4[0:4]
            # logger.info(ri_gewei)
            int_ri_gewei = int(ri_gewei, 2)
            logger.info(" （2.4）Tp的启动帧发送时标的byte4的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_ri_gewei)

            logger.info("得到时间：%d%d %d%d:%d%d:%d%d" % (int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei,
                int_miao_shiwei, int_miao_gewei))
            return int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei, int_miao_shiwei, int_miao_gewei
        # except Exception as e:
        #     logger.error("【异常】启动帧发送时标，报错：%s" % e)

    # 【检查】：时间标签Tp（6B）：启动帧帧序号计数器PFC（1B）、启动帧发送时标（4B）、 允许发送传输延时时间（1B）：
    def check_00_Tp(self, data_list):
        # try:
            result = analyze_fixed.check_SEQ(data_list)
            SEQ_D7_TpV = result[0]
            if SEQ_D7_TpV == "1":  # 只有TpV等于1的时候，报文才有Tp
                logger.info("【组成】：时间标签Tp（6B）：启动帧帧序号计数器PFC（1B）、启动帧发送时标（4B）、 允许发送传输延时时间（1B）")
                Tp = data_list[-8:-2]
                logger.info("【时间标签Tp（6B） 原报文】 :%s" % Tp)

                # （1）启动帧帧序号计数器PFC（1B）
                PFC = data_list[-8]
                logger.info("【时间标签Tp，其中启动帧帧序号计数器PFC 原报文】：%s" % PFC)
                logger.info(" （1.1）启动帧帧序号计数器PFC  的byte：%s" % PFC)
                bin_PFC = bin(eval('0x' + PFC))
                logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制：%s" % bin_PFC)
                bin_PFC = bin_PFC[2:]
                logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制最终值：%s" % bin_PFC)
                if len(bin_PFC) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_PFC))
                else:
                    append_string = ''
                bin_PFC = append_string + bin_PFC[0:]
                logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制补位最终值：%s" % bin_PFC)
                int_PFC = int(bin_PFC, 2)
                logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制最终值，再转换为十进制：%s" % int_PFC)

                # （2）启动帧发送时标（4B）
                list_shibiao = self.check_00_Tp_shibiao_data(data_list)

                # （3）允许发送传输延时时间（1B）
                yanshi = data_list[-3]
                logger.info("【时间标签Tp，其中允许发送传输延时时间 原报文】：%s" % yanshi)
                logger.info(" （3.1）允许发送传输延时时间  的byte：%s" % yanshi)
                yanshi = bin(eval('0x' + yanshi))
                logger.info(" （3.1）允许发送传输延时时间 转换为二进制：%s" % yanshi)
                yanshi = yanshi[2:]
                logger.info(" （3.1）允许发送传输延时时间 转换为二进制最终值：%s" % yanshi)
                if len(yanshi) != 8:
                    append_string = analyze_base.generate_append_string(len(yanshi))
                else:
                    append_string = ''
                yanshi = append_string + yanshi[0:]
                logger.info(" （3.1）允许发送传输延时时间 转换为二进制补位最终值：%s" % yanshi)
                int_yanshi = int(yanshi, 2)
                logger.info(" （3.1）允许发送传输延时时间 转换为二进制最终值，再转换为十进制：%s" % int_yanshi)

                return int_PFC, list_shibiao, int_yanshi
            else:
                logger.info("【正常】 SEQ_D7_TpV不是1，所以 无时间标签Tp")
                # print("【正常】 SEQ_D7_TpV不是1，所以 无时间标签Tp")
        # except Exception as e:
            # logger.error("【异常】时间标签Tp，报错：%s" % e)


# 自测
if __name__ == '__main__':
    analyze_fn_00_base = AnalyzeFnO0Base()
    # 1、读取报文
    data_list = analyze_base.get_data_list_conf("baowen00H")
    # 2、详解报文
    logger.info("-------------- Fn ：计算 -------------")
    analyze_fn_00_base.check_00_Fn(data_list)
    logger.info("-------------- EC ：检查事件计数器 2B -------------")
    analyze_fn_00_base.check_00_EC(data_list)
    logger.info("-------------- Tp ：检查时间标签 6B -------------")
    analyze_fn_00_base.check_00_Tp(data_list)

    # 暂时未用【检查】：数据单元标识（4B），从左至右： DA1，DA2，DT1，DT2，计算出Pn、Fn
    def check_00_biaoshi(self, data_list):
        analyze_fixed_not.check_biaoshi(data_list)
        # result = analyze_fixed_not.check_biaoshi(data_list)
        # return result

    # 暂时未用 【检查】：Fn的含义
    def check_00_Fn2(self, data_list):  # 拆分、完整报文
        Fn_dict = {1: '全部确认：对收到报文中的全部数据单元标识进行确认', 2: '全部否认：对收到报文中的全部数据单元标识进行否认',
                   3: '按数据单元标识确认和否认：对收到报文中的全部数据单元标识进行逐个确认/否认', 4: '硬件安全认证错误应答',
                   "其他": '备用'}
        result = self.check_00_biaoshi(data_list)
        Fn = result[0]
        Pn = result[1]
        if (Fn in list(Fn_dict.keys())) and (Pn == 0):
            logger.info("【正常】 Fn=%s,Pn=%s，表示{ %s }" % (Fn, Pn, Fn_dict[Fn]))
            print("【正常】 Fn=%s,Pn=%s，表示{ %s }" % (Fn, Pn, Fn_dict[Fn]))
        return Fn, Pn
