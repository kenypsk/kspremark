#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from master_station.framework.afn_04.analyze_Fn_04_define import AnalyzeFnO4Define

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_04.analyze_Fn_04_base import AnalyzeFnO4Base
from master_station.framework.common.analyze_base import AnalyzeBase
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnO4").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fn_04_base = AnalyzeFnO4Base()
analyze_fn_04_define = AnalyzeFnO4Define()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnO4(object):

    # 【汇总】
    def test_analyze_fn_04(self, data_list):
        logger.info("-------------- Fn ：计算 -------------")
        Fn = analyze_fn_04_base.check_04_Fn(data_list)
        logger.info("-------------- Fn ：定义 -------------")
        analyze_fn_04_base.test_analyze_04_fn(data_list, Fn)
        logger.info("-------------- PW ：消息认证码字段 16B -------------")
        analyze_fn_04_base.check_04_PW(data_list)
        logger.info("-------------- Tp ：检查时间标签 6B -------------")
        analyze_fn_04_base.check_04_Tp(data_list)


# 自测
if __name__ == '__main__':
    analyze_fn_04 = AnalyzeFnO4()
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen04H")
    # 2、详解报文
    analyze_fn_04.test_analyze_fn_04(data_list)
