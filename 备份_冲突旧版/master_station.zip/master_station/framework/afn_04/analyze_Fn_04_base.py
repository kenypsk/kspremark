#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from master_station.framework.afn_04.analyze_Fn_04_define import AnalyzeFnO4Define

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_base import AnalyzeFnOdBase
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnO4Base").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_0d_base = AnalyzeFnOdBase()
analyze_fn_04_define = AnalyzeFnO4Define()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnO4Base(object):

    # 【检查】：Fn的含义
    def check_04_Fn(self, data_list):  # 拆分、完整报文
        Fn = analyze_fixed_not.get_Fn(data_list)
        return Fn

    # 【解析】：根据Fn不同的含义，选择解析报文的格式
    # 0.1、define_Fn：Fn定义
    def test_analyze_04_fn(self, data_list, Fn):
        func_code = analyze_fixed.check_AFN(data_list)
        if func_code == "04":
            if Fn in (67, 68):  # 测试 Fn=67/68
                analyze_fn_04_define.check_04_Fn_67_68(data_list)
            if Fn in (65, 66):  # 测试 Fn=65/66
                analyze_fn_04_define.check_04_Fn_65_66(data_list)
            if Fn == 10:  # 测试 Fn=10
                analyze_fn_04_define.check_04_Fn_10(data_list)

    # 附录A.16   时间标签Tp（6B）的启动帧发送时标（4B）
    def check_04_Tp_shibiao_data(self, data_list):
        # try:
            # （2）启动帧发送时标（4B）: 秒（1B）+ 分（1B） + 时（1B） + 日（1B）
            shibiao = data_list[-7:-3]
            logger.info("【原报文：时间标签Tp，其中启动帧发送时标】：%s" % shibiao)
            # （2）启动帧发送时标（4B）：秒（1B）+ 分（1B） + 时（1B） + 日（1B）
            # （2.1） 秒（1B）
            byte1 = data_list[-7]
            logger.info(" （2.1）Tp的启动帧发送时标的byte1：%s" % byte1)
            bin_byte1 = bin(eval('0x' + byte1))
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制：%s" % bin_byte1)
            bin_byte1 = bin_byte1[2:]
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制最终值：%s" % bin_byte1)
            if len(bin_byte1) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte1))
            else:
                append_string = ''
            bin_byte1 = append_string + bin_byte1[0:]
            # logger.info(" （2.1）Tp的启动帧发送时标的byte1，转换为二进制补位最终值：%s" % bin_byte1)
            miao_shiwei = bin_byte1[4:]
            # logger.info(miao_shiwei)
            int_miao_shiwei = int(miao_shiwei, 2)
            logger.info(" （2.1）Tp的启动帧发送时标的byte1的秒的十位，转换为二进制最终值，再转换为十进制：%s" % int_miao_shiwei)
            miao_gewei = bin_byte1[0:4]
            # logger.info(miao_gewei)
            int_miao_gewei = int(miao_gewei, 2)
            logger.info(" （2.1）Tp的启动帧发送时标的byte1的秒的个位，转换为二进制最终值，再转换为十进制：%s" % int_miao_gewei)

            # （2.2） 分（1B）
            byte2 = data_list[-6]
            logger.info(" （2.2）Tp的启动帧发送时标的byte2：%s" % byte2)
            bin_byte2 = bin(eval('0x' + byte2))
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制：%s" % bin_byte2)
            bin_byte2 = bin_byte2[2:]
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制最终值：%s" % bin_byte2)
            if len(bin_byte2) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte2))
            else:
                append_string = ''
            bin_byte2 = append_string + bin_byte2[0:]
            # logger.info(" （2.2）Tp的启动帧发送时标的byte2，转换为二进制补位最终值：%s" % bin_byte2)
            fen_shiwei = bin_byte2[4:]
            # logger.info(fen_shiwei)
            int_fen_shiwei = int(fen_shiwei, 2)
            logger.info(" （2.2）Tp的启动帧发送时标的byte2的分的十位，转换为二进制最终值，再转换为十进制：%s" % int_fen_shiwei)
            fen_gewei = bin_byte2[0:4]
            # logger.info(fen_gewei)
            int_fen_gewei = int(fen_gewei, 2)
            logger.info(" （2.2）Tp的启动帧发送时标的byte2的分的个位，转换为二进制最终值，再转换为十进制：%s" % int_fen_gewei)

            # （2.3） 时（1B）
            byte3 = data_list[-5]
            logger.info(" （2.3）Tp的启动帧发送时标的byte3：%s" % byte3)
            bin_byte3 = bin(eval('0x' + byte3))
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制：%s" % bin_byte3)
            bin_byte3 = bin_byte3[2:]
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制最终值：%s" % bin_byte3)
            if len(bin_byte3) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte3))
            else:
                append_string = ''
            bin_byte3 = append_string + bin_byte3[0:]
            # logger.info(" （2.3）Tp的启动帧发送时标的byte3，转换为二进制补位最终值：%s" % bin_byte3)
            shi_shiwei = bin_byte3[4:]
            # logger.info(shi_shiwei)
            int_shi_shiwei = int(shi_shiwei, 2)
            logger.info(" （2.3）Tp的启动帧发送时标的byte3的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_shi_shiwei)
            shi_gewei = bin_byte3[0:4]
            # logger.info(shi_gewei)
            int_shi_gewei = int(shi_gewei, 2)
            logger.info(" （2.3）Tp的启动帧发送时标的byte3的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_shi_gewei)

            # （2.4）日（1B）
            byte4 = data_list[-4]
            logger.info(" （2.4）Tp的启动帧发送时标的byte4：%s" % byte4)
            bin_byte4 = bin(eval('0x' + byte4))
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制：%s" % bin_byte4)
            bin_byte4 = bin_byte4[2:]
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制最终值：%s" % bin_byte4)
            if len(bin_byte4) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte4))
            else:
                append_string = ''
            bin_byte4 = append_string + bin_byte4[0:]
            # logger.info(" （2.4）Tp的启动帧发送时标的byte4，转换为二进制补位最终值：%s" % bin_byte4)
            ri_shiwei = bin_byte4[4:]
            # logger.info(ri_shiwei)
            int_ri_shiwei = int(ri_shiwei, 2)
            logger.info(" （2.4）Tp的启动帧发送时标的byte4的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_ri_shiwei)
            ri_gewei = bin_byte4[0:4]
            # logger.info(ri_gewei)
            int_ri_gewei = int(ri_gewei, 2)
            logger.info(" （2.4）Tp的启动帧发送时标的byte4的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_ri_gewei)

            logger.info("【计算】 得到时间：%d%d %d%d:%d%d:%d%d" % (
                int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei,
                int_miao_shiwei, int_miao_gewei))
            return int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei, int_miao_shiwei, int_miao_gewei
        # except Exception as e:
            # logger.error("【异常】 启动帧发送时标，报错：%s" % e)

    # 【检查】：时间标签Tp（6B）：启动帧帧序号计数器PFC（1B）、启动帧发送时标（4B）、 允许发送传输延时时间（1B）：
    def check_04_Tp(self, data_list):
        # try:
            result = analyze_fixed.check_SEQ(data_list)
            SEQ_D7_TpV = result[0]
            if SEQ_D7_TpV == "1":  # 只有TpV等于1的时候，报文才有Tp
                logger.info("【组成】 时间标签Tp（6B）：启动帧帧序号计数器PFC（1B）、启动帧发送时标（4B）、 允许发送传输延时时间（1B）")
                Tp = data_list[-8:-2]
                logger.info("【原报文： 时间标签Tp（6B）】 :%s" % Tp)

                # （1）启动帧帧序号计数器PFC（1B）
                PFC = data_list[-8]
                logger.info("【原报文：时间标签Tp，其中启动帧帧序号计数器PFC】：%s" % PFC)
                logger.info(" （1.1）启动帧帧序号计数器PFC 的byte：%s" % PFC)
                bin_PFC = bin(eval('0x' + PFC))
                # logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制：%s" % bin_PFC)
                bin_PFC = bin_PFC[2:]
                # logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制最终值：%s" % bin_PFC)
                if len(bin_PFC) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_PFC))
                else:
                    append_string = ''
                bin_PFC = append_string + bin_PFC[0:]
                # logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制补位最终值：%s" % bin_PFC)
                int_PFC = int(bin_PFC, 2)
                logger.info(" （1.1）启动帧帧序号计数器PFC 转换为二进制最终值，再转换为十进制：%s" % int_PFC)

                # （2）启动帧发送时标（4B）
                list_shibiao = self.check_04_Tp_shibiao_data(data_list)

                # （3）允许发送传输延时时间（1B）
                yanshi = data_list[-3]
                logger.info("【原报文：时间标签Tp，其中允许发送传输延时时间】：%s" % yanshi)
                logger.info(" （3.1）允许发送传输延时时间  的byte：%s" % yanshi)
                yanshi = bin(eval('0x' + yanshi))
                # logger.info(" （3.1）允许发送传输延时时间 转换为二进制：%s" % yanshi)
                yanshi = yanshi[2:]
                # logger.info(" （3.1）允许发送传输延时时间 转换为二进制最终值：%s" % yanshi)
                if len(yanshi) != 8:
                    append_string = analyze_base.generate_append_string(len(yanshi))
                else:
                    append_string = ''
                yanshi = append_string + yanshi[0:]
                # logger.info(" （3.1）允许发送传输延时时间 转换为二进制补位最终值：%s" % yanshi)
                int_yanshi = int(yanshi, 2)
                logger.info(" （3.1）允许发送传输延时时间 转换为二进制最终值，再转换为十进制：%s" % int_yanshi)

                return int_PFC, list_shibiao, int_yanshi
            else:
                logger.info("【正常】 SEQ_D7_TpV不是1，无时间标签Tp")
                # print("【正常】 SEQ_D7_TpV不是1，无时间标签Tp")
        # except Exception as e:
        #     logger.error("【异常】 时间标签Tp，报错：%s" % e)

    # 【检查】：消息认证码字段PW（16B）：
    def check_04_PW(self, data_list):
        # 消息认证码字段PW用于重要下行报文，由16字节组成，PW是由主站按系统约定的认证算法产生，并在主站发送的报文中下发给终端，由终端进行校验认证，通过则响应主站命令，反之则否认。
        # 终端在收到带有PW的报文，必须在认证通过后，才能响应命令。
        # try:
            result = analyze_fixed.check_control_bytes_C(data_list)
            C_D7_DIR = result[0]
            if C_D7_DIR == "0":  # 只有DIR=0下行报文，才有PW
                logger.info("【组成】：消息认证码字段PW（16B）：MAC（4B）、保留（12B）")
                # 确定有PW后，再根据确定是否有Tp，才能判断PW在报文中的index
                tmp_result = analyze_fixed.check_SEQ(data_list)
                SEQ_D7_TpV = tmp_result[0]
                PW = ""
                if SEQ_D7_TpV == "1":  # 只有TpV等于1的时候，报文才有Tp
                    PW = data_list[-24:-8]  # 有Tp时，PW的index
                    logger.info("【原报文：消息认证码字段PW（16B），有时间标签Tp时】：%s" % PW)
                elif SEQ_D7_TpV == "0":
                    PW = data_list[-18:-2]  # 无Tp时，PW的index
                    logger.info("【原报文：消息认证码字段PW（16B），无有时间标签Tp时】：%s" % PW)
                mac = PW[0:4]
                logger.info("【原报文：消息认证码字段PW，其中MAC（4B）】：%s" % mac)
                baoliu = PW[4:]
                logger.info("【原报文：消息认证码字段PW，其中保留字段（12B）】：%s" % baoliu)
        # except Exception as e:
        #     logger.error("【异常】 消息认证码字段PW，报错：%s" % e)


# 自测
if __name__ == '__main__':
    analyze_fn_04_base = AnalyzeFnO4Base()
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen04H")
    # 2、详解报文
    logger.info("-------------- Fn ：计算 -------------")
    Fn = analyze_fn_04_base.check_04_Fn(data_list)
    logger.info("-------------- Fn ：定义 -------------")
    analyze_fn_04_base.test_analyze_04_fn(data_list, Fn)
    logger.info("-------------- PW ：消息认证码字段 16B -------------")
    analyze_fn_04_base.check_04_PW(data_list)
    logger.info("-------------- Tp ：检查时间标签 6B -------------")
    analyze_fn_04_base.check_04_Tp(data_list)

    # 【检查】：数据单元标识（4B），从左至右： DA1，DA2，DT1，DT2，其中DA=DA1+DA2=0，计算出Pn、Fn
    def check_04_biaoshi(self, data_list):
        result = analyze_fixed_not.check_biaoshi(data_list)
        Fn = result[0]
        bin_biao_shi_DA1 = result[6]
        bin_biao_shi_DA2 = result[7]
        # DA = DA1+DA2
        int_biao_shi_DA = int((bin_biao_shi_DA1 + bin_biao_shi_DA2), 2)
        if int_biao_shi_DA == 0:
            logger.info(" 报文中数据单元标识 DA，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DA)
            logger.info("【正常】 DA1和DA2全为“0”，表示终端信息点")
        return Fn, int_biao_shi_DA

    # 【定义】：Fn的含义
    def check_04_Fn2(self, data_list):  # 拆分、完整报文
        Fn_dict = {10: '终端电能表/交流采样装置配置参数', 65: '定时上报1类数据任务设置', 66: '定时上报2类数据任务设置', 67: '定时上报1类数据任务启动/停止设置',
                   68: '定时上报2类数据任务启动/停止设置'}
        result = self.check_04_biaoshi(data_list)
        Fn = result[0]
        if Fn in list(Fn_dict.keys()):
            logger.info("【正常】 Fn=%s，表示：{ %s }" % (Fn, Fn_dict[Fn]))
        return Fn
