#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.common.analyze_base import AnalyzeBase

logger = Logger(logger="AnalyzeFnO4Define").getlog()
base_conf = BaseConf()
analyze_base = AnalyzeBase()


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnO4Define(object):

    # 10_1B：通信速率及端口号（1B）、通信协议类型（1B）、电能费率个数（1B）、有功电能示值整数位及小数位个数（1B）、用户大类号及用户小类号（1B）
    def check_04_Fn_10_zijie1(self, data_list, name, b1):
        # （1）（1B）
        baowen = data_list[b1:b1+1]
        logger.info("【原报文：%s】：%s" % (name, baowen))
        # （1.1）byte1
        byte1 = data_list[b1]
        # logger.info(" （1.1）%s的byte1：%s" % (name, byte1))
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （1.1）%s的byte1，转换为二进制：%s" % (name, bin_byte1))
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （1.1）%s的byte1，转换为二进制最终值：%s" % (name, bin_byte1))
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （1.1）%s的byte1，转换为二进制补位最终值：%s" % (name, bin_byte1))

        int_bin_byte1 = int(bin_byte1, 2)
        logger.info("【正常】 %s：%s" % (name, int_bin_byte1))
        return int_bin_byte1

    # 10_2B：本次电能表/交流采样装置配置数量n（2B）、电能表/交流采样装置序号（2B）、所属测量点号（2B）
    def check_04_Fn_10_zijie2(self, data_list, name, b1):
        # （1）（2B）
        baowen = data_list[b1:b1+2]
        logger.info("【原报文：%s】：%s" % (name, baowen))
        # （1.1）byte1
        byte1 = data_list[b1]
        # logger.info(" （1.1）%s的byte1：%s" % (name, byte1))
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （1.1）%s的byte1，转换为二进制：%s" % (name, bin_byte1))
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （1.1）%s的byte1，转换为二进制最终值：%s" % (name, bin_byte1))
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （1.1）%s的byte1，转换为二进制补位最终值：%s" % (name, bin_byte1))
        # （1.2）byte2
        byte2 = data_list[b1+1]
        # logger.info(" （1.2）%s的byte2：%s" % (name, byte2))
        bin_byte2 = bin(eval('0x' + byte2))
        # logger.info(" （1.2）%s的byte2，转换为二进制：%s" % (name, bin_byte2))
        bin_byte2 = bin_byte2[2:]
        # logger.info(" （1.2）%s的byte2，转换为二进制最终值：%s" % (name, bin_byte2))
        if len(bin_byte2) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte2))
        else:
            append_string = ''
        bin_byte2 = append_string + bin_byte2[0:]
        # logger.info(" （1.2）%s的byte2，转换为二进制补位最终值：%s" % (name, bin_byte2))

        bin_byte = bin_byte2+bin_byte1
        int_bin_byte = int(bin_byte, 2)
        logger.info("【正常】 %s：%s" % (name, int_bin_byte))
        return int_bin_byte

    # 10_6B：通信密码（6B）
    def check_04_Fn_10_zijie6(self, data_list, name, b1):
        # （1）（2B）
        baowen = data_list[b1: b1 + 6]
        logger.info("【原报文：%s】：%s" % (name, baowen))
        # （1.1）byte1
        byte1 = data_list[b1]
        # logger.info(" （1.1）%s的byte1：%s" % (name, byte1))
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （1.1）%s的byte1，转换为二进制：%s" % (name, bin_byte1))
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （1.1）%s的byte1，转换为二进制最终值：%s" % (name, bin_byte1))
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （1.1）%s的byte1，转换为二进制补位最终值：%s" % (name, bin_byte1))
        # （1.2）byte2
        byte2 = data_list[b1 + 1]
        # logger.info(" （1.2）%s的byte2：%s" % (name, byte2))
        bin_byte2 = bin(eval('0x' + byte2))
        # logger.info(" （1.2）%s的byte2，转换为二进制：%s" % (name, bin_byte2))
        bin_byte2 = bin_byte2[2:]
        # logger.info(" （1.2）%s的byte2，转换为二进制最终值：%s" % (name, bin_byte2))
        if len(bin_byte2) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte2))
        else:
            append_string = ''
        bin_byte2 = append_string + bin_byte2[0:]
        # logger.info(" （1.2）%s的byte2，转换为二进制补位最终值：%s" % (name, bin_byte2))
        # （1.3）byte3
        byte3 = data_list[b1 + 2]
        # logger.info(" （1.3）%s的byte3：%s" % (name, byte3))
        bin_byte3 = bin(eval('0x' + byte3))
        # logger.info(" （1.3）%s的byte3，转换为二进制：%s" % (name, bin_byte3))
        bin_byte3 = bin_byte3[2:]
        # logger.info(" （1.3）%s的byte3，转换为二进制最终值：%s" % (name, bin_byte3))
        if len(bin_byte3) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte3))
        else:
            append_string = ''
        bin_byte3 = append_string + bin_byte3[0:]
        # logger.info(" （1.3）%s的byte3，转换为二进制补位最终值：%s" % (name, bin_byte3))
        # （1.4）byte4
        byte4 = data_list[b1 + 3]
        # logger.info(" （1.4）%s的byte4：%s" % (name, byte4))
        bin_byte4 = bin(eval('0x' + byte4))
        # logger.info(" （1.4）%s的byte4，转换为二进制：%s" % (name, bin_byte4))
        bin_byte4 = bin_byte4[2:]
        # logger.info(" （1.4）%s的byte4，转换为二进制最终值：%s" % (name, bin_byte4))
        if len(bin_byte4) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte4))
        else:
            append_string = ''
        bin_byte4 = append_string + bin_byte4[0:]
        # logger.info(" （1.4）%s的byte4，转换为二进制补位最终值：%s" % (name, bin_byte4))
        # （1.5）byte5
        byte5 = data_list[b1 + 4]
        # logger.info(" （1.5）%s的byte5：%s" % (name, byte5))
        bin_byte5 = bin(eval('0x' + byte5))
        # logger.info(" （1.5）%s的byte5，转换为二进制：%s" % (name, bin_byte5))
        bin_byte5 = bin_byte5[2:]
        # logger.info(" （1.5）%s的byte5，转换为二进制最终值：%s" % (name, bin_byte5))
        if len(bin_byte5) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte5))
        else:
            append_string = ''
        bin_byte5 = append_string + bin_byte5[0:]
        # logger.info(" （1.5）%s的byte5，转换为二进制补位最终值：%s" % (name, bin_byte5))
        # （1.6）byte6
        byte6 = data_list[b1 + 5]
        # logger.info(" （1.6）%s的byte6：%s" % (name, byte6))
        bin_byte6 = bin(eval('0x' + byte6))
        # logger.info(" （1.6）%s的byte6，转换为二进制：%s" % (name, bin_byte6))
        bin_byte6 = bin_byte6[2:]
        # logger.info(" （1.6）%s的byte6，转换为二进制最终值：%s" % (name, bin_byte6))
        if len(bin_byte6) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte6))
        else:
            append_string = ''
        bin_byte6 = append_string + bin_byte6[0:]
        # logger.info(" （1.6）%s的byte6，转换为二进制补位最终值：%s" % (name, bin_byte6))

        bin_byte = bin_byte6+bin_byte5+bin_byte4+bin_byte3+bin_byte2+bin_byte1
        int_bin_byte = int(bin_byte, 2)
        logger.info("【正常】 %s：%s" % (name, int_bin_byte))
        return int_bin_byte

    # 66_part1:
    def check_04_Fn_66_part1(self, data_list):
        # （1） 定时上报周期及单位（1B）
        byte1 = data_list[18]
        logger.info("【原报文：定时上报周期及单位】：%s" % byte1)
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （1.1）配置任务 定时上报周期及单位，转换为二进制：%s" % bin_byte1)
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （1.1）配置任务 定时上报周期及单位，转换为二进制最终值：%s" % bin_byte1)
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （1.1）配置任务 定时上报周期及单位，转换为二进制补位最终值：%s" % bin_byte1)
        # （1.1）定时上报周期单位
        zqdw = bin_byte1[-2:]
        int_zqdw = int(zqdw, 2)
        # logger.info(" （1.1）配置任务 定时上报周期单位：%s" % int_zqdw)
        # （1.2）定时上报周期
        zq = bin_byte1[0:6]
        int_zq = int(zq, 2)
        # logger.info(" （1.1）配置任务 定时上报周期：%s" % int_zq)
        return int_zqdw, int_zq

    # 66_part2: 见附录A.1
    def check_04_Fn_66_part2(self, data_list):
        try:
            # （1）上报基准时间（6B）：秒（1B）+ 分（1B） + 时（1B） + 日（1B） + 星期-月（1B） + 年（1B）
            xintiao = data_list[19:25]
            logger.info("【原报文：上报基准时间】：%s" % xintiao)
            # （2.1） 秒（1B）
            byte1 = data_list[18]
            # logger.info(" （2.1）上报基准时间的byte1：%s" % byte1)
            bin_byte1 = bin(eval('0x' + byte1))
            # logger.info(" （2.1）上报基准时间的byte1，转换为二进制：%s" % bin_byte1)
            bin_byte1 = bin_byte1[2:]
            # logger.info(" （2.1）上报基准时间的byte1，转换为二进制最终值：%s" % bin_byte1)
            if len(bin_byte1) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte1))
            else:
                append_string = ''
            bin_byte1 = append_string + bin_byte1[0:]
            # logger.info(" （2.1）上报基准时间的byte1，转换为二进制补位最终值：%s" % bin_byte1)
            miao_shiwei = bin_byte1[4:]
            # logger.info(miao_shiwei)
            int_miao_shiwei = int(miao_shiwei, 2)
            # logger.info(" （2.1）上报基准时间的byte1的秒的十位，转换为二进制最终值，再转换为十进制：%s" % int_miao_shiwei)
            miao_gewei = bin_byte1[0:4]
            # logger.info(miao_gewei)
            int_miao_gewei = int(miao_gewei, 2)
            # logger.info(" （2.1）上报基准时间的byte1的秒的个位，转换为二进制最终值，再转换为十进制：%s" % int_miao_gewei)

            # （2.2） 分（1B）
            byte2 = data_list[19]
            # logger.info(" （2.2）上报基准时间的byte2：%s" % byte2)
            bin_byte2 = bin(eval('0x' + byte2))
            # logger.info(" （2.2）上报基准时间的byte2，转换为二进制：%s" % bin_byte2)
            bin_byte2 = bin_byte2[2:]
            # logger.info(" （2.2）上报基准时间的byte2，转换为二进制最终值：%s" % bin_byte2)
            if len(bin_byte2) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte2))
            else:
                append_string = ''
            bin_byte2 = append_string + bin_byte2[0:]
            # logger.info(" （2.2）上报基准时间的byte2，转换为二进制补位最终值：%s" % bin_byte2)
            fen_shiwei = bin_byte2[4:]
            # logger.info(fen_shiwei)
            int_fen_shiwei = int(fen_shiwei, 2)
            # logger.info(" （2.2）上报基准时间的byte2的分的十位，转换为二进制最终值，再转换为十进制：%s" % int_fen_shiwei)
            fen_gewei = bin_byte2[0:4]
            # logger.info(fen_gewei)
            int_fen_gewei = int(fen_gewei, 2)
            # logger.info(" （2.2）上报基准时间的byte2的分的个位，转换为二进制最终值，再转换为十进制：%s" % int_fen_gewei)

            # （2.3） 时（1B）
            byte3 = data_list[19]
            # logger.info(" （2.3）上报基准时间的byte3：%s" % byte3)
            bin_byte3 = bin(eval('0x' + byte3))
            # logger.info(" （2.3）上报基准时间的byte3，转换为二进制：%s" % bin_byte3)
            bin_byte3 = bin_byte3[2:]
            # logger.info(" （2.3）上报基准时间的byte3，转换为二进制最终值：%s" % bin_byte3)
            if len(bin_byte3) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte3))
            else:
                append_string = ''
            bin_byte3 = append_string + bin_byte3[0:]
            # logger.info(" （2.3）上报基准时间的byte3，转换为二进制补位最终值：%s" % bin_byte3)
            shi_shiwei = bin_byte3[4:]
            # logger.info(shi_shiwei)
            int_shi_shiwei = int(shi_shiwei, 2)
            # logger.info(" （2.3）上报基准时间的byte3的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_shi_shiwei)
            shi_gewei = bin_byte3[0:4]
            # logger.info(shi_gewei)
            int_shi_gewei = int(shi_gewei, 2)
            # logger.info(" （2.3）上报基准时间的byte3的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_shi_gewei)

            # （2.4） 日（1B）
            byte4 = data_list[19]
            # logger.info(" （2.4）上报基准时间的byte4：%s" % byte4)
            bin_byte4 = bin(eval('0x' + byte4))
            # logger.info(" （2.4）上报基准时间的byte4，转换为二进制：%s" % bin_byte4)
            bin_byte4 = bin_byte4[2:]
            # logger.info(" （2.4）上报基准时间的byte4，转换为二进制最终值：%s" % bin_byte4)
            if len(bin_byte4) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte4))
            else:
                append_string = ''
            bin_byte4 = append_string + bin_byte4[0:]
            # logger.info(" （2.4）上报基准时间的byte4，转换为二进制补位最终值：%s" % bin_byte4)
            ri_shiwei = bin_byte4[4:]
            # logger.info(ri_shiwei)
            int_ri_shiwei = int(ri_shiwei, 2)
            # logger.info(" （2.4）上报基准时间的byte4的时的十位，转换为二进制最终值，再转换为十进制：%s" % int_ri_shiwei)
            ri_gewei = bin_byte4[0:4]
            # logger.info(ri_gewei)
            int_ri_gewei = int(ri_gewei, 2)
            # logger.info(" （2.4）上报基准时间的byte4的时的个位，转换为二进制最终值，再转换为十进制：%s" % int_ri_gewei)

            # （2.5） 星期-月（1B）
            byte5 = data_list[19]
            # logger.info(" （2.5）上报基准时间的byte5：%s" % byte5)
            bin_byte5 = bin(eval('0x' + byte5))
            # logger.info(" （2.5）上报基准时间的byte5，转换为二进制：%s" % bin_byte5)
            bin_byte5 = bin_byte5[2:]
            # logger.info(" （2.5）上报基准时间的byte5，转换为二进制最终值：%s" % bin_byte5)
            if len(bin_byte5) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte5))
            else:
                append_string = ''
            bin_byte5 = append_string + bin_byte5[0:]
            # logger.info(" （2.5）上报基准时间的byte5，转换为二进制补位最终值：%s" % bin_byte5)
            xingqi_shiwei = bin_byte5[5:]
            # logger.info(xingqi_shiwei)
            int_xingqi_shiwei = int(xingqi_shiwei, 2)
            # logger.info(" （2.5）上报基准时间的byte5的星期的个位，转换为二进制最终值，再转换为十进制：%s" % int_xingqi_shiwei)
            yue_shiwei = bin_byte5[4]
            # logger.info(yue_shiwei)
            int_yue_shiwei = int(yue_shiwei, 2)
            # logger.info(" （2.5）上报基准时间的byte5的月的十位，转换为二进制最终值，再转换为十进制：%s" % int_yue_shiwei)
            yue_gewei = bin_byte5[0:4]
            # logger.info(yue_gewei)
            int_yue_gewei = int(yue_gewei, 2)
            # logger.info(" （2.5）上报基准时间的byte5的月的个位，转换为二进制最终值，再转换为十进制：%s" % int_yue_gewei)

            # （2.6） 年（1B）
            byte6 = data_list[19]
            # logger.info(" （2.6）上报基准时间的byte6：%s" % byte6)
            bin_byte6 = bin(eval('0x' + byte6))
            # logger.info(" （2.6）上报基准时间的byte6，转换为二进制：%s" % bin_byte6)
            bin_byte6 = bin_byte6[2:]
            # logger.info(" （2.6）上报基准时间的byte6，转换为二进制最终值：%s" % bin_byte6)
            if len(bin_byte6) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte6))
            else:
                append_string = ''
            bin_byte6 = append_string + bin_byte6[0:]
            # logger.info(" （2.6）上报基准时间的byte6，转换为二进制补位最终值：%s" % bin_byte6)
            nian_shiwei = bin_byte6[4:]
            # logger.info(nian_shiwei)
            int_nian_shiwei = int(nian_shiwei, 2)
            # logger.info(" （2.6）上报基准时间的byte6的年的十位，转换为二进制最终值，再转换为十进制：%s" % int_nian_shiwei)
            nian_gewei = bin_byte6[0:4]
            # logger.info(nian_gewei)
            int_nian_gewei = int(nian_gewei, 2)
            # logger.info(" （2.6）上报基准时间的byte6的年的个位，转换为二进制最终值，再转换为十进制：%s" % int_nian_gewei)
            logger.info("【计算】 得到上报基准时间：20%d%d-%d%d-%d%d %d%d:%d%d:%d%d，星期%d" % (
            int_nian_shiwei, int_nian_gewei, int_yue_shiwei, int_yue_gewei,
            int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei, int_miao_shiwei,
            int_miao_gewei, int_xingqi_shiwei))
            return int_nian_shiwei, int_nian_gewei, int_yue_shiwei, int_yue_gewei, \
                   int_ri_shiwei, int_ri_gewei, int_shi_shiwei, int_shi_gewei, int_fen_shiwei, int_fen_gewei, int_miao_shiwei, int_miao_gewei, int_xingqi_shiwei
        except Exception as e:
            logger.error("【异常】 上报基准时间，报错：%s" % e)

    # 66_part3：
    def check_04_Fn_66_part3(self, data_list):
        # （3） 曲线数据抽取倍率R（1B）
        byte1 = data_list[25]
        logger.info("【原报文：曲线数据抽取倍率R】：%s" % byte1)
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （3.1）配置任务 曲线数据抽取倍率R，转换为二进制：%s" % bin_byte1)
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （3.1）配置任务 曲线数据抽取倍率R，转换为二进制最终值：%s" % bin_byte1)
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （3.1）配置任务 曲线数据抽取倍率R，转换为二进制补位最终值：%s" % bin_byte1)
        int_bin_byte1 = int(bin_byte1, 2)
        logger.info("【正常】 曲线数据抽取倍率R：%s" % int_bin_byte1)
        return int_bin_byte1

    # 66_part4：数据单元标识个数n
    def check_04_Fn_66_part4(self, data_list):
        # （4）数据单元标识个数n（1B）
        byte1 = data_list[26]
        logger.info("【原报文：数据单元标识个数】：%s" % byte1)
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （4.1）配置任务 数据单元标识个数n，转换为二进制：%s" % bin_byte1)
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （4.1）配置任务 数据单元标识个数n，转换为二进制最终值：%s" % bin_byte1)
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （4.1）配置任务 数据单元标识个数n，转换为二进制补位最终值：%s" % bin_byte1)
        pzx_count = int(bin_byte1, 2)
        return pzx_count

    # 66_part5：数据单元标识（详细的，如采集项77、78...）
    def check_04_Fn_66_part5(self, data_list, pzx_count):
        # （5）数据单元标识（4B） 每隔4B一个采集项
        start_index = 27
        byte = data_list[start_index: -3]
        length = len(byte)  # 从数据单元标识index开始后面报文还有多少字节
        logger.info("【原报文：数据单元标识开始（%d字节）】：%s" % (length, byte))
        begin = 0
        jishuqi = 1
        while begin <= length:
            biaoshi = byte[begin:begin + 4]  # 每4个字节组成一个数据单元标识
            # logger.info("【正常】 数据单元标识：%s" % biaoshi)
            if biaoshi == ['01', '01', '10', '09']:
                logger.info("【正常】  %s  有采集项77 " % biaoshi)
            elif biaoshi == ['01', '01', '20', '09']:
                logger.info("【正常】  %s  有采集项78 " % biaoshi)
            elif biaoshi == ['01', '01', '40', '09']:
                logger.info("【正常】  %s  有采集项79 " % biaoshi)
            elif biaoshi == ['01', '01', '80', '09']:
                logger.info("【正常】  %s  有采集项80 " % biaoshi)
            elif biaoshi == ['01', '01', '01', '0a']:
                logger.info("【正常】  %s  有采集项81 " % biaoshi)
            elif biaoshi == ['01', '01', '02', '0a']:
                logger.info("【正常】  %s  有采集项82 " % biaoshi)
            elif biaoshi == ['01', '01', '04', '0a']:
                logger.info("【正常】  %s  有采集项83 " % biaoshi)
            elif biaoshi == ['01', '01', '08', '0a']:
                logger.info("【正常】  %s  有采集项84 " % biaoshi)
            elif biaoshi == ['01', '01', '10', '0a']:
                logger.info("【正常】  %s  有采集项85 " % biaoshi)
            elif biaoshi == ['01', '01', '20', '0a']:
                logger.info("【正常】  %s  有采集项86 " % biaoshi)
            elif biaoshi == ['01', '01', '40', '0a']:
                logger.info("【正常】  %s  有采集项87 " % biaoshi)
            elif biaoshi == ['01', '01', '80', '0a']:
                logger.info("【正常】  %s  有采集项88 " % biaoshi)
            elif biaoshi == ['01', '01', '01', '0b']:
                logger.info("【正常】  %s  有采集项89 " % biaoshi)
            elif biaoshi == ['01', '01', '02', '0b']:
                logger.info("【正常】  %s  有采集项90 " % biaoshi)
            elif biaoshi == ['01', '01', '04', '0b']:
                logger.info("【正常】  %s  有采集项91 " % biaoshi)
            elif biaoshi == ['01', '01', '08', '0b']:
                logger.info("【正常】  %s  有采集项92 " % biaoshi)
            elif biaoshi == ['01', '01', '10', '0b']:
                logger.info("【正常】  %s  有采集项93 " % biaoshi)
            elif biaoshi == ['01', '01', '20', '0b']:
                logger.info("【正常】  %s  有采集项94 " % biaoshi)
            elif biaoshi == ['01', '01', '40', '0b']:
                logger.info("【正常】  %s  有采集项95 " % biaoshi)
            elif biaoshi == ['01', '01', '80', '0b']:
                logger.info("【正常】  %s  有采集项96 " % biaoshi)
            elif biaoshi == ['01', '01', '10', '0c']:
                logger.info("【正常】  %s  有采集项101 " % biaoshi)
            elif biaoshi == ['01', '01', '20', '0c']:
                logger.info("【正常】  %s  有采集项102 " % biaoshi)
            elif biaoshi == ['01', '01', '40', '0c']:
                logger.info("【正常】  %s  有采集项103 " % biaoshi)
            elif biaoshi == ['01', '01', '80', '0c']:
                logger.info("【正常】  %s  有采集项104 " % biaoshi)
            elif biaoshi == ['01', '01', '01', '0d']:
                logger.info("【正常】  %s  有采集项105 " % biaoshi)
            elif biaoshi == ['01', '01', '02', '0d']:
                logger.info("【正常】  %s  有采集项106 " % biaoshi)
            elif biaoshi == ['01', '01', '04', '0d']:
                logger.info("【正常】  %s  有采集项107 " % biaoshi)
            elif biaoshi == ['01', '01', '08', '0d']:
                logger.info("【正常】  %s  有采集项108 " % biaoshi)
            begin = begin + 4
            jishuqi = jishuqi + 1
            if jishuqi > pzx_count:  # 目前最多可配置27个。所以后面就直接结束
                break
        else:
            logger.error("【异常】 数据单元标识不正确，%s")
        return

    # 见附录A.12：通信地址（6B）、所属采集器通信地址（6B）
    def check_04_F10_data(self, data_list, name, b1):
        try:
            # （1）（6B）
            xintiao = data_list[b1: b1 + 6]
            logger.info("【%s 原报文】：%s" % (name, xintiao))
            # （1.1） byte1（1B）
            byte1 = data_list[b1]
            # logger.info(" （1.1）%s的byte1：%s" % (name, byte1))
            bin_byte1 = bin(eval('0x' + byte1))
            # logger.info(" （1.1）%s的byte1，转换为二进制：%s" % (name, bin_byte1))
            bin_byte1 = bin_byte1[2:]
            # logger.info(" （1.1）%s的byte1，转换为二进、制最终值：%s" % (name, bin_byte1))
            if len(bin_byte1) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte1))
            else:
                append_string = ''
            bin_byte1 = append_string + bin_byte1[0:]
            # logger.info(" （1.1）%s的byte1，转换为二进制补位最终值：%s" % (name, bin_byte1))
            shiwei = bin_byte1[4:]
            # logger.info(shiwei)
            int_shiwei = int(shiwei, 2)
            # logger.info(" （1.1）%s的byte1的十位，转换为二进制最终值，再转换为十进制：%s" % (name, int_shiwei))
            gewei = bin_byte1[0:4]
            # logger.info(gewei)
            int_gewei = int(gewei, 2)
            # logger.info(" （1.1）%s的byte1的个位，转换为二进制最终值，再转换为十进制：%s" % (name, int_gewei))

            # （1.2） byte2（1B）
            byte2 = data_list[b1 + 1]
            # logger.info(" （1.2）%s的byte2：%s" % (name, byte2))
            bin_byte2 = bin(eval('0x' + byte2))
            # logger.info(" （1.2）%s的byte2，转换为二进制：%s" % (name, bin_byte2))
            bin_byte2 = bin_byte2[2:]
            # logger.info(" （1.2）%s的byte2，转换为二进制最终值：%s" % (name, bin_byte2))
            if len(bin_byte2) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte2))
            else:
                append_string = ''
            bin_byte2 = append_string + bin_byte2[0:]
            # logger.info(" （1.2）%s的byte2，转换为二进制补位最终值：%s" % (name, bin_byte2))
            qianwei = bin_byte2[4:]
            # logger.info(qianwei)
            int_qianwei = int(qianwei, 2)
            # logger.info(" （1.2）%s的byte2的千位，转换为二进制最终值，再转换为十进制：%s" % (name, int_qianwei))
            baiwei = bin_byte2[0:4]
            # logger.info(baiwei)
            int_baiwei = int(baiwei, 2)
            # logger.info(" （1.2）%s的byte2的百位，转换为二进制最终值，再转换为十进制：%s" % (name, int_baiwei))

            # （1.3） byte3（1B）
            byte3 = data_list[b1 + 2]
            # logger.info(" （1.3）%s的byte3：%s" % (name, byte3))
            bin_byte3 = bin(eval('0x' + byte3))
            # logger.info(" （1.3）%s的byte3，转换为二进制：%s" % (name, bin_byte3))
            bin_byte3 = bin_byte3[2:]
            # logger.info(" （1.3）%s的byte3，转换为二进制最终值：%s" % (name, bin_byte3))
            if len(bin_byte3) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte3))
            else:
                append_string = ''
            bin_byte3 = append_string + bin_byte3[0:]
            # logger.info(" （1.3）%s的byte3，转换为二进制补位最终值：%s" % (name, bin_byte3))
            shiwanwei = bin_byte3[4:]
            # logger.info(shiwanwei)
            int_shiwanwei = int(shiwanwei, 2)
            # logger.info(" （1.3）%s的byte3的十万位，转换为二进制最终值，再转换为十进制：%s" % (name, int_shiwanwei))
            wanwei = bin_byte3[0:4]
            # logger.info(wanwei)
            int_wanwei = int(wanwei, 2)
            # logger.info(" （1.3）%s的byte3的万位，转换为二进制最终值，再转换为十进制：%s" % (name, int_wanwei))

            # （1.4） byte4（1B）
            byte4 = data_list[b1 + 3]
            # logger.info(" （1.4）%s的byte4：%s" % (name, byte4))
            bin_byte4 = bin(eval('0x' + byte4))
            # logger.info(" （1.4）%s的byte4，转换为二进制：%s" % (name, bin_byte4))
            bin_byte4 = bin_byte4[2:]
            # logger.info(" （1.4）%s的byte4，转换为二进制最终值：%s" % (name, bin_byte4))
            if len(bin_byte4) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte4))
            else:
                append_string = ''
            bin_byte4 = append_string + bin_byte4[0:]
            # logger.info(" （1.4）%s的byte4，转换为二进制补位最终值：%s" % (name, bin_byte4))
            qianwanwei = bin_byte4[4:]
            # logger.info(qianwanwei)
            int_qianwanwei = int(qianwanwei, 2)
            # logger.info(" （1.4）%s的byte4的千万位，转换为二进制最终值，再转换为十进制：%s" % (name, int_qianwanwei))
            baiwanwei = bin_byte4[0:4]
            # logger.info(baiwanwei)
            int_baiwanwei = int(baiwanwei, 2)
            # logger.info(" （1.4）%s的byte4的百万位，转换为二进制最终值，再转换为十进制：%s" % (name, int_baiwanwei))

            # （1.5） byte5（1B）
            byte5 = data_list[b1 + 4]
            # logger.info(" （1.5）%s的byte5：%s" % (name, byte5))
            bin_byte5 = bin(eval('0x' + byte5))
            # logger.info(" （1.5）%s的byte5，转换为二进制：%s" % (name, bin_byte5))
            bin_byte5 = bin_byte5[2:]
            # logger.info(" （1.5）%s的byte5，转换为二进制最终值：%s" % (name, bin_byte5))
            if len(bin_byte5) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte5))
            else:
                append_string = ''
            bin_byte5 = append_string + bin_byte5[0:]
            # logger.info(" （1.5）%s的byte5，转换为二进制补位最终值：%s" % (name, bin_byte5))
            shiyiwei = bin_byte5[4:]
            # logger.info(shiyiwei)
            int_shiyiwei = int(shiyiwei, 2)
            # logger.info(" （1.4）%s的byte5的十亿位，转换为二进制最终值，再转换为十进制：%s" % (name, int_shiyiwei))
            yiwei = bin_byte5[0:4]
            # logger.info(yiwei)
            int_yiwei = int(yiwei, 2)
            # logger.info(" （1.4）%s的byte5的亿位，转换为二进制最终值，再转换为十进制：%s" % (name, int_yiwei))

            # （1.6） byte6（1B）
            byte6 = data_list[b1 + 5]
            # logger.info(" （1.6）%s的byte6：%s" % (name, byte6))
            bin_byte6 = bin(eval('0x' + byte6))
            # logger.info(" （1.6）%s的byte6，转换为二进制：%s" % (name, byte6))
            bin_byte6 = bin_byte6[2:]
            # logger.info(" （1.6）%s的byte6，转换为二进制最终值：%s" % (name, byte6))
            if len(bin_byte6) != 8:
                append_string = analyze_base.generate_append_string(len(bin_byte6))
            else:
                append_string = ''
            bin_byte6 = append_string + bin_byte6[0:]
            # logger.info(" （1.6）%s的byte6，转换为二进制补位最终值：%s" % (name, byte6))
            qianyiwei = bin_byte6[4:]
            # logger.info(qianyiwei)
            int_qianyiwei = int(qianyiwei, 2)
            # logger.info(" （1.6）%s的byte6千亿位，转换为二进制最终值，再转换为十进制：%s" % (name, int_qianyiwei))
            baiyiwei = bin_byte6[0:4]
            # logger.info(baiyiwei)
            int_baiyiwei = int(baiyiwei, 2)
            # logger.info(" （1.6）%s的byte6的百亿位，转换为二进制最终值，再转换为十进制：%s" % (name, int_baiyiwei))

            value = int_gewei + int_shiwei * 10 + int_baiwei * 100 + int_qianwei * 1000 + int_wanwei * 10000 + int_shiwanwei * 100000 + int_baiwanwei * 1000000 + int_qianwanwei * 10000000 + int_yiwei * 100000000 + int_shiyiwei * 1000000000 + int_baiyiwei * 10000000000 + int_qianyiwei * 100000000000
            logger.info(" %s：%s" % (name, value))
            return value, int_gewei, int_shiwei, int_baiwei, int_qianwei, int_wanwei, int_shiwanwei, int_baiwanwei, int_qianwanwei, int_yiwei, int_shiyiwei, int_baiyiwei, int_qianyiwei
        except Exception as e:
            logger.error("【异常】%s，报错：%s" % e)

    # 【（1、配置表计）】定时上报1类数据任务启动/停止设置 - 数据格式
    def check_04_Fn_10(self, data_list):
        try:
            # 一、本次电能表数量
            # （1）本次电能表/交流采样装置配置数量n（2B）
            count = self.check_04_Fn_10_zijie2(data_list, "本次电能表/交流采样装置配置数量", 18)
            logger.info("【说明】 所以报文中含有 %d 块表计的数据需要解析" % count)

            # 二、本次配置第n块:电能表 /交流采样装置（如果后续n块表就从（2）-（11）执行循环，报文开始位置是47）
            if count > 0:
                logger.info("-------------- 第一块表计数据 --------------")
                # （2）电能表/交流采样装置序号（2B）
                self.check_04_Fn_10_zijie2(data_list, "电能表/交流采样装置序号", 20)
                # （3）所属测量点号（2B）
                self.check_04_Fn_10_zijie2(data_list, "所属测量点号", 22)
                # （4）通信速率及端口号（1B）
                self.check_04_Fn_10_zijie1(data_list, "通信速率及端口号", 24)
                # （5）通信协议类型（1B）
                self.check_04_Fn_10_zijie1(data_list, "通信协议类型", 25)
                # （6）通信地址（6B）
                self.check_04_F10_data(data_list, "通信地址", 26)
                # （7）通讯密码（6B）
                self.check_04_Fn_10_zijie6(data_list, "通讯密码", 32)
                # （8）电能费率个数（1B）
                self.check_04_Fn_10_zijie1(data_list, "电能费率个数", 38)
                # （9）有功电能示值整数位及小数位个数（1B）
                self.check_04_Fn_10_zijie1(data_list, "有功电能示值整数位及小数位个数", 39)
                # （10）所属采集器通信地址（6B）
                self.check_04_F10_data(data_list, "所属采集器通信地址", 40)
                # （11）用户大类号及用户小类号（1B）
                self.check_04_Fn_10_zijie1(data_list, "用户大类号及用户小类号", 46)
            if count > 1:
                logger.info("-------------- 第二块表计数据 --------------")
                # （2）电能表/交流采样装置序号（2B）
                self.check_04_Fn_10_zijie2(data_list, "电能表/交流采样装置序号", 47)
                # （3）所属测量点号（2B）
                self.check_04_Fn_10_zijie2(data_list, "所属测量点号", 49)
                # （4）通信速率及端口号（1B）
                self.check_04_Fn_10_zijie1(data_list, "通信速率及端口号", 51)
                # （5）通信协议类型（1B）
                self.check_04_Fn_10_zijie1(data_list, "通信协议类型", 52)
                # （6）通信地址（6B）
                self.check_04_F10_data(data_list, "通信地址", 53)
                # （7）通讯密码（6B）
                self.check_04_Fn_10_zijie6(data_list, "通讯密码", 59)
                # （8）电能费率个数（1B）
                self.check_04_Fn_10_zijie1(data_list, "电能费率个数", 65)
                # （9）有功电能示值整数位及小数位个数（1B）
                self.check_04_Fn_10_zijie1(data_list, "有功电能示值整数位及小数位个数", 66)
                # （10）所属采集器通信地址（6B）
                self.check_04_F10_data(data_list, "所属采集器通信地址", 67)
                # （11）用户大类号及用户小类号（1B）
                self.check_04_Fn_10_zijie1(data_list, "用户大类号及用户小类号", 73)
        except Exception as e:
            logger.error("【异常】 报错：%s" % e)

    # 【（2、配置任务）】设置参数：定时上报2类数据任务设置 - 数据格式
    def check_04_Fn_65_66(self, data_list):
        # try:
            # 定时上报2类数据任务设置（配置任务）（13B）：xx 、xx
            pzrw = data_list[18:-3]
            logger.info("【原报文：定时上报2类数据任务设置（配置任务）】：%s" % pzrw)
            # （1）定时上报周期及单位（1B）
            result = self.check_04_Fn_66_part1(data_list)
            zqdw = result[0]
            zqdw_dict = {0: "分", 1: "时", 2: "日", 3: "月"}
            if zqdw in list(zqdw_dict.keys()):
                logger.info("【正常】 定时上报周期单位：%s，表示：{ 上报周期为 %s }" % (zqdw, zqdw_dict[zqdw]))
            else:
                logger.info("【异常】 定时上报周期单位 %s，不正确}" % zqdw, )
            zq = result[1]
            logger.info("【正常】 定时上报周期：%s，表示：{ 每隔 %s 分 }" % (zq, zq))
            # （2）上报基准时间：秒分时日月年（6B）
            self.check_04_Fn_66_part2(data_list)
            # （3）曲线数据抽取倍率R（1B）
            R = self.check_04_Fn_66_part3(data_list)
            # logger.info("【计算】 ：%s" % R)
            R_dict = {1: "表示仍按30分钟抽取", 2: "表示按60分钟抽取"}  # 取值范围1～96，表示终端按此倍率抽取数据上送，如被抽取的数据的冻结密度m = 2，即每30分钟冻结一个值
            if (R >= 1) and (R <= 96):
                if R in list(R_dict.keys()):
                    logger.info("【正常】 曲线数据抽取倍率R=%s，表示：{ %s }" % (R, R_dict[R]))
            else:
                logger.error("【异常】 曲线数据抽取倍率 R=%s，不符合 }" % R)

            # （4）数据单元标识个数n（1B）
            pzx_count = self.check_04_Fn_66_part4(data_list)
            logger.info("【正常】 数据单元标识个数：%s" % pzx_count)
            # （5）具体数据标识
            self.check_04_Fn_66_part5(data_list, pzx_count)

        # except Exception as e:
        #     logger.error("【异常】配置任务，报错：%s" % e)

    # 【（3/4、启动/停止任务）】定时上报1类数据任务启动/停止设置 - 数据格式
    def check_04_Fn_67_68(self, data_list):
        try:
            # （1）定时上报1类数据任务启动/停止设置（启动/停止）（1B）：启动/停止标志（1B）
            biaozhi = data_list[18]
            logger.info("【原报文：定时上报1类数据任务启动/停止设置（启动/停止任务）】：%s" % biaozhi)
            # （1.1） 启动/停止标志（1B）
            if biaozhi == "55":
                logger.info("【正常】 定时上报1类数据任务启动/停止设置：%s，表示：{ 启动任务 }" % biaozhi)
            elif biaozhi == "AA" or biaozhi == "aa":
                logger.info("【正常】 定时上报1类数据任务启动/停止设置：%s，表示：{ 停止任务 }" % biaozhi)
            else:
                logger.info("【正常】 定时上报1类数据任务启动/停止设置：%s，表示：{ 无效 }" % biaozhi)
        except Exception as e:
            logger.error("【异常】 定时上报1类数据任务启动/停止设置（启动/停止任务），报错：%s" % e)


# 自测
if __name__ == '__main__':
    analyze_fn_04_define = AnalyzeFnO4Define()
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen04H")
    # 2、详解报文
    # analyze_fn_04_define.check_04_Fn_10(data_list)
    analyze_fn_04_define.check_04_Fn_65_66(data_list)
    # analyze_fn_04_define.check_04_Fn_67_68(data_list)
    # analyze_fn_04_define.check_04_Fn_66_part5(data_list, 28)


    def data_all(self, data_list, name, b1):
        byte1 = data_list[b1]
        logger.info(" （1.1）%s的byte1：%s" % (name, byte1))
        bin_byte1 = bin(eval('0x' + byte1))
        # logger.info(" （1.1）%s的byte1，转换为二进制：%s" % (name, bin_byte1))
        bin_byte1 = bin_byte1[2:]
        # logger.info(" （1.1）%s的byte1，转换为二进、制最终值：%s" % (name, bin_byte1))
        if len(bin_byte1) != 8:
            append_string = analyze_base.generate_append_string(len(bin_byte1))
        else:
            append_string = ''
        bin_byte1 = append_string + bin_byte1[0:]
        # logger.info(" （1.1）%s的byte1，转换为二进制补位最终值：%s" % (name, bin_byte1))
        return bin_byte1
