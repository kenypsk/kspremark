#!/usr/bin/python
# coding: utf-8
from logger_demo.framework.log.logger import Logger
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed

logger = Logger(logger="AnalyzeFixedNot").getlog()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()


# 【解析】 非固定部分解析 --> 得到Pn、Fn及其含义
class AnalyzeFixedNot(object):

    # 【检查】：数据单元标识（4B），从左至右： DA1，DA2，DT1，DT2，计算出Pn、Fn
    def check_biaoshi(self, data_list):  # 拆分、完整报文
        data_dict = {'01': '1',
                     '02': '2',
                     '04': '3',
                     '08': '4',
                     '10': '5',
                     '20': '6',
                     '40': '7',
                     '80': '8'
                     }

        biao_shi = data_list[14:18]
        logger.info("【原报文：数据单元标识】：%s" % biao_shi)

        # （1）转换DA2为二进制
        biao_shi_DA2 = data_list[15]
        # logger.info(" （2）报文中数据单元标识 DA2：%s" % biao_shi_DA2)
        bin_biao_shi_DA2 = bin(eval('0x' + biao_shi_DA2))
        # logger.info(" （2）报文中数据单元标识 DA2，转换为二进制：%s" % bin_biao_shi_DA2)
        bin_biao_shi_DA2 = bin_biao_shi_DA2[2:]
        # logger.info(" （3）报文中数据单元标识 DA2，转换为二进制最终值：%s" % bin_biao_shi_DA2)
        int_biao_shi_DA2 = int(bin_biao_shi_DA2, 2)
        # logger.info(" （4）报文中数据单元标识 DA2，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DA2)

        # （2）转换DA1为二进制
        biao_shi_DA1 = data_list[14]
        # logger.info(" （1）报文中数据单元标识 DA1：%s" % biao_shi_DA1)
        bin_biao_shi_DA1 = bin(eval('0x' + biao_shi_DA1))
        # logger.info(" （2）报文中数据单元标识 DA1，转换为二进制：%s" % bin_biao_shi_DA1)
        bin_biao_shi_DA1 = bin_biao_shi_DA1[2:]
        # logger.info(" （3）报文中数据单元标识 DA1，转换为二进制最终值：%s" % bin_biao_shi_DA1)
        int_biao_shi_DA1 = int(bin_biao_shi_DA1, 2)
        # logger.info(" （4）报文中数据单元标识 DA1，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DA1)

        if biao_shi_DA1 in list(data_dict.keys()):
            result_DA1 = data_dict[biao_shi_DA1]
            # logger.info("【正常】 DA1 对照表，DA1十六进制值：%s,对应 DA1真实值： %s" % (biao_shi_DA1, int(result_DA1)))
            Pn = (int_biao_shi_DA2 - 1) * 8 + int(result_DA1)  # Pn计算公式： (DA2 - 1) * 8 + DA1对应的值就是信息点标识pn
            logger.info("【计算】 Pn=%d，其中DA2值：%d，DA1值：%d" % (Pn, int_biao_shi_DA2, int(result_DA1)))
        else:
            Pn = 0
            logger.error("【错误】 直接定义Pn=0，DA1 对照表，其中DA1不在对照表内")

        # （3）转换DT2为二进制
        biao_shi_DT2 = data_list[17]
        # logger.info(" （4）报文中数据单元标识 DT2：%s" % biao_shi_DT2)
        bin_biao_shi_DT2 = bin(eval('0x' + biao_shi_DT2))
        # logger.info(" （2）报文中数据单元标识 DT2，转换为二进制：%s" % bin_biao_shi_DT2)
        bin_biao_shi_DT2 = bin_biao_shi_DT2[2:]
        # logger.info(" （3）报文中数据单元标识 DT2，转换为二进制最终值：%s" % bin_biao_shi_DT2)
        int_biao_shi_DT2 = int(bin_biao_shi_DT2, 2)
        # logger.info(" （4）报文中数据单元标识 DT2，转换为二进制最终值，再转换为十进制：%s" % int_biao_shi_DT2)

        # （4）转换DT1为二进制
        biao_shi_DT1 = data_list[16]
        # logger.info(" （3）报文中数据单元标识 DT1：%s" % biao_shi_DT1)
        if biao_shi_DT1 in list(data_dict.keys()):
            result_DT1 = data_dict[biao_shi_DT1]
            # logger.info("【正常】 DT1 对照表，DT1十六进制值：%s,对应 DT1真实值： %s" % (biao_shi_DT1, int(result_DT1)))
            Fn = int_biao_shi_DT2 * 8 + int(result_DT1)  # Fn计算公式：DT2 * 8 + DT1对应的值就是信息类标识Fn
            logger.info("【计算】 Fn=%d，其中DT2值：%d，DT1值：%d" % (Fn, int_biao_shi_DT2, int(result_DT1)))
        else:
            Fn = 0
            logger.error("【错误】 直接定义Fn=0，DT1 对照表，其中DT1不在对照表内")

        # return Fn, Pn, biao_shi
        return Fn, Pn, biao_shi[0], biao_shi[1], biao_shi[2], biao_shi[3], bin_biao_shi_DA1, bin_biao_shi_DA2

    # {判断}：根据AFN、Pn、Fn，综合判断Pn、Fn得到具体含义
    def get_Fn(self, data_list):
        logger.info("-------------- AFN ：检查应用功能码 1B --------------")
        AFN = analyze_fixed.check_AFN(data_list)

        logger.info("-------------- 数据单元标识：检查 4B --------------")
        Pn_Fn = self.check_biaoshi(data_list)
        Fn = Pn_Fn[0]
        Pn = Pn_Fn[1]
        biao_shi = Pn_Fn[2:6]

        if AFN == "00":
            func_dict00 = {1: '全部确认：对收到报文中的全部数据单元标识进行确认', 2: '全部否认：对收到报文中的全部数据单元标识进行否认',
                           3: '按数据单元标识确认和否认：对收到报文中的全部数据单元标识进行逐个确认/否认', 4: '硬件安全认证错误应答', '其他': '备用'}
            if Fn in list(func_dict00.keys()):
                logger.info("【计算】 AFN=%s,Fn=%s，Pn=%s，数据标识[%s,%s,%s,%s]，Fn对应功能表示：{ %s }" % (AFN, Fn, Pn, biao_shi[0], biao_shi[1], biao_shi[2], biao_shi[3], func_dict00[Fn]))
            else:
                logger.error("【错误】 Fn=%s 对应功能不存在，Fn对应功能不匹配" % Fn)
            return Fn
        if AFN == "02":
            func_dict02 = {1: '登录', 2: '退出登录', 3: '心跳', '其他': '备用'}
            if Fn in list(func_dict02.keys()):
                logger.info("【计算】 AFN=%s,Fn=%s，Pn=%s，数据标识[%s,%s,%s,%s]，Fn对应功能表示：{ %s }" % (AFN, Fn, Pn, biao_shi[0], biao_shi[1], biao_shi[2], biao_shi[3], func_dict02[Fn]))
            else:
                logger.error("【错误】 Fn=%s 对应功能不存在，Fn对应功能不匹配" % Fn)
            return Fn
        if AFN == "04":
            func_dict02 = {10: '终端电能表/交流采样装置配置参数', 65: '定时上报1类数据任务设', 66: '定时上报2类数据任务设置',
                           67: '定时上报1类数据任务启动/停止设置', 68: '定时上报2类数据任务启动/停止设置'}
            if Fn in list(func_dict02.keys()):
                logger.info("【计算】 AFN=%s,Fn=%s，Pn=%s，数据标识[%s,%s,%s,%s]，Fn对应功能表示：{ %s }" % (AFN, Fn, Pn, biao_shi[0], biao_shi[1], biao_shi[2], biao_shi[3], func_dict02[Fn]))
            else:
                logger.error("【错误】 Fn=%s 对应功能不存在，Fn对应功能不匹配" % Fn)
            return Fn
        if AFN == "0d":
            func_dict0d = {77	: '总视在功率', 78	: 'A相视在功率', 79	: 'B相视在功率', 80	: 'C相视在功率',
                           81	: '总有功功率', 82	: 'A相有功功率',  83	: 'B相有功功率', 84	: 'C相有功功率',
                           85	: '总无功功率', 86	: 'A相无功功率', 87	: 'B相无功功率', 88	: 'C相无功功率',
                           89	: 'A相电压',  90	: 'B相电压', 91	: 'C相电压', 92	: 'A相电流', 93	: 'B相电流', 94	: 'C相电流', 95	: '零序电流',
                           96: '频率', 101	: '正向有功总电能示值', 102	: '正向无功总电能示值',  103	: '反向有功总电能示值',  104	: '反向无功总电能示值',
                           105	: '总功率因数', 106	: 'A相功率因数', 107	: 'B相功率因数', 108	: 'C相功率因数'
                           }
            if Fn in list(func_dict0d.keys()):
                logger.info("【计算】 AFN=%s,Fn=%s，Pn=%s，数据标识[%s,%s,%s,%s]，Fn对应功能表示：{ %s }" % (AFN, Fn, biao_shi[0], biao_shi[1], biao_shi[2], biao_shi[3], biao_shi, func_dict0d[Fn]))
            else:
                logger.error("【错误】 Fn=%s 对应功能不存在，Fn对应功能不匹配" % Fn)
            return Fn

    # 2、analyze：非固定报文
    def test_analyze_fixed_not(self, data_list):
        logger.info("-------------- Fn ： 计算 --------------")
        self.get_Fn(data_list)


if __name__ == '__main__':
    analyze_fixed_not = AnalyzeFixedNot()
    # 1、读取报文
    # （1）拆分报文  只能从报文类型为0dH，按采集项人工拆分
    # data_list = analyze_base.get_data_list_conf("101")
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen00H")
    # data_list = analyze_base.get_data_list_conf("baowen02H")
    # data_list = analyze_base.get_data_list_conf("baowen04H")
    # data_list = analyze_base.get_data_list_conf("baowen0dH")
    # data_list = analyze_base.get_data_list_conf("baowen")

    # 2、解析报文：非固定部分Fn、Pn及含义（Pn即measurePoint？）
    analyze_fixed_not.test_analyze_fixed_not(data_list)   # 适用（完整和拆分）报文
