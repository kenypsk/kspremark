#!/usr/bin/python
# coding: utf-8
import os
from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
logger = Logger(logger="AnalyzeBase").getlog()
base_conf = BaseConf()
base_dir = os.path.abspath(os.path.join(os.getcwd(), "../.."))
ini_dir = "conf"
ini_name = "data.txt"
# conf_dir = base_dir + "/" + ini_dir  # 文件夹


# 【基础】 配置文件读取
class AnalyzeBase(object):

    # 0.1、读取配置文件1
    def get_data_list(self, file_name):
        # （1）直接读取文件
        fp = open(file_name, 'r')
        raw_data = fp.read()
        data_list = raw_data.split()
        # print("【原报文】：%s" % data_list)
        logger.info("【原报文】：%s" % data_list)
        return data_list

    # 0.2、读取配置文件2
    def get_data_list_conf(self, data_type):
        # （2）读取配置文件
        file_name = base_conf.conf_get_file_name("conf", "data.ini")  # 测试通过
        data_list = base_conf.conf_read_value(file_name, section_name=data_type, key=data_type).split()
        # print("【原报文】：%s" % data_list)
        logger.info("【原报文】：%s" % data_list)
        return data_list

    # 补位：不足8位的补0
    def generate_append_string(self, length):
        value = 8 - length
        tmp_string = ""
        if value == 1:
            tmp_string = '0'
        elif value == 2:
            tmp_string = '00'
        elif value == 3:
            tmp_string = '000'
        elif value == 4:
            tmp_string = '0000'
        elif value == 5:
            tmp_string = '00000'
        elif value == 6:
            tmp_string = '000000'
        elif value == 7:
            tmp_string = '0000000'
        else:
            logger.error("【错误】 长度不正确!")
        return tmp_string


if __name__ == '__main__':
    analyze_base = AnalyzeBase()
    # 方法一：读取报文
    file_name = base_dir + "/" + ini_dir + "/" + ini_name  # 文件
    data_list = analyze_base.get_data_list(file_name)

    # 方法二：读取报文
    data_list = analyze_base.get_data_list_conf("baowen0dH")

    # 测试通过
    # logger.info("\n-------------- 缺位补位 --------------")
    # tmp_string = analyze_base.generate_append_string(1)
    # logger.info(tmp_string)
