#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue
from master_station.framework.afn_0d.analyze_Fn_0d_base import AnalyzeFnOdBase

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_define import AnalyzeFnOdDefine
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnOd").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_0d_base = AnalyzeFnOdBase()
analyze_fn_0d_define = AnalyzeFnOdDefine()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 针对AFN=0dH的完整报文：Fn详细解析，通过analyze_fn_0d_base类截图计算所需报文，最终得到curveValue
class AnalyzeFnOd(object):

    # 0.1、define_Fn：Fn定义
    def test_analyze_fn(self, data_list, type):
        func_code = analyze_fixed.check_AFN(data_list)
        if func_code == "0d":
            if type in (77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88):  # 测试 81-84 : A.9　数据格式09
                result77_88 = analyze_fn_0d_define.check_fn_77_88(data_list, type)
                if result77_88 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result77_88[0], result77_88[1], result77_88[2], type, result77_88[3], result77_88[4]))
                        logger.info(
                            "【正常】 采集项 %s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result77_88[0], result77_88[1], result77_88[2], type, result77_88[3], result77_88[4]))
                        return result77_88[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
            if type in (89, 90, 91):  # 测试 89_91 : A.7　数据格式07
                result89_91 = analyze_fn_0d_define.check_fn_89_91(data_list, type)
                if result89_91 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项 %s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result89_91[0], result89_91[1], result89_91[2], type, result89_91[3], result89_91[4]))
                        logger.info(
                            "【正常】 采集项 %s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result89_91[0], result89_91[1], result89_91[2], type, result89_91[3], result89_91[4]))
                        return result89_91[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
            if type in (92, 93, 94, 95):  # 测试 92_95 : A.25　数据格式25
                result92_95 = analyze_fn_0d_define.check_fn_92_95(data_list, type)
                if result92_95 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result92_95[0], result92_95[1], result92_95[2], type, result92_95[3], result92_95[4]))
                        logger.info(
                            "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result92_95[0], result92_95[1], result92_95[2], type, result92_95[3], result92_95[4]))
                        return result92_95[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
            if type == 96:  # 测试 96 : 未定义，暂时先用89_91解析
                result96 = analyze_fn_0d_define.check_fn_89_91(data_list, type)
                if result96 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result96[0], result96[1], result96[2], type, result96[3], result96[4]))
                        logger.info(
                            "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result96[0], result96[1], result96[2], type, result96[3], result96[4]))
                        return result96[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
            if type in (101, 102, 103, 104):  # 测试 101_104 : A.11　数据格式11
                result101_104 = analyze_fn_0d_define.check_fn_101_104(data_list, type)
                if result101_104 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result101_104[0], result101_104[1], result101_104[2], type, result101_104[3],
                        #     result101_104[4]))
                        logger.info(
                            "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result101_104[0], result101_104[1], result101_104[2], type, result101_104[3],
                            result101_104[4]))
                        return result101_104[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
            if type in (105, 106, 107, 108):  # 测试 105_108 : A.5　数据格式05
                result105_108 = analyze_fn_0d_define.check_fn_105_108(data_list, type)
                if result105_108 == "":
                    # print("【正常】 采集项%s 上传数据为 null" % type)
                    logger.info("【正常】 采集项%s 上传数据为 null" % type)
                    return None
                else:
                    try:
                        # print(
                        #     "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                        #     type, result105_108[0], result105_108[1], result105_108[2], type, result105_108[3],
                        #     result105_108[4]))
                        logger.info(
                            "【正常】 采集项%s 数据冻结密度m = %s(表示%s), 数据点数n = %s(表示以m为间隔的连续n个点的曲线数据)：\n  type = %s，freezeTime = %s，cureveValue = %s \n" % (
                            type, result105_108[0], result105_108[1], result105_108[2], type, result105_108[3],
                            result105_108[4]))
                        return result105_108[4]
                    except Exception as e:
                        logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))

    # 0.2、数据库实际存储
    def test_mysql(self, sql):
        mysql = base_mysql.mysql_connect('192.168.11.225', 'masterstation', '123456', 'masterstation', 3306)  # 测试通过
        # con = mysql[0]
        cur = mysql[1]
        sql_result = select_mysql.get_mysql_data(sql, cur)
        if sql_result == "":
            logger.info("【正常】 查询出数据为 null")
        else:
            logger.info("【正常】 查询成功")
        return sql_result

    # 0.3、比较，两者是否匹配
    def compare_vaule(self, js_curveValue, curveValue):
        if (js_curveValue == "") or (curveValue == ""):
            logger.error("【异常】 存在某个数据为 null")
        elif js_curveValue == curveValue:
            logger.info("【匹配】 该采集项数据匹配，计算值js_curveValue：%f，数据库值curveValue：%f" % (js_curveValue, curveValue))
        else:
            logger.info("【不匹配】 该采集项数据不匹配，计算值js_curveValue：%f，而数据库值curveValue：%f" % (js_curveValue, curveValue))

    # 0.4、汇总（完整报文：不需要拆分，能同时计算出采集项 77-108 所有值）
    def test_analyze_fn_0d(self, data_list, type):
        # 【0.1、计算】cureveValue
        logger.info("-------------- curveValue ：计算 -------------")
        js_result = self.test_analyze_fn(data_list, type)
        # print(js_result)
        if js_result is not None:
            if js_result == 0:
                js_curveValue = js_result
            else:
                js_curveValue = float('%.4f' % (js_result))
        else:
            js_curveValue = ""
        logger.info("采集项%s 得到 curveValue ：%s " % (type, js_curveValue))

        # 【0.2、数据库】 cureveValue
        logger.info("-------------- curveValue ：查询mysql -------------")
        sql = 'select curveValue from curvedata20180224 where type =101 and FROM_UNIXTIME(freezeTime)="2018-02-24 10:30:00";'
        sql_result = self.test_mysql(sql)
        if sql_result != "":
            curveValue = float('%.4f' % 138.6200)
        else:
            curveValue = ""
        # curveValue = Decimal(sql_result[0][0])
        # curveValue = float('%.2f' % (sql_result[0][0]))
        # curveValue = float('%.2f' % (Decimal((sql_result)[0][0])))

        # 【0.3、比较】 两者是否一致
        logger.info("-------------- curveValue ：是否匹配 -------------")
        self.compare_vaule(js_curveValue, curveValue)
        return js_curveValue, curveValue


# 自测
if __name__ == '__main__':
    analyze_fn_0d = AnalyzeFnOd()
    # 针对拆分报文
    # 1、读取报文
    # （1）拆分报文
    # data_list = analyze_base.get_data_list_conf("89")
    # 2、解析报文：采集项数据
    # analyze_fn_0d.test_analyze_fn_0d(data_list, 89)

    # 针对完整报文
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen0dH")
    # 2、解析报文：采集项数据
    analyze_fn_0d.test_analyze_fn_0d(data_list, 81)
    # logger.info(list(enumerate(data_list)))

    # 3、根据步骤2得到的下标：截取以数据标识开始的报文  {3、获取真实数据报文}
    def get_Fn_data_back(self, data_list):
        result = analyze_fixed_not.check_biaoshi(data_list)
        Fn = result[0]
        a = result[2]  # if str(result[2]) == "01":  print("pass")
        b = result[3]
        c = result[4]
        d = result[5]
        # str77 = ['01', '01', '10', '09']
        type_dict = {77: "'01', '01', '10', '09'",
                     78: "'01', '01', '20', '09'",
                     79: "'01', '01', '40', '09'"
                     }
        print("=============")
        if Fn in list(type_dict.keys()):
            print("322332323232")
            data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 18
            sj_list = data_list[data_start_index - 4:]
            for type_dict[Fn] in sj_list:
                if (a == "01") and (b == "01") and (c == "10") and (d == "09"):  # type == 77
                    print(sj_list)
                    self.test_analyze_fn(data_list)
                elif (a == "01") and (b == "01") and (c == "20") and (d == "09"):  # type == 78
                    print(sj_list)
                    self.test_analyze_fn(data_list)


                # for str in data_list:
                # if (a == "01") and (b == "01") and (c == "20") and (d == "09"):  # type == 78
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 32
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "09"):  # type == 79
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 46
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "09"):  # type == 80
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 60
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0a"):  # type == 81
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 74
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0a"):  # type == 82
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 88
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "09"):  # type == 83
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 102
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0a"):  # type == 84
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 116
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0a"):  # type == 85
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 130
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0a"):  # type == 86
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 144
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0a"):  # type == 87
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 158
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0a"):  # type == 88
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 172
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0b"):  # type == 89
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 186
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0b"):  # type == 90
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 199
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "0b"):  # type == 91
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 212
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0b"):  # type == 92
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 225
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0b"):  # type == 93
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 239
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0b"):  # type == 94
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 253
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0b"):  # type == 95
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 267
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0b"):  # type == 96
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 281
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "10") and (d == "0c"):  # type == 101
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 294
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "20") and (d == "0c"):  # type == 102
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 309
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "40") and (d == "0c"):  # type == 103
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 324
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "80") and (d == "0c"):  # type == 104
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 339
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "01") and (d == "0d"):  # type == 105
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 354
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "02") and (d == "0d"):  # type == 106
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 367
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "04") and (d == "0d"):  # type == 107
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 380
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list
                # if (a == "01") and (b == "01") and (c == "08") and (d == "0d"):  # type == 108
                #     data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 393
                #     sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                #     return sj_list

