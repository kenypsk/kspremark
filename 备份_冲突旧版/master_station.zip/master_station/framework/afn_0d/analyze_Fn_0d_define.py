#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_base import AnalyzeFnOdBase
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnOdDefine").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_0d_base = AnalyzeFnOdBase()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnOdDefine(object):

    # 未定义，备用
    def check_fn_96(self, data_list):
        pass

    # 见附录A.9   明确：81_88 总/A相/B相/C相：有功功率/无功功率    备用：77_80 总/A相/B相/C相：视在功率
    def check_fn_77_88(self, data_list, type):
        logger.info("【采集项 %s 组成】：曲线类数据时标Td_c（7B）、采集项%s第1组数据（3B）....采集项%s第n组数据（3B）" % (type, type, type))
        sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, type)  # 得到从数据标识开始的剩余字符串
        logger.info("【非原报文】 采集项 %s 开始的数据（含数据标识）剩余报文部分：%s" % (type, sj_list))
        try:
            # （1）曲线类数据时标Td_c（7B） = 起始时间ts：分时日月年（5B） + 数据冻结密度m（1B） + 数据点数n（1B）
            Td_c = sj_list[4:11]
            logger.info("【采集项 %s 曲线类数据时标Td_c 原报文】：%s" % (type, Td_c))
            # （1.1） 起始时间ts：分时日月年（5B）
            qssj = sj_list[4:9]
            # logger.info(" （1.1）报文中曲线类数据时标Td_c 的起始时间ts（分时日月年）：%s" % qssj)
            logger.info("【正常】 采集项 %s 曲线类数据时标Td_c 的起始时间ts，即freezeTime值：20%s-%s-%s %s:%s" % (type, qssj[4], qssj[3], qssj[2], qssj[1], qssj[0]))
            # （1.2） 数据冻结密度m（1B）
            sjdjmdm = sj_list[9]
            int_sjdjmdm = int(sjdjmdm, 2)
            # logger.info(" （1.2）报文中曲线类数据时标Td_c 的数据冻结密度m：%s" % int_sjdjmdm)
            sjdjmdm_dict = {
                            0: "不冻结：每整点依次的冻结时刻无",
                            1: "15：每整点依次的冻结时刻，15分，30分，45分，0分",
                            2: "30：每整点依次的冻结时刻：30分，0分",
                            3: "60：每整点依次的冻结时刻：0分",
                            254: "5：每整点依次的冻结时刻：5分、10分、15分... 0分",
                            255: "1：每整点依次的冻结时刻：1分、2分、3分... 0分",
                            "其他": "备用"
            }
            if int_sjdjmdm in list(sjdjmdm_dict.keys()):
                logger.info("【正常】 采集项 %s 曲线类数据时标Td_c 的数据冻结密度m：%s,表示：{ %s }" % (type, int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm]))
            else:
                logger.error("【错误】 采集项 %s 曲线类数据时标Td_c 的数据冻结密度m 不匹配" % type)
            # （1.3） 数据点数n（1B）
            sjdsn = sj_list[10]
            int_sjdsn = int(sjdsn, 2)
            logger.info("【正常】 采集项 %s 曲线类数据时标Td_c 的数据点数n：%s，表示：{ 连续%s个点的曲线数据 }" % (type, int_sjdsn,int_sjdsn))

            # （2）无功功率1（3B）....无功功率n（3B），其中每个无功功率（3B）= byte1 + byte2 + byte3
            logger.info("【采集项 %s 纯数据 原报文】：%s" % (type, sj_list[11:14]))
            if sj_list[11:14] in wujie:
                logger.info("【采集项 %s 原报文】：%s 解析无数据" % (type, sj_list[11:14]))
                cureve_value = ""
                return cureve_value
            else:
                # （2.1）无功功率1的 byte1（1B）
                byte1 = sj_list[11]
                logger.info(" （2.1）采集项 %s 的byte1：%s" % (type, byte1))
                bin_byte1 = bin(eval('0x' + byte1))
                # logger.info(" （2.1）采集项 %s 的byte1，转换为二进制：%s" % (type, bin_byte1))
                bin_byte1 = bin_byte1[2:]
                # logger.info(" （2.1）采集项 %s 的byte1，转换为二进制最终值：%s" % (type, bin_byte1))
                if len(bin_byte1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte1))
                else:
                    append_string = ''
                bin_byte1 = append_string + bin_byte1[0:]
                logger.info(" （2.1）采集项 %s 的byte1，转换为二进制补位最终值：%s" % (type, bin_byte1))
                wanfenwei = bin_byte1[4:]
                # logger.info(wanfenwei)
                int_wanfenwei = int(wanfenwei, 2)
                logger.info(" （2.1）采集项 %s 的byte1的万分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_wanfenwei))
                qianfenwei = bin_byte1[0:4]
                # logger.info(qianfenwei)
                int_qianfenwei = int(qianfenwei, 2)
                logger.info(" （2.1）采集项 %s 的byte1的千分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_qianfenwei))

                # （2.2）无功功率1的 byte2（1B）
                byte2 = sj_list[12]
                logger.info(" （2.2）采集项 %s 的byte2：%s" % (type, byte2))
                bin_byte2 = bin(eval('0x' + byte2))
                # logger.info(" （2.2）采集项 %s 的byte2，转换为二进制：%s" % (type, bin_byte2))
                bin_byte2 = bin_byte2[2:]
                # logger.info(" （2.2）采集项 %s 的byte2，转换为二进制最终值：%s" % (type, bin_byte2))
                if len(bin_byte2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte2))
                else:
                    append_string = ''
                bin_byte2 = append_string + bin_byte2[0:]
                logger.info(" （2.2）采集项 %s 的byte2，转换为二进制补位最终值：%s" % (type, bin_byte2))
                baifenwei = bin_byte2[4:]
                # logger.info(baifenwei)
                int_baifenwei = int(baifenwei, 2)
                logger.info(" （2.2）采集项 %s 的byte2的百分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baifenwei))
                shifenwei = bin_byte2[0:4]
                # logger.info(shifenwei)
                int_shifenwei = int(shifenwei, 2)
                logger.info(" （2.2）采集项 %s 的byte2的十分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shifenwei))

                # （2.3）无功功率1的 byte3（1B）
                byte3 = sj_list[13]
                logger.info(" （2.3）采集项 %s 的byte3：%s" % (type, byte3))
                bin_byte3 = bin(eval('0x' + byte3))
                # logger.info(" （2.3）采集项 %s 的byte3，转换为二进制：%s" % (type, bin_byte3))
                bin_byte3 = bin_byte3[2:]
                # logger.info(" （2.3）采集项 %s 的byte3，转换为二进制最终值：%s" % (type, bin_byte3))
                if len(bin_byte3) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte3))
                else:
                    append_string = ''
                bin_byte3 = append_string + bin_byte3[0:]
                logger.info(" （2.3）采集项 %s 的byte3，转换为二进制补位最终值：%s" % (type, bin_byte3))
                gewei = bin_byte3[4:]
                # logger.info(gewei)
                int_gewei = int(gewei, 2)
                logger.info(" （2.3）采集项 %s 的byte3的个位，转换为二进制最终值，再转换为十进制：%s" % (type, int_gewei))
                shiwei = bin_byte3[1:4]
                # logger.info(shiwei)
                int_shiwei = int(shiwei, 2)
                logger.info(" （2.3）采集项 %s 的byte3的十位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwei))
                Swei = bin_byte3[0]
                # logger.info(Swei)
                int_Swei = int(Swei, 2)
                logger.info(" （2.3）采集项 %s 的byte3的S位，转换为二进制最终值，再转换为十进制：%s" % (type, int_Swei))

                # S的定义：S = 0，表示数据为正值，S = 1，表示数据为负值
                # 计算value值
                if int_Swei == 0:
                    cureve_value = int_shiwei*10+int_gewei*1+int_shifenwei/10+int_baifenwei/100+int_qianfenwei/1000+int_wanfenwei/10000
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                elif int_Swei == 1:
                    cureve_value = -(int_shiwei*10+int_gewei*1+int_shifenwei/10+int_baifenwei/100+int_qianfenwei/1000+int_wanfenwei/10000)
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                return int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm], int_sjdsn, ("20%s-%s-%s %s:%s" % (qssj[4], qssj[3], qssj[2], qssj[1], qssj[0])), cureve_value
        except Exception as e:
            logger.error("【异常】采集项%s不存在，报错：%s" % (type, e))

    # 见附录A.7   A相/B相/C相：电压
    def check_fn_89_91(self, data_list, type):
        logger.info("【采集项 %s 组成】：曲线类数据时标Td_c（7B）、采集项%s第1组数据（2B）....采集项%s第n组数据（2B）" % (type, type, type))
        sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, type)  # 得到从数据标识开始的剩余字符串
        logger.info("【非原报文】 采集项 %s 开始的数据（含数据标识）剩余报文部分：%s" % (type, sj_list))
        try:
            # （1）曲线类数据时标Td_c（7B） = 起始时间ts：分时日月年（5B） + 数据冻结密度m（1B） + 数据点数n（1B）
            Td_c = sj_list[4:11]
            # print(Td_c)
            logger.info("【采集项%s 曲线类数据时标Td_c 原报文】：%s" % (type, Td_c))
            # （1.1） 起始时间ts：分时日月年（5B）
            qssj = sj_list[4:9]
            # logger.info(" （1.1）采集项 %s 曲线类数据时标Td_c 的起始时间ts（分时日月年）：%s" % (type,qssj))
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的起始时间ts，即freezeTime值：20%s-%s-%s %s:%s" % (type, qssj[4], qssj[3], qssj[2], qssj[1], qssj[0]))
            # （1.2） 数据冻结密度m（1B）
            sjdjmdm = sj_list[9]
            int_sjdjmdm = int(sjdjmdm, 2)
            # logger.info(" （1.2）采集项 %s 曲线类数据时标Td_c 的数据冻结密度m：%s" % (type,int_sjdjmdm))
            sjdjmdm_dict = {
                0: "不冻结：每整点依次的冻结时刻无",
                1: "15：每整点依次的冻结时刻，15分，30分，45分，0分",
                2: "30：每整点依次的冻结时刻：30分，0分",
                3: "60：每整点依次的冻结时刻：0分",
                254: "5：每整点依次的冻结时刻：5分、10分、15分... 0分",
                255: "1：每整点依次的冻结时刻：1分、2分、3分... 0分",
                "其他": "备用"
            }
            if int_sjdjmdm in list(sjdjmdm_dict.keys()):
                logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s,表示：{ %s }" % (type, int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm]))
            else:
                logger.error("【错误】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m 不匹配" % type)
            # （1.3） 数据点数n（1B）
            sjdsn = sj_list[10]
            int_sjdsn = int(sjdsn, 2)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据点数n：%s，表示：{ 连续%s个点的曲线数据 }" % (type, int_sjdsn, int_sjdsn))

            # （2）电压数据1（2B）....电压数据n（2B），其中每个电压数据（2B）= byte1 + byte2
            logger.info("【采集项%s 纯数据原报文】：%s" % (type, sj_list[11:13]))
            if sj_list[11:13] in wujie:
                logger.info("【采集项%s 原报文】：%s 解析无数据" % (type, sj_list[11:13]))
                cureve_value = ""
                return cureve_value
            else:
                # （2.1）电压数据1的 byte1（1B）
                byte1 = sj_list[11]
                logger.info(" （2.1）采集项%s 的byte1：%s" % (type, byte1))
                bin_byte1 = bin(eval('0x' + byte1))
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制：%s" % (type, bin_byte1))
                bin_byte1 = bin_byte1[2:]
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制最终值：%s" % (type, bin_byte1))
                if len(bin_byte1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte1))
                else:
                    append_string = ''
                bin_byte1 = append_string + bin_byte1[0:]
                logger.info(" （2.1）采集项%s 的byte1，转换为二进制补位最终值：%s" % (type, bin_byte1))
                shifenwei = bin_byte1[4:]
                # logger.info(shifenwei)
                int_shifenwei = int(shifenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的十分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shifenwei))
                gewei = bin_byte1[0:4]
                # logger.info(gewei)
                int_gewei = int(gewei, 2)
                logger.info(" （2.1）采集项%s 的byte1的个位，转换为二进制最终值，再转换为十进制：%s" % (type, int_gewei))

                # （2.2）电压数据1的 byte2（1B）
                byte2 = sj_list[12]
                logger.info(" （2.2）采集项%s 的byte2：%s" % (type, byte2))
                bin_byte2 = bin(eval('0x' + byte2))
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制：%s" % (type, bin_byte2))
                bin_byte2 = bin_byte2[2:]
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制最终值：%s" % (type, bin_byte2))
                if len(bin_byte2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte2))
                else:
                    append_string = ''
                bin_byte2 = append_string + bin_byte2[0:]
                logger.info(" （2.2）采集项%s 的byte2，转换为二进制补位最终值：%s" % (type, bin_byte2))
                shiwei = bin_byte2[4:]
                # logger.info(shiwei)
                int_shiwei = int(shiwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的十位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwei))
                baiwei = bin_byte2[0:4]
                # logger.info(baiwei)
                int_baiwei = int(baiwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的百位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baiwei))
                # 计算value值
                cureve_value = int_baiwei * 100 + int_shiwei * 10 + int_gewei * 1 + int_shifenwei / 10
                # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                # logger.info(cureve_value)
                return int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm], int_sjdsn, ("20%s-%s-%s %s:%s" % (qssj[4], qssj[3], qssj[2], qssj[1], qssj[0])), cureve_value
        except Exception as e:
            logger.error("【异常】采集项%s不存在，报错：%s" % (type, e))

    # 见附录A.25  A相/B相/C相/零序：电流
    def check_fn_92_95(self, data_list, type):
        logger.info("【采集项 %s 组成】：曲线类数据时标Td_c（7B）、采集项%s第1组数据（3B）....采集项%s第n组数据（3B）" % (type, type, type))
        sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, type)  # 得到从数据标识开始的剩余字符串
        logger.info("【非原报文】 采集项 %s 开始的数据（含数据标识）剩余报文部分：%s" % (type, sj_list))
        try:
            # （1）曲线类数据时标Td_c（7B） = 起始时间ts：分时日月年（5B） + 数据冻结密度m（1B） + 数据点数n（1B）
            Td_c = sj_list[4:11]
            logger.info("【采集项%s 曲线类数据时标Td_c 原报文】：%s" % (type, Td_c))
            # （1.1） 起始时间ts：分时日月年（5B）
            qssj = sj_list[4:9]
            # logger.info(" （1.1）报文中曲线类数据时标Td_c 的起始时间ts（分时日月年）：%s" % qssj)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的起始时间ts，即freezeTime值：20%s-%s-%s %s:%s" % (type, qssj[4], qssj[3], qssj[2], qssj[1], qssj[0]))
            # （1.2） 数据冻结密度m（1B）
            sjdjmdm = sj_list[9]
            int_sjdjmdm = int(sjdjmdm, 2)
            # logger.info(" （1.2）报文中曲线类数据时标Td_c 的数据冻结密度m：%s" % int_sjdjmdm)
            sjdjmdm_dict = {
                0: "不冻结：每整点依次的冻结时刻无",
                1: "15：每整点依次的冻结时刻，15分，30分，45分，0分",
                2: "30：每整点依次的冻结时刻：30分，0分",
                3: "60：每整点依次的冻结时刻：0分",
                254: "5：每整点依次的冻结时刻：5分、10分、15分... 0分",
                255: "1：每整点依次的冻结时刻：1分、2分、3分... 0分",
                "其他": "备用"
            }
            if int_sjdjmdm in list(sjdjmdm_dict.keys()):
                logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s,表示：{ %s }" % (type, int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm]))
            else:
                logger.error("【错误】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m 不匹配" % type)
            # （1.3） 数据点数n（1B）
            sjdsn = sj_list[10]
            int_sjdsn = int(sjdsn, 2)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据点数n：%s，表示：{ 连续%s个点的曲线数据 }" % ((type, int_sjdsn, int_sjdsn)))

            # （2）电流数据1（3B）....电流数据n（3B），其中每个电流数据（3B）= byte1 + byte2 + byte3
            logger.info("【采集项 %s 纯数据原报文】：%s" % (type, sj_list[11:14]))
            if sj_list[11:14] in wujie:
                logger.info("【采集项%s 原报文】：%s 解析无数据" % (type, sj_list[11:14]))
                cureve_value = ""
                return cureve_value
            else:
                # （2.1）电流数据1的 byte1（1B）
                byte1 = sj_list[11]
                logger.info(" （2.1）采集项%s 的byte1：%s" % (type, byte1))
                bin_byte1 = bin(eval('0x' + byte1))
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制：%s" % (type, bin_byte1))
                bin_byte1 = bin_byte1[2:]
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制最终值：%s" % (type, bin_byte1))
                if len(bin_byte1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte1))
                else:
                    append_string = ''
                bin_byte1 = append_string + bin_byte1[0:]
                logger.info(" （2.1）采集项%s 的byte1，转换为二进制补位最终值：%s" % (type, bin_byte1))
                qianfenwei = bin_byte1[4:]
                # logger.info(qianfenwei)
                int_qianfenwei = int(qianfenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的千分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_qianfenwei))
                baifenwei = bin_byte1[0:4]
                # logger.info(baifenwei)
                int_baifenwei = int(baifenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的百分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baifenwei))

                # （2.2）电流数据1的 byte2（1B）
                byte2 = sj_list[12]
                logger.info(" （2.2）采集项%s 的byte2：%s" % (type, byte2))
                bin_byte2 = bin(eval('0x' + byte2))
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制：%s" % (type, bin_byte2))
                bin_byte2 = bin_byte2[2:]
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制最终值：%s" % (type, bin_byte2))
                if len(bin_byte2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte2))
                else:
                    append_string = ''
                bin_byte2 = append_string + bin_byte2[0:]
                logger.info(" （2.2）采集项%s 的byte2，转换为二进制补位最终值：%s" % (type, bin_byte2))
                shifenwei = bin_byte2[4:]
                # logger.info(shifenwei)
                int_shifenwei = int(shifenwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的十分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shifenwei))
                gewei = bin_byte2[0:4]
                # logger.info(gewei)
                int_gewei = int(gewei, 2)
                logger.info(" （2.2）采集项%s 的byte2的个位，转换为二进制最终值，再转换为十进制：%s" % (type, int_gewei))

                # （2.3）电流数据1的 byte3（1B）
                byte3 = sj_list[13]
                logger.info(" （2.3）采集项%s 的byte3：%s" % (type, byte3))
                bin_byte3 = bin(eval('0x' + byte3))
                # logger.info(" （2.3）采集项%s 的byte3，转换为二进制：%s" % (type, bin_byte3))
                bin_byte3 = bin_byte3[2:]
                # logger.info(" （2.3）采集项%s 的byte3，转换为二进制最终值：%s" % (type, bin_byte3))
                if len(bin_byte3) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte3))
                else:
                    append_string = ''
                bin_byte3 = append_string + bin_byte3[0:]
                logger.info(" （2.3）采集项%s 的byte3，转换为二进制补位最终值：%s" % (type, bin_byte3))
                shiwei = bin_byte3[4:]
                # logger.info(shiwei)
                int_shiwei = int(shiwei, 2)
                logger.info(" （2.3）采集项%s 的byte3的十位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwei))
                baiwei = bin_byte3[1:4]
                # logger.info(baiwei)
                int_baiwei = int(baiwei, 2)
                logger.info(" （2.3）采集项%s 的byte3的百位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baiwei))
                Swei = bin_byte3[0]
                # logger.info(Swei)
                int_Swei = int(Swei, 2)
                logger.info(" （2.3）采集项%s 的byte3的S位，转换为二进制最终值，再转换为十进制：%s" % (type, int_Swei))

                # S的定义：S = 0，表示数据为正值，S = 1，表示数据为负值
                # 计算value值
                if int_Swei == 0:
                    cureve_value = int_baiwei * 100 + int_shiwei * 10 + int_gewei * 1 + int_shifenwei / 10 + int_baifenwei / 100 + int_qianfenwei / 1000
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                elif int_Swei == 1:
                    cureve_value = -(int_baiwei * 100 + int_shiwei * 10 + int_gewei * 1 + int_shifenwei / 10 + int_baifenwei / 100 + int_qianfenwei / 1000)
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                return int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm], int_sjdsn, ("20%s-%s-%s %s:%s" % (qssj[4], qssj[3], qssj[2], qssj[1], qssj[0])), cureve_value
        except Exception as e:
            logger.error("【异常】采集项%s不存在，报错：%s" % (type, e))

    # 见附录A.11  正/反：有/无功电能示值
    def check_fn_101_104(self, data_list, type):
        logger.info("【采集项 %s 组成】：曲线类数据时标Td_c（7B）、采集项%s第1组数据（3B）....采集项%s第n组数据（3B）" % (type, type, type))
        sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, type)  # 得到从数据标识开始的剩余字符串
        logger.info("【非原报文】 采集项 %s 开始的数据（含数据标识）剩余报文部分：%s" % (type, sj_list))
        try:
            # （1）曲线类数据时标Td_c（7B） = 起始时间ts：分时日月年（5B） + 数据冻结密度m（1B） + 数据点数n（1B）
            Td_c = sj_list[4:11]
            logger.info("【采集项%s 曲线类数据时标Td_c 原报文】：%s" % (type,Td_c))
            # （1.1） 起始时间ts：分时日月年（5B）
            qssj = sj_list[4:9]
            # logger.info(" （1.1）采集项%s 曲线类数据时标Td_c 的起始时间ts（分时日月年）：%s" % qssj)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的起始时间ts，即freezeTime值：20%s-%s-%s %s:%s" % (type, qssj[4], qssj[3], qssj[2], qssj[1], qssj[0]))
            # （1.2） 数据冻结密度m（1B）
            sjdjmdm = sj_list[9]
            int_sjdjmdm = int(sjdjmdm, 2)
            logger.info(" （1.2）采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s" % (type,int_sjdjmdm))
            sjdjmdm_dict = {
                            0: "不冻结：每整点依次的冻结时刻无",
                            1: "15：每整点依次的冻结时刻，15分，30分，45分，0分",
                            2: "30：每整点依次的冻结时刻：30分，0分",
                            3: "60：每整点依次的冻结时刻：0分",
                            254: "5：每整点依次的冻结时刻：5分、10分、15分... 0分",
                            255: "1：每整点依次的冻结时刻：1分、2分、3分... 0分",
                            "其他": "备用"
            }
            if int_sjdjmdm in list(sjdjmdm_dict.keys()):
                logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s,表示：{ %s }" % (type, int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm]))
            else:
                logger.error("【错误】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m 不匹配" % type)
            # （1.3） 数据点数n（1B）
            sjdsn = sj_list[10]
            int_sjdsn = int(sjdsn, 2)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据点数n：%s，表示：{ 连续%s个点的曲线数据 }" % (type, int_sjdsn,int_sjdsn))

            # （2）电能示值1（4B）....电能示值n（4B），其中每个电能示值（4B）= byte1 + byte2 + byte3 + byte4
            logger.info("【采集项 %s 纯数据原报文】：%s" % (type, sj_list[11:15]))
            if sj_list[11:15] in wujie:
                logger.info("【采集项%s 原报文】：%s 解析无数据" % (type, sj_list[11:15]))
                cureve_value = ""
                return cureve_value
            else:
                # （2.1）电能示值1的 byte1（1B）
                byte1 = sj_list[11]
                logger.info(" （2.1）采集项%s 的byte1：%s" % (type, byte1))
                bin_byte1 = bin(eval('0x' + byte1))
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制：%s" % (type, bin_byte1))
                bin_byte1 = bin_byte1[2:]
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制最终值：%s" % (type, bin_byte1))
                if len(bin_byte1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte1))
                else:
                    append_string = ''
                bin_byte1 = append_string + bin_byte1[0:]
                logger.info(" （2.1）采集项%s 的byte1，转换为二进制补位最终值：%s" % (type, bin_byte1))
                baifenwei = bin_byte1[4:]
                # logger.info(baifenwei)
                int_baifenwei = int(baifenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的百分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baifenwei))
                shifenwei = bin_byte1[0:4]
                # logger.info(shifenwei)
                int_shifenwei = int(shifenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的十分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shifenwei))

                # （2.2）电能示值1的 byte2（1B）
                byte2 = sj_list[12]
                logger.info(" （2.2）采集项%s 的byte2：%s" % (type, byte2))
                bin_byte2 = bin(eval('0x' + byte2))
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制：%s" % (type, bin_byte2))
                bin_byte2 = bin_byte2[2:]
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制最终值：%s" % (type, bin_byte2))
                if len(bin_byte2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte2))
                else:
                    append_string = ''
                bin_byte2 = append_string + bin_byte2[0:]
                logger.info(" （2.2）采集项%s 的byte2，转换为二进制补位最终值：%s" % (type, bin_byte2))
                gewei = bin_byte2[4:]
                # logger.info(gewei)
                int_gewei = int(gewei, 2)
                logger.info(" （2.2）采集项%s 的byte2的个位，转换为二进制最终值，再转换为十进制：%s" % (type, int_gewei))
                shiwei = bin_byte2[0:4]
                # logger.info(shiwei)
                int_shiwei = int(shiwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的十位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwei))

                # （2.3）电能示值1的 byte3（1B）
                byte3 = sj_list[13]
                logger.info(" （2.3）采集项%s 的byte3：%s" % (type, byte3))
                bin_byte3 = bin(eval('0x' + byte3))
                # logger.info(" （2.3）采集项%s 的byte3，转换为二进制：%s" % (type, bin_byte3))
                bin_byte3 = bin_byte3[2:]
                # logger.info(" （2.3）采集项%s 的byte3，转换为二进制最终值：%s" % (type, bin_byte3))
                if len(bin_byte3) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte3))
                else:
                    append_string = ''
                bin_byte3 = append_string + bin_byte3[0:]
                logger.info(" （2.3）采集项%s 的byte3，转换为二进制补位最终值：%s" % (type, bin_byte3))
                baiwei = bin_byte3[4:]
                # logger.info(baiwei)
                int_baiwei = int(baiwei, 2)
                logger.info(" （2.3）采集项%s 的byte3的百位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baiwei))
                qianwei = bin_byte3[1:4]
                # logger.info(qianwei)
                int_qianwei = int(qianwei, 2)
                logger.info(" （2.3）采集项%s 的byte3的千位，转换为二进制最终值，再转换为十进制：%s" % (type, int_qianwei))

                # （2.4）电能示值1的 byte4（1B）
                byte4 = sj_list[14]
                logger.info(" （2.4）采集项%s 的byte4：%s" % (type, byte4))
                bin_byte4 = bin(eval('0x' + byte4))
                # logger.info(" （2.4）采集项%s 的byte4，转换为二进制：%s" % (type, bin_byte4))
                bin_byte4 = bin_byte4[2:]
                # logger.info(" （2.4）采集项%s 的byte4，转换为二进制最终值：%s" % (type, bin_byte4))
                if len(bin_byte4) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte4))
                else:
                    append_string = ''
                bin_byte4 = append_string + bin_byte4[0:]
                logger.info(" （2.4）采集项%s 的byte4，转换为二进制补位最终值：%s" % (type, bin_byte4))
                wanwei = bin_byte4[4:]
                # logger.info(wanwei)
                int_wanwei = int(wanwei, 2)
                logger.info(" （2.4）采集项%s 的byte4的万位，转换为二进制最终值，再转换为十进制：%s" % (type, int_wanwei))
                shiwanwei = bin_byte4[1:4]
                # logger.info(shiwanwei)
                int_shiwanwei = int(shiwanwei, 2)
                logger.info(" （2.4）采集项%s 的byte4的十万位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwanwei))

                # 计算value值
                cureve_value = int_shiwanwei*100000 + int_wanwei*10000 + int_qianwei*1000 + int_baiwei*100 + int_shiwei*10 + int_gewei*1 + int_shifenwei/10 + int_baifenwei/100
                # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                return int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm], int_sjdsn, ("20%s-%s-%s %s:%s" % (qssj[4], qssj[3], qssj[2], qssj[1], qssj[0])), cureve_value
        except Exception as e:
            logger.error("【异常】采集项%s不存在，报错：%s" % (type, e))

    # 见附录A.5   总/A相/B相/C相：功率因数
    def check_fn_105_108(self, data_list, type):
        logger.info("【采集项 %s 组成】：曲线类数据时标Td_c（7B）、采集项%s第1组数据（2B）....采集项%s第n组数据（2B）" % (type, type, type))
        sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, type)  # 得到从数据标识开始的剩余字符串
        logger.info("【非原报文】 采集项 %s 开始的数据（含数据标识）剩余报文部分：%s" % (type, sj_list))
        try:
            # （1）曲线类数据时标Td_c（7B） = 起始时间ts：分时日月年（5B） + 数据冻结密度m（1B） + 数据点数n（1B）
            Td_c = sj_list[4:11]
            logger.info("【采集项%s 曲线类数据时标Td_c 原报文】：%s" % (type, Td_c))
            # （1.1） 起始时间ts：分时日月年（5B）
            qssj = sj_list[4:9]
            # logger.info(" （1.1）采集项%s 曲线类数据时标Td_c 的起始时间ts（分时日月年）：%s" % (type, qssj))
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的起始时间ts，即freezeTime值：20%s-%s-%s %s:%s" % (type, qssj[4], qssj[3], qssj[2], qssj[1], qssj[0]))
            # （1.2） 数据冻结密度m（1B）
            sjdjmdm = sj_list[9]
            int_sjdjmdm = int(sjdjmdm, 2)
            # logger.info(" （1.2）采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s" % (type, int_sjdjmdm))
            sjdjmdm_dict = {
                            0: "不冻结：每整点依次的冻结时刻无",
                            1: "15：每整点依次的冻结时刻，15分，30分，45分，0分",
                            2: "30：每整点依次的冻结时刻：30分，0分",
                            3: "60：每整点依次的冻结时刻：0分",
                            254: "5：每整点依次的冻结时刻：5分、10分、15分... 0分",
                            255: "1：每整点依次的冻结时刻：1分、2分、3分... 0分",
                            "其他": "备用"
            }
            if int_sjdjmdm in list(sjdjmdm_dict.keys()):
                logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m：%s,表示：{ %s }" % (type, int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm]))
            else:
                logger.error("【错误】 采集项%s 曲线类数据时标Td_c 的数据冻结密度m 不匹配" % type)
            # （1.3） 数据点数n（1B）
            sjdsn = sj_list[10]
            int_sjdsn = int(sjdsn, 2)
            logger.info("【正常】 采集项%s 曲线类数据时标Td_c 的数据点数n：%s，表示：{ 连续%s个点的曲线数据 }" % (type, int_sjdsn,int_sjdsn))

            # （2）功率因数1（2B）....功率因数n（4B），其中每个功率因数（2B）= byte1 + byte2
            logger.info("【采集项 %s 纯数据原报文】：%s" % (type, sj_list[11:13]))
            if sj_list[11:13] in wujie:
                logger.info("【采集项%s 原报文】：%s 解析无数据" % (type, sj_list[11:13]))
                cureve_value = ""
                return cureve_value
            else:
                # （2.1）无功功率1的 byte1（1B）
                byte1 = sj_list[11]
                logger.info(" （2.1）采集项%s 的byte1：%s" % (type, byte1))
                bin_byte1 = bin(eval('0x' + byte1))
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制：%s" % (type, bin_byte1))
                bin_byte1 = bin_byte1[2:]
                # logger.info(" （2.1）采集项%s 的byte1，转换为二进制最终值：%s" % (type, bin_byte1))
                if len(bin_byte1) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte1))
                else:
                    append_string = ''
                bin_byte1 = append_string + bin_byte1[0:]
                logger.info(" （2.1）采集项%s 的byte1，转换为二进制补位最终值：%s" % (type, bin_byte1))
                shifenwei = bin_byte1[4:]
                # logger.info(shifenwei)
                int_shifenwei = int(shifenwei, 2)
                logger.info(" （2.1）采集项%s 的byte1的十分位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shifenwei))
                gewei = bin_byte1[0:4]
                # logger.info(gewei)
                int_gewei = int(gewei, 2)
                logger.info(" （2.1）采集项%s 的byte1的个位，转换为二进制最终值，再转换为十进制：%s" % (type, int_gewei))

                # （2.2）无功功率1的 byte2（1B）
                byte2 = sj_list[12]
                logger.info(" （2.2）采集项%s 的byte2：%s" % (type, byte2))
                bin_byte2 = bin(eval('0x' + byte2))
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制：%s" % (type, bin_byte2))
                bin_byte2 = bin_byte2[2:]
                # logger.info(" （2.2）采集项%s 的byte2，转换为二进制最终值：%s" % (type, bin_byte2))
                if len(bin_byte2) != 8:
                    append_string = analyze_base.generate_append_string(len(bin_byte2))
                else:
                    append_string = ''
                bin_byte2 = append_string + bin_byte2[0:]
                logger.info(" （2.2）采集项%s 的byte2，转换为二进制补位最终值：%s" % (type, bin_byte2))
                shiwei = bin_byte2[4:]
                # logger.info(shiwei)
                int_shiwei = int(shiwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的十位，转换为二进制最终值，再转换为十进制：%s" % (type, int_shiwei))
                baiwei = bin_byte2[1:4]
                # logger.info(baiwei)
                int_baiwei = int(baiwei, 2)
                logger.info(" （2.2）采集项%s 的byte2的百位，转换为二进制最终值，再转换为十进制：%s" % (type, int_baiwei))
                Swei = bin_byte2[0]
                # logger.info(Swei)
                int_Swei = int(Swei, 2)
                logger.info(" （2.2）采集项%s 的byte2的S位，转换为二进制最终值，再转换为十进制：%s" % (type, int_Swei))

                # S的定义：S = 0，表示数据为正值，S = 1，表示数据为负值
                # 计算value值
                if int_Swei == 0:
                    cureve_value = (int_baiwei * 100 + int_shiwei * 10 + int_gewei * 1 + int_shifenwei / 10)/100
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                elif int_Swei == 1:
                    cureve_value = -(int_baiwei * 100 + int_shiwei * 10 + int_gewei * 1 + int_shifenwei / 10)/100
                    # print("采集项 %s 的cureveValue值：%s" % (type, cureve_value))
                return int_sjdjmdm, sjdjmdm_dict[int_sjdjmdm], int_sjdsn, ("20%s-%s-%s %s:%s" % (qssj[4], qssj[3], qssj[2], qssj[1], qssj[0])), cureve_value
        except Exception as e:
            logger.error("【异常】采集项%s不存在，报错：%s" % (type, e))


# 自测
if __name__ == '__main__':
    analyze_fn_0d_define = AnalyzeFnOdDefine()
    # # 1、读取报文
    # # （1）拆分报文
    # data_list = analyze_base.get_data_list_conf("101")
    # # 2、详解采集项
    # analyze_fn_0d_define.check_fn_101_104(data_list, 101)

    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen0dH")
    # 2、详解采集项
    logger.info("-------------- 采集项：解析 --------------")
    analyze_fn_0d_define.check_fn_77_88(data_list, 81)  # 读取完整报文，但是要单独指定采集项
    analyze_fn_0d_define.check_fn_89_91(data_list, 89)  # 读取完整报文，但是要单独指定采集项
    analyze_fn_0d_define.check_fn_92_95(data_list, 95)  # 读取完整报文，但是要单独指定采集项
    analyze_fn_0d_define.check_fn_89_91(data_list, 96)  # 读取完整报文，但是要单独指定采集项
    analyze_fn_0d_define.check_fn_101_104(data_list, 101)  # 读取完整报文，但是要单独指定采集项
    analyze_fn_0d_define.check_fn_105_108(data_list, 106)  # 读取完整报文，但是要单独指定采集项
