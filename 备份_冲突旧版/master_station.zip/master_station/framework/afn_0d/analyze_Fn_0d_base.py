#!/usr/bin/python
# coding: utf-8
from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL
logger = Logger(logger="AnalyzeFnOdBase").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()


# 【截取】 AFN=0dH 完整报文 --> Fn解析 --> 截图从纯数据开始的报文 （最终得到xx采集项，从数据标识开始的剩余部分报文）
class AnalyzeFnOdBase(object):

    # 1、根据报文的数据标识位（4B） ,得到标识的最后一个 index 下标  {1、为获取真实数据报文做准备}
    def get_Fn_element_index(self, data_list, byte1, byte2, byte3, byte4):  # 01 01 01 0a
        for (i1, element1) in enumerate(data_list):
            # logger.info(str(i1) + " " + element1)
            if element1 == byte1:
                for (i2, element2) in enumerate(data_list):
                    if element2 == byte2 and i2 == i1+1:
                        for (i3, element3) in enumerate(data_list):
                            if element3 == byte3 and i3 == i2+1:
                                for (i4, element4) in enumerate(data_list):
                                    if element4 == byte4 and i4 == i3+1:
                                        # logger.info("数据标识最后一位：index是" +str(i4) + "，value是" + element4)
                                        return i4, element4

    # 2、根据步骤1得到的下标+1，计算出对应范围的数据（不含数据标识）的第一个 index 下标  {2、获取真实数据报文的index}
    def get_Fn_data_start_index(self, data_list, type, byte1, byte2, byte3, byte4):
        try:
            element_index = self.get_Fn_element_index(data_list,  byte1, byte2, byte3, byte4)
            # 注意此处是数据标识的下一位，数据的第一位，不能搞错
            data_start_index = element_index[0] + 1
            logger.info("【原报文】 采集项 %s 在纯数据部分（不用含数据标识）index起始位置是：%d" % (type, data_start_index))
            return data_start_index
        except Exception as e:
            logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))

    # 【暂时未用】3、根据步骤2得到的下标：截取以数据标识开始的报文  {3、获取真实数据报文}
    def get_Fn_data(self, data_list):
        result = analyze_fixed_not.check_biaoshi(data_list)
        Fn = str(result[0])
        a = str(result[2])   # if str(result[2]) == "01":  print("pass")
        b = str(result[3])
        c = str(result[4])
        d = str(result[5])
        if (a == "01") and (b == "01") and (c == "10") and (d == "09"):  # type == 77
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 18
            sj_list = data_list[data_start_index - 4:]   # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "20") and (d == "09"):  # type == 78
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 32
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "40") and (d == "09"):  # type == 79
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 46
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "80") and (d == "09"):  # type == 80
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 60
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "01") and (d == "0a"):  # type == 81
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 74
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "02") and (d == "0a"):  # type == 82
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 88
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "04") and (d == "0a"):  # type == 83
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 102
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "08") and (d == "0a"):  # type == 84
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 116
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "10") and (d == "0a"):  # type == 85
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 130
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "20") and (d == "0a"):  # type == 86
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 144
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "40") and (d == "0a"):  # type == 87
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 158
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "80") and (d == "0a"):  # type == 88
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 172
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "01") and (d == "0b"):  # type == 89
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 186
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "02") and (d == "0b"):  # type == 90
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 199
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "04") and (d == "0b"):  # type == 91
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 212
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "08") and (d == "0b"):  # type == 92
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 225
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "10") and (d == "0b"):  # type == 93
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 239
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "20") and (d == "0b"):  # type == 94
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 253
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "40") and (d == "0b"):  # type == 95
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 267
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "80") and (d == "0b"):  # type == 96
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 281
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "10") and (d == "0c"):  # type == 101
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 294
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "20") and (d == "0c"):  # type == 102
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 309
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "40") and (d == "0c"):  # type == 103
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 324
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "80") and (d == "0c"):  # type == 104
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 339
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "01") and (d == "0d"):  # type == 105
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 354
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "02") and (d == "0d"):  # type == 106
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 367
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "04") and (d == "0d"):  # type == 107
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 380
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        if (a == "01") and (b == "01") and (c == "08") and (d == "0d"):  # type == 108
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 393
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list

    # 3、根据步骤2得到的下标：截取以（指定type）数据标识开始的报文  {3、获取真实数据报文}
    def get_Fn_data_type(self, data_list, type):
        Fn = type
        if type == 77:
            a = "01"
            b = "01"
            c = "10"
            d = "09"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 18
                sj_list = data_list[data_start_index - 4:]   # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 78:
            a = "01"
            b = "01"
            c = "20"
            d = "09"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 32
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 79:
            a = "01"
            b = "01"
            c = "40"
            d = "09"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 46
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 80:
            a = "01"
            b = "01"
            c = "80"
            d = "09"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 60
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 81:
            a = "01"
            b = "01"
            c = "01"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 74
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 82:
            a = "01"
            b = "01"
            c = "02"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 88
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 83:
            a = "01"
            b = "01"
            c = "04"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 102
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 84:
            a = "01"
            b = "01"
            c = "08"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 116
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 85:
            a = "01"
            b = "01"
            c = "10"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 130
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 86:
            a = "01"
            b = "01"
            c = "20"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 144
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 87:
            a = "01"
            b = "01"
            c = "40"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 158
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 88:
            a = "01"
            b = "01"
            c = "80"
            d = "0a"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 172
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 89:
            a = "01"
            b = "01"
            c = "01"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 186
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 90:
            a = "01"
            b = "01"
            c = "02"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 199
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 91:
            a = "01"
            b = "01"
            c = "04"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 212
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 92:
            a = "01"
            b = "01"
            c = "08"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 225
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 93:
            a = "01"
            b = "01"
            c = "10"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 239
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 94:
            a = "01"
            b = "01"
            c = "20"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 253
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 95:
            a = "01"
            b = "01"
            c = "40"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 267
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 96:
            a = "01"
            b = "01"
            c = "80"
            d = "0b"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 281
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 101:
            a = "01"
            b = "01"
            c = "10"
            d = "0c"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 294
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 102:
            a = "01"
            b = "01"
            c = "20"
            d = "0c"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 309
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 103:
            a = "01"
            b = "01"
            c = "40"
            d = "0c"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 324
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 104:
            a = "01"
            b = "01"
            c = "80"
            d = "0c"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 339
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 105:
            a = "01"
            b = "01"
            c = "01"
            d = "0d"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 354
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 106:
            a = "01"
            b = "01"
            c = "02"
            d = "0d"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 367
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 107:
            a = "01"
            b = "01"
            c = "04"
            d = "0d"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 380
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))
        if type == 108:
            a = "01"
            b = "01"
            c = "08"
            d = "0d"
            try:
                data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)  # 393
                sj_list = data_list[data_start_index - 4:]  # print(sj_list)
                return sj_list
            except Exception as e:
                logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))


if __name__ == '__main__':
    analyze_fn_0d_base = AnalyzeFnOdBase()
    # # 1、读取报文
    # # （1）拆分报文
    # data_list = analyze_base.get_data_list_conf("89")
    # # 2、截取采集项剩余报文（含数据标识）
    # # （2）需要指定采集项
    # sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, 89)  # 得到从数据标识开始的剩余字符串
    # print("【截取】所需采集项报文：%s" % sj_list)

    # 1、读取报文
    # （1）完整报文
    data_list = analyze_base.get_data_list_conf("baowen0dH")
    # 2、截取采集项剩余报文（含数据标识）
    # （1）【暂未用】不需要指定采集项
    # sj_list = analyze_fn_0d_base.get_Fn_data(data_list)  # (单)得到从数据标识开始的剩余字符串
    # （2）需要指定采集项
    logger.info("-------------- 从数据标识开始剩余报文 --------------")
    sj_list = analyze_fn_0d_base.get_Fn_data_type(data_list, 81)  # 得到从数据标识开始的剩余字符串
    print("【截取】所需采集项报文：%s" % sj_list)

    # 3、获取采集项对应数据开始的index标识位
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 77, "01", "01", "10", "09")  # 18
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 78, "01", "01", "20", "09")  # 32
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 79, "01", "01", "40", "09")  # 46
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 80, "01", "01", "80", "09")  # 60
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 81, "01", "01", "01", "0a")  # 74
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 82, "01", "01", "02", "0a")  # 88
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 83, "01", "01", "04", "0a")  # 102
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 84, "01", "01", "08", "0a")  # 116
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 85, "01", "01", "10", "0a")  # 130
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 86, "01", "01", "20", "0a")  # 144
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 87, "01", "01", "40", "0a")  # 158
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 88, "01", "01", "80", "0a")  # 172
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 89, "01", "01", "01", "0b")  # 186
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 90, "01", "01", "02", "0b")  # 199
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 91, "01", "01", "04", "0b")  # 212
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 92, "01", "01", "08", "0b")  # 225
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 93, "01", "01", "10", "0b")  # 239
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 94, "01", "01", "20", "0b")  # 253
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 95, "01", "01", "40", "0b")  # 267
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 96, "01", "01", "80", "0b")  # 281
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 101, "01", "01", "10", "0c")  # 294
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 102, "01", "01", "20", "0c")  # 309
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 103, "01", "01", "40", "0c")  # 324
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 104, "01", "01", "80", "0c")  # 339
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 105, "01", "01", "01", "0d")  # 354
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 106, "01", "01", "02", "0d")  # 367
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 107, "01", "01", "04", "0d")  # 380
    # data_start_index = analyze_fn_0d_base.get_Fn_data_start_index(data_list, 108, "01", "01", "08", "0d")  # 393

    # 【暂时未用】
    def get_sj_list(self, data_list, type, a, b, c, d):
        print("type=%d" % type)
        print("a=%s" % a)
        print("b=%s" % b)
        print("c=%s" % c)
        print("d=%s" % d)
        Fn = type
        try:
            data_start_index = self.get_Fn_data_start_index(data_list, Fn, a, b, c, d)
            sj_list = data_list[data_start_index - 4:]  # print(sj_list)
            return sj_list
        except Exception as e:
            logger.error("【异常】采集项 %s不存在，报错：%s" % (type, e))

    # 【暂时未用】3、根据步骤2得到的下标：截取以（指定type）数据标识开始的报文  {3、获取真实数据报文}
    def get_Fn_data_type2(self, data_list, type):
        if type == 77:  # 18
            a = "01"
            b = "01"
            c = "10"
            d = "09"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 78:  # 32
            a = "01"
            b = "01"
            c = "20"
            d = "09"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 79:  # 46
            a = "01"
            b = "01"
            c = "40"
            d = "09"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 80:  # 60
            a = "01"
            b = "01"
            c = "80"
            d = "09"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 81:  # 74
            a = "01"
            b = "01"
            c = "01"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 82:  # 88
            a = "01"
            b = "01"
            c = "02"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 83:   # 102
            a = "01"
            b = "01"
            c = "04"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 84:  # 116
            a = "01"
            b = "01"
            c = "08"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 85:   # 130
            a = "01"
            b = "01"
            c = "10"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 86:   # 144
            a = "01"
            b = "01"
            c = "20"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 87:   # 158
            a = "01"
            b = "01"
            c = "40"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 88:  # 172
            a = "01"
            b = "01"
            c = "80"
            d = "0a"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 89:    # 186
            a = "01"
            b = "01"
            c = "01"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 90:  # 199
            a = "01"
            b = "01"
            c = "02"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 91:   # 212
            a = "01"
            b = "01"
            c = "04"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 92:  # 225
            a = "01"
            b = "01"
            c = "08"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 93:    # 239
            a = "01"
            b = "01"
            c = "10"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 94:   # 253
            a = "01"
            b = "01"
            c = "20"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 95:   # 267
            a = "01"
            b = "01"
            c = "40"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 96:   # 281
            a = "01"
            b = "01"
            c = "80"
            d = "0b"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 101:  # 294
            a = "01"
            b = "01"
            c = "10"
            d = "0c"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 102:   # 309
            a = "01"
            b = "01"
            c = "20"
            d = "0c"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 103:   # 324
            a = "01"
            b = "01"
            c = "40"
            d = "0c"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 104:   # 339
            a = "01"
            b = "01"
            c = "80"
            d = "0c"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 105:   # 354
            a = "01"
            b = "01"
            c = "01"
            d = "0d"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 106:   # 367
            a = "01"
            b = "01"
            c = "02"
            d = "0d"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 107:   # 380
            a = "01"
            b = "01"
            c = "04"
            d = "0d"
            self.get_sj_list(data_list, type, a, b, c, d)
        if type == 108:   # 393
            a = "01"
            b = "01"
            c = "08"
            d = "0d"
            self.get_sj_list(data_list, type, a, b, c, d)
