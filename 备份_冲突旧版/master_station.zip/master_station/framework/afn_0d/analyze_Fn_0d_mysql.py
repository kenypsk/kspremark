#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue
from master_station.framework.afn_0d.analyze_Fn_0d_base import AnalyzeFnOdBase

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_0d.analyze_Fn_0d_define import AnalyzeFnOdDefine
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnOdMySQL").getlog()
base_conf = BaseConf()
base_mysql = BaseMySQL()
select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_0d_base = AnalyzeFnOdBase()
analyze_fn_0d_define = AnalyzeFnOdDefine()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 针对AFN=0dH的完整报文：Fn详细解析，通过analyze_fn_0d_base类截图计算所需报文，最终得到curveValue
class AnalyzeFnOdMySQL(object):

    # 0.2、数据库实际存储
    def test_mysql(self, sql):
        mysql = base_mysql.mysql_connect('192.168.11.225', 'masterstation', '123456', 'masterstation', 3306)  # 测试通过
        # con = mysql[0]
        cur = mysql[1]
        sql_result = select_mysql.get_mysql_data(sql, cur)
        if sql_result == "":
            logger.info("【正常】 查询出数据为 null")
        else:
            logger.info("【正常】 查询成功")
        return sql_result

    # 0.3、比较，两者是否匹配
    def compare_vaule(self, js_curveValue, curveValue):
        if (js_curveValue == "") or (curveValue == ""):
            logger.error("【异常】 存在某个数据为 null")
        elif js_curveValue == curveValue:
            logger.info("【匹配】 该采集项数据匹配，计算值js_curveValue：%f，数据库值curveValue：%f" % (js_curveValue, curveValue))
        else:
            logger.info("【不匹配】 该采集项数据不匹配，计算值js_curveValue：%f，而数据库值curveValue：%f" % (js_curveValue, curveValue))


# 自测
if __name__ == '__main__':
    analyze_fn_0d_mysql = AnalyzeFnOdMySQL()
    # 针对拆分报文
    # 1、读取报文
    # （1）拆分报文
    data_list = analyze_base.get_data_list_conf("89")

    # 针对完整报文
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen0dH")
    # 2、解析报文：采集项数据

    # 2、查询
    sql = ""
    analyze_fn_0d_mysql.test_mysql(sql)
