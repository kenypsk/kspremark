#!/usr/bin/python
# coding: utf-8
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_00.analyze_Fn_00 import AnalyzeFnO0
from master_station.framework.afn_02.analyze_Fn_02 import AnalyzeFnO2
from master_station.framework.afn_04.analyze_Fn_04 import AnalyzeFnO4
from master_station.framework.afn_0d.analyze_Fn_0d import AnalyzeFnOd
from master_station.framework.common.analyze_base import AnalyzeBase
from master_station.framework.common.analyze_fixed import AnalyzeFixed
from master_station.framework.common.analyze_fixed_not import AnalyzeFixedNot

logger = Logger(logger="AnalyzeFrame").getlog()
analyze_base = AnalyzeBase()
analyze_fixed = AnalyzeFixed()
analyze_fixed_not = AnalyzeFixedNot()
analyze_fn_00 = AnalyzeFnO0()
analyze_fn_02 = AnalyzeFnO2()
analyze_fn_04 = AnalyzeFnO4()
analyze_fn_0d = AnalyzeFnOd()


class AnalyzeFrame(object):
    def test_jiexi_00H(self):
        logger.info("******************** start ********************")
        logger.info("******************** 【读取】：0、读取配置文件：得到完整报文 ********************")
        data_list = analyze_base.get_data_list_conf("baowen00H")
        logger.info("******************** 【解析】：1、根据固定报文：得到AFN、Fn ********************")
        analyze_fixed.test_analyze_fixed(data_list)
        logger.info("******************** 【解析】：2、根据非固定报文：得到Fn含义  ********************")
        analyze_fixed_not.test_analyze_fixed_not(data_list)
        logger.info("******************** 【解析】：3、详解  ********************")
        analyze_fn_00.test_analyze_fn_00(data_list)
        logger.info("******************** end ********************")

    def test_jiexi_02H(self):
        logger.info("******************** start ********************")
        logger.info("******************** 【读取】：0、读取配置文件：得到完整报文 ********************")
        data_list = analyze_base.get_data_list_conf("baowen02H")
        logger.info("******************** 【解析】：1、根据固定报文：得到AFN、Fn ********************")
        analyze_fixed.test_analyze_fixed(data_list)
        logger.info("******************** 【解析】：2、根据非固定报文：得到Fn含义  ********************")
        analyze_fixed_not.test_analyze_fixed_not(data_list)
        logger.info("******************** 【解析】：3、详解  ********************")
        analyze_fn_02.test_analyze_fn_02(data_list)
        logger.info("******************** end ********************")

    def test_jiexi_04H(self):
        logger.info("******************** start ********************")
        logger.info("******************** 【读取】：0、读取配置文件：得到完整报文 ********************")
        data_list = analyze_base.get_data_list_conf("baowen04H")
        logger.info("******************** 【解析】：1、根据固定报文：得到AFN、Fn ********************")
        analyze_fixed.test_analyze_fixed(data_list)
        logger.info("******************** 【解析】：2、根据非固定报文：得到Fn含义  ********************")
        analyze_fixed_not.test_analyze_fixed_not(data_list)
        logger.info("******************** 【解析】：3、详解  ********************")
        analyze_fn_04.test_analyze_fn_04(data_list)
        logger.info("******************** end ********************")

    def test_jiexi_0dH(self):
        logger.info("******************** start ********************")
        logger.info("******************** 【读取】：0、读取配置文件：得到完整报文 ********************")
        data_list = analyze_base.get_data_list_conf("baowen0dH")
        logger.info("******************** 【解析】：1、根据固定报文：得到AFN、Fn ********************")
        analyze_fixed.test_analyze_fixed(data_list)
        logger.info("******************** 【解析】：2、根据非固定报文：得到Fn含义  ********************")
        analyze_fixed_not.test_analyze_fixed_not(data_list)
        logger.info("******************** 【计算】：3、根据AFN、Fn：得到curveValue ********************")
        analyze_fn_0d.test_analyze_fn_0d(data_list, 81)  # 目前针对采集完整28项的报文，只能得到第一个77的值
        logger.info("******************** end ********************")


if __name__ == '__main__':
    analyze_frame = AnalyzeFrame()
    analyze_frame.test_jiexi_00H()
    analyze_frame.test_jiexi_02H()
    analyze_frame.test_jiexi_04H()
    analyze_frame.test_jiexi_0dH()
