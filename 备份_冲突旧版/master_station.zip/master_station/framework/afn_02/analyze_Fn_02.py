#!/usr/bin/python
# coding: utf-8
# 仅适用于 应用层功能码 AFN 是 0dH 的报文 【是数据0+d】
# 【完整】完整报文，验证所有采集项 curveValue

from config_demo.framework.config.base_conf import BaseConf
from logger_demo.framework.log.logger import Logger
from master_station.framework.afn_02.analyze_Fn_02_base import AnalyzeFnO2Base
from master_station.framework.common.analyze_base import AnalyzeBase
from mysql_demo.framework.mysql.base_mysql import BaseMySQL
from mysql_demo.framework.mysql.select_mysql import SelectMySQL

logger = Logger(logger="AnalyzeFnO2").getlog()
base_conf = BaseConf()
# base_mysql = BaseMySQL()
# select_mysql = SelectMySQL()
analyze_base = AnalyzeBase()
analyze_fn_02_base = AnalyzeFnO2Base()
wujie = (['ee', 'ee', 'ee', 'ee'], ['ee', 'ee', 'ee'], ['ee', 'ee'], ['ff', 'ff'])


# 【解析】 AFN=0dH 纯数据报文  --> Fn解析 --> 得到各采集项curveValue （通过analyze_fn_0d_list类截图计算所需报文，Fn详细解析）
class AnalyzeFnO2(object):

    # 【汇总】
    def test_analyze_fn_02(self, data_list):
        logger.info("-------------- Fn ：计算 -------------")
        analyze_fn_02_base.check_02_Fn(data_list)


# 自测
if __name__ == '__main__':
    analyze_fn_02 = AnalyzeFnO2()
    # 1、读取报文
    # （2）完整报文
    data_list = analyze_base.get_data_list_conf("baowen02H")
    # 2、详解报文
    analyze_fn_02.test_analyze_fn_02(data_list)
