#!/usr/bin/python
# coding: utf-8
# import sys
import datetime
import os
from xlrd import open_workbook
from xlutils.copy import copy
base_dir = os.path.abspath(os.path.join(os.getcwd(), "../.."))
baowen_dir = "data"
baowen_name = "baowen.xls"
baowen = base_dir + "/" + baowen_dir + "/" + baowen_name
init_list = ['00', '05']
max_count = 20
# max_count = int(sys.argv[1])


# 【模拟】模拟构建终端上传报文
class GenerateBaoWen(object):
    iteration = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e']
    read_excel = open_workbook(baowen)
    excel = copy(read_excel)
    table = excel.get_sheet(0)

    # 公共：计算 CS
    def calculate_CS(self, data_list):
        user_data = data_list[6:-2]
        hex_user_data = ['0x' + item for item in user_data]
        byte_sum = sum([eval(value) for value in hex_user_data])
        byte_str = hex(byte_sum)
        CS = byte_str[-2:]
        return CS

    # 1、构建登录报文（1条）
    def generate_login_frame(self, te_address, hang):
        sam_login_head = ['68', '32', '00', '32', '00', '68', 'c9']
        sam_login_midd = ['00', '02', '70', '00', '00', '01', '00']
        sam_login_end = ['16']
        temp_CS = ['xx']
        temp_frame = sam_login_head + te_address + sam_login_midd + temp_CS + sam_login_end
        temp_CS[0] = self.calculate_CS(temp_frame)
        # print(temp_CS)   # 打印计算出的校验和CS
        temp_frame = sam_login_head + te_address + sam_login_midd + temp_CS + sam_login_end
        # print(temp_frame)  # 打印出构建心跳报文list
        login_frame = ''
        for item in temp_frame:
            login_frame = login_frame + item   # 存入excel的报文格式
        # print(login_frame)   # 683200320068c900050000000270000001004116
        self.table.write(hang, 0, login_frame)

    # 2、构建心跳报文（0-f条）
    def generate_beat_frame(self, te_address, hang):
        sam_beat1 = ['68', '32', '00', '32', '00', '68', 'c9']
        sam_beat2 = ['00', '02']
        sam_beat3 = ['00', '00', '04', '00']
        sam_beat4 = ['16']
        lie = 1
        for item in self.iteration:
            temp_CS = ['xx']
            seq_list = list()
            temp_seq = '7' + item  # seq的序列号从是7x ，从x从0~e
            seq_list.append(temp_seq)
            temp_frame = sam_beat1 + te_address + sam_beat2 + seq_list + sam_beat3 + temp_CS + sam_beat4
            temp_CS[0] = self.calculate_CS(temp_frame)
            # print(temp_CS)  # 打印计算出的校验和CS
            temp_frame = sam_beat1 + te_address + sam_beat2 + seq_list + sam_beat3 + temp_CS + sam_beat4
            # print(temp_frame)  # 打印出构建心跳报文list
            beat_frame = ''
            for item in temp_frame:
                beat_frame = beat_frame + item  # 存入excel的报文格式
            # print(beat_frame)
            self.table.write(hang, lie, beat_frame)
            lie = lie + 1

    # 3、构建数据报文（1条）
    # 3.1 根据报文所需格式，得到当前时间：分 时 日 月 年
    def get_data_time(self):
        now_time = datetime.datetime.now().strftime('%H %d %m %y')  # 时 日 月 年
        fen = datetime.datetime.now().strftime('%M')  # 分
        if fen in (0, 15):
            fen = 0
        elif fen in (15, 30):
            fen = 15
        elif fen in (30, 45):
            fen = 30
        else:
            fen = 45
        # fen = nowTime[0]
        # print(fen)
        data_time = (str(fen) + " " + now_time)  # 报文所需格式 ：分 时 日 月 年
        data_time = data_time.split()
        return data_time

    # 3.2 替换模拟报文时间为当前时间：分 时 日 月 年
    def get_data(self, data_cjx):
        data = data_cjx
        data[4:9] = self.get_data_time()
        return data

    # 3.3 构建28项报文的数据列表
    def get_date_28(self):
        data_77 = self.get_data(['01', '01', '10', '09', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_78 = self.get_data(['01', '01', '20', '09', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_79 = self.get_data(['01', '01', '40', '09', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_80 = self.get_data(['01', '01', '80', '09', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_81 = self.get_data(['01', '01', '01', '0a', '15', '00', '14', '03', '18', '01', '01', '23', '01', '00'])
        data_82 = self.get_data(['01', '01', '02', '0a', '15', '00', '14', '03', '18', '01', '01', '23', '01', '00'])
        data_83 = self.get_data(['01', '01', '04', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_84 = self.get_data(['01', '01', '08', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_85 = self.get_data(['01', '01', '10', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_86 = self.get_data(['01', '01', '20', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_87 = self.get_data(['01', '01', '40', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_88 = self.get_data(['01', '01', '80', '0a', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_89 = self.get_data(['01', '01', '01', '0b', '15', '00', '14', '03', '18', '01', '01', '91', '22'])
        data_90 = self.get_data(['01', '01', '02', '0b', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee'])
        data_91 = self.get_data(['01', '01', '04', '0b', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee'])
        data_92 = self.get_data(['01', '01', '08', '0b', '15', '00', '14', '03', '18', '01', '01', '53', '00', '00'])
        data_93 = self.get_data(['01', '01', '10', '0b', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_94 = self.get_data(['01', '01', '20', '0b', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee'])
        data_95 = self.get_data(['01', '01', '40', '0b', '15', '00', '14', '03', '18', '01', '01', '54', '00', '00'])
        data_96 = self.get_data(['01', '01', '80', '0b', '15', '00', '14', '03', '18', '01', '01', '00', '00'])
        data_101 = self.get_data(['01', '01', '10', '0c', '15', '00', '14', '03', '18', '01', '01', '93', '52', '01', '00'])
        data_102 = self.get_data(['01', '01', '20', '0c', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee', 'ee'])
        data_103 = self.get_data(['01', '01', '40', '0c', '15', '00', '14', '03', '18', '01', '01', '28', '00', '00', '00'])
        data_104 = self.get_data(['01', '01', '80', '0c', '15', '00', '14', '03', '18', '01', '01', 'ee', 'ee', 'ee', 'ee'])
        data_105 = self.get_data(['01', '01', '01', '0d', '15', '00', '14', '03', '18', '01', '01', '00', '10'])
        data_106 = self.get_data(['01', '01', '02', '0d', '15', '00', '14', '03', '18', '01', '01', '00', '10'])
        data_107 = self.get_data(['01', '01', '04', '0d', '15', '00', '14', '03', '18', '01', '01', 'ff', 'ff'])
        data_108 = self.get_data(['01', '01', '08', '0d', '15', '00', '14', '03', '18', '01', '01', 'ff', 'ff', 'd6', '16'])
        data_list = data_77 + data_78 + data_79 + data_80 + data_81 + data_82 + data_83 + data_84 + data_85 + \
            data_86 + data_87 + data_88 + data_88 + data_89 + data_90 + data_91 + data_92 + data_93 + data_94 + \
            data_95 + data_96 + data_101 + data_102 + data_103 + data_104 + data_105 + data_106 + data_107 + data_108
        # print(data_77)
        # print(data_list)
        return data_list

    # 3.4 构建数据报文（1条）
    def generate_data_frame(self, te_address, hang):
        sam_data_head = ['68', '32', '06', '32', '06', '68', 'c4']
        sam_gnm = ['00', '0d', '7f']  # 地址域A3=00 ,功能码=0d，seq=7f
        sam_data_end = ['16']
        temp_CS = ['xx']
        data_list = self.get_date_28()  # 模拟28项数据组合上报数据
        temp_frame = sam_data_head + te_address + sam_gnm + data_list + temp_CS + sam_data_end  # print(temp_frame)
        temp_CS[0] = self.calculate_CS(temp_frame)   # print(temp_CS)
        temp_frame = sam_data_head + te_address + sam_gnm + data_list + temp_CS + sam_data_end  # print(temp_frame)
        data_frame = ''
        for item in temp_frame:
            data_frame = data_frame + item
        self.table.write(hang, 16, data_frame)

    # 4、整合报文：登录 + 心跳 + 数据
    def generate_frame(self, local_list, hang):
        self.generate_login_frame(local_list.copy(), hang)  # 登录
        self.generate_beat_frame(local_list.copy(), hang)  # 心跳
        self.generate_data_frame(local_list.copy(), hang)  # 数据

    # 5、转换终端地址为报文形式，保存完整报文
    def get_address_list(self):
        try:
            for i in range(max_count):
                # print(i)
                # if i == 0:
                #     continue
                tem_list = list()
                hex_address = hex(i)
                address = hex_address[2:]
                if len(address) == 1:
                    tem_add = '0' + address
                    tem_list.append(tem_add)
                    tem_list.append('00')
                elif len(address) == 2:
                    tem_list.append(address)
                    tem_list.append('00')
                    # address = address + '00'
                elif len(address) == 3:
                    qian_address = address[-2:]
                    hou_address = '0' + address[:-2]
                    tem_list.append(qian_address)
                    tem_list.append(hou_address)
                    # address = qian_address + '0' + hou_address
                else:
                    qian_address = address[-2:]
                    hou_address = address[:-2]
                    tem_list.append(qian_address)
                    tem_list.append(hou_address)
                    # address = qian_address + hou_address
                address_list = init_list + tem_list  # 得到终端地址
                self.generate_frame(address_list, i)  # 构建和储存登录、心跳报文
            self.excel.save(baowen)  # 保存完整报文
            print("【正常】构建 %s 条数据成功！ " % max_count)
            # return address_list, i
        except Exception as e:
            print("【异常】构建数据失败，报错：%s" % e)


if __name__ == '__main__':
    gbw = GenerateBaoWen()
    gbw.get_address_list()
